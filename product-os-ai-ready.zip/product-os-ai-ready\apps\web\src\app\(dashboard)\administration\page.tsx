import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Building2, 
  FolderKanban, 
  LayoutDashboard, 
  Map, 
  Plus, 
  Search, 
  Settings, 
  ShieldCheck, 
  Users 
} from 'lucide-react';

export default function Administration() {
  return (
    <div className="p-8 space-y-8 max-w-[1600px] mx-auto">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-slate-900">Administration Center</h1>
          <p className="text-muted-foreground mt-2 text-sm">
            Manage your organization's core entities, access control, and configurations.
          </p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="bg-white">
            <Settings className="w-4 h-4 mr-2" /> Global Settings
          </Button>
          <Button className="bg-indigo-600 hover:bg-indigo-700">
            <Plus className="w-4 h-4 mr-2" /> Create New Entity
          </Button>
        </div>
      </div>

      {/* Global Search */}
      <div className="relative max-w-2xl">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
        <Input 
          placeholder="Search products, projects, users, or teams..." 
          className="pl-10 h-12 bg-white border-slate-200 text-base rounded-xl"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        
        <Card className="bg-white hover:border-indigo-200 transition-colors cursor-pointer group shadow-sm border-slate-200 flex flex-col">
          <CardHeader>
            <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center mb-4 group-hover:bg-blue-100 group-hover:scale-105 transition-all">
              <LayoutDashboard className="w-6 h-6" />
            </div>
            <CardTitle>Products</CardTitle>
            <CardDescription>Manage your product portfolios, health scores, and core definitions.</CardDescription>
          </CardHeader>
          <CardContent className="mt-auto pt-0">
            <div className="flex items-center justify-between text-sm">
              <span className="font-medium text-slate-700">12 Active</span>
              <span className="text-indigo-600 font-medium hover:underline">Manage &rarr;</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white hover:border-indigo-200 transition-colors cursor-pointer group shadow-sm border-slate-200 flex flex-col">
          <CardHeader>
            <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center mb-4 group-hover:bg-indigo-100 group-hover:scale-105 transition-all">
              <FolderKanban className="w-6 h-6" />
            </div>
            <CardTitle>Projects</CardTitle>
            <CardDescription>Configure project workspaces, lifecycles, and default workflows.</CardDescription>
          </CardHeader>
          <CardContent className="mt-auto pt-0">
            <div className="flex items-center justify-between text-sm">
              <span className="font-medium text-slate-700">48 In-Flight</span>
              <span className="text-indigo-600 font-medium hover:underline">Manage &rarr;</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white hover:border-indigo-200 transition-colors cursor-pointer group shadow-sm border-slate-200 flex flex-col">
          <CardHeader>
            <div className="w-12 h-12 bg-amber-50 text-amber-600 rounded-xl flex items-center justify-center mb-4 group-hover:bg-amber-100 group-hover:scale-105 transition-all">
              <Map className="w-6 h-6" />
            </div>
            <CardTitle>Roadmaps</CardTitle>
            <CardDescription>Define strategic objectives, initiatives, and portfolio timelines.</CardDescription>
          </CardHeader>
          <CardContent className="mt-auto pt-0">
            <div className="flex items-center justify-between text-sm">
              <span className="font-medium text-slate-700">5 Active Portfolios</span>
              <span className="text-indigo-600 font-medium hover:underline">Manage &rarr;</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white hover:border-indigo-200 transition-colors cursor-pointer group shadow-sm border-slate-200 flex flex-col">
          <CardHeader>
            <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center mb-4 group-hover:bg-emerald-100 group-hover:scale-105 transition-all">
              <Users className="w-6 h-6" />
            </div>
            <CardTitle>Teams</CardTitle>
            <CardDescription>Build organizational structures, set capacities, and assign members.</CardDescription>
          </CardHeader>
          <CardContent className="mt-auto pt-0">
            <div className="flex items-center justify-between text-sm">
              <span className="font-medium text-slate-700">24 Teams</span>
              <span className="text-indigo-600 font-medium hover:underline">Manage &rarr;</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white hover:border-indigo-200 transition-colors cursor-pointer group shadow-sm border-slate-200 flex flex-col">
          <CardHeader>
            <div className="w-12 h-12 bg-purple-50 text-purple-600 rounded-xl flex items-center justify-center mb-4 group-hover:bg-purple-100 group-hover:scale-105 transition-all">
              <Building2 className="w-6 h-6" />
            </div>
            <CardTitle>Organization</CardTitle>
            <CardDescription>Configure organizational settings, billing, and global integrations.</CardDescription>
          </CardHeader>
          <CardContent className="mt-auto pt-0">
            <div className="flex items-center justify-between text-sm">
              <span className="font-medium text-slate-700">Acme Corp</span>
              <span className="text-indigo-600 font-medium hover:underline">Settings &rarr;</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white hover:border-indigo-200 transition-colors cursor-pointer group shadow-sm border-slate-200 flex flex-col">
          <CardHeader>
            <div className="w-12 h-12 bg-slate-100 text-slate-600 rounded-xl flex items-center justify-center mb-4 group-hover:bg-slate-200 group-hover:scale-105 transition-all">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <CardTitle>Access & Roles</CardTitle>
            <CardDescription>Manage user roles (CEO, PM, Dev) and granular permission layers.</CardDescription>
          </CardHeader>
          <CardContent className="mt-auto pt-0">
            <div className="flex items-center justify-between text-sm">
              <span className="font-medium text-slate-700">142 Users</span>
              <span className="text-indigo-600 font-medium hover:underline">Security &rarr;</span>
            </div>
          </CardContent>
        </Card>

      </div>

      {/* Recent Audit Log Stub */}
      <Card className="bg-white shadow-sm border-slate-200 mt-8">
        <CardHeader>
          <CardTitle className="text-lg">Recent Administrative Actions</CardTitle>
          <CardDescription>Audit log of organization-level changes</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              { action: 'User Role Updated', target: 'sarah.j@acme.com', by: 'admin@acme.com', time: '2 mins ago' },
              { action: 'Team Created', target: 'Frontend Platform Squad', by: 'admin@acme.com', time: '1 hour ago' },
              { action: 'Project Archived', target: 'Legacy Payment API', by: 'john.d@acme.com', time: '5 hours ago' },
            ].map((log, i) => (
              <div key={i} className="flex flex-col sm:flex-row sm:items-center justify-between p-3 rounded-lg border border-slate-100 bg-slate-50">
                <div>
                  <p className="text-sm font-medium text-slate-900">{log.action}: <span className="font-normal text-slate-600">{log.target}</span></p>
                  <p className="text-xs text-slate-500 mt-1">By {log.by}</p>
                </div>
                <div className="text-xs text-slate-400 mt-2 sm:mt-0 font-medium">
                  {log.time}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      
    </div>
  );
}
