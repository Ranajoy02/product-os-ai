import { Resolver, Query, Mutation, Args, ID } from '@nestjs/graphql';
import { RoadmapService } from './roadmap.service';
import {
  Roadmap,
  StrategicGoal,
  Objective,
  Initiative,
  RoadmapItem,
  RoadmapType,
} from './roadmap.model';

@Resolver(() => Roadmap)
export class RoadmapResolver {
  constructor(private readonly roadmapService: RoadmapService) {}

  @Query(() => Roadmap, { nullable: true })
  async roadmapTree(@Args('id', { type: () => ID }) id: string) {
    return this.roadmapService.getRoadmapTree(id);
  }

  @Query(() => [Roadmap])
  async roadmaps() {
    return this.roadmapService.getRoadmaps();
  }

  @Mutation(() => StrategicGoal)
  async createStrategicGoal(@Args('name') name: string) {
    return this.roadmapService.createStrategicGoal(name);
  }

  @Mutation(() => Objective)
  async createObjective(
    @Args('goalId') goalId: string,
    @Args('name') name: string,
  ) {
    return this.roadmapService.createObjective(goalId, name);
  }

  @Mutation(() => Initiative)
  async createInitiative(
    @Args('objectiveId') objectiveId: string,
    @Args('name') name: string,
  ) {
    return this.roadmapService.createInitiative(objectiveId, name);
  }

  @Mutation(() => Roadmap)
  async createRoadmap(
    @Args('name') name: string,
    @Args('type', { type: () => RoadmapType }) type: RoadmapType,
  ) {
    return this.roadmapService.createRoadmap(name, type);
  }

  @Mutation(() => RoadmapItem)
  async createRoadmapItem(
    @Args('roadmapId') roadmapId: string,
    @Args('initiativeId') initiativeId: string,
    @Args('startDate') startDate: Date,
    @Args('endDate') endDate: Date,
    @Args('status') status: string,
  ) {
    return this.roadmapService.createRoadmapItem(
      roadmapId,
      initiativeId,
      startDate,
      endDate,
      status,
    );
  }
}
