import { Module } from '@nestjs/common';
import { RoadmapService } from './roadmap.service';
import { RoadmapController } from './roadmap.controller';
import { RoadmapResolver } from './roadmap.resolver';

@Module({
  controllers: [RoadmapController],
  providers: [RoadmapService, RoadmapResolver],
  exports: [RoadmapService],
})
export class RoadmapModule {}
