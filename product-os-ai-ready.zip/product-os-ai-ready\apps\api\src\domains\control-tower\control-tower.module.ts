import { Module } from '@nestjs/common';
import { ControlTowerResolver } from './control-tower.resolver';
import { ControlTowerService } from './control-tower.service';

@Module({
  providers: [ControlTowerResolver, ControlTowerService],
  exports: [ControlTowerService],
})
export class ControlTowerModule {}
