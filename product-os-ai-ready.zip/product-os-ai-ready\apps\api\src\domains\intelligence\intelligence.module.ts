import { Module } from '@nestjs/common';
import { DeliveryIntelligenceResolver } from './delivery-intelligence/delivery-intelligence.resolver';
import { IntelligenceResolver } from './intelligence.resolver';
import { IntelligenceService } from './intelligence.service';
import { PrismaModule } from '../../core/prisma/prisma.module';

@Module({
  imports: [PrismaModule],
  providers: [
    DeliveryIntelligenceResolver,
    IntelligenceResolver,
    IntelligenceService,
  ],
  exports: [
    DeliveryIntelligenceResolver,
    IntelligenceResolver,
    IntelligenceService,
  ],
})
export class IntelligenceModule {}
