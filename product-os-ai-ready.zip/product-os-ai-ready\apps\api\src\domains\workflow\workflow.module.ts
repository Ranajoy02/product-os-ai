import { Module } from '@nestjs/common';
import { WorkflowService } from './workflow.service';
import { WorkflowController } from './workflow.controller';
import { WorkflowResolver } from './workflow.resolver';

@Module({
  controllers: [WorkflowController],
  providers: [WorkflowService, WorkflowResolver],
  exports: [WorkflowService, WorkflowResolver],
})
export class WorkflowModule {}
