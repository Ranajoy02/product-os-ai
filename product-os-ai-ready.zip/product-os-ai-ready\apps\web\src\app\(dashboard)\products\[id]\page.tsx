import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

export default function ProductHealthDashboard() {
  // Static mockup for the UI. Real data fetched from /api/health/products/:id
  const healthScore = 84; 
  const statusColor = healthScore > 70 ? 'text-emerald-500' : healthScore > 40 ? 'text-amber-500' : 'text-rose-500';

  return (
    <div className="p-8 space-y-8 max-w-5xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Product Health: Alpha</h1>
          <p className="text-muted-foreground">Aggregated across 3 linked projects and 14 releases.</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">Recalculate</Button>
          <Button>Generate Report</Button>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-4">
        <Card className="col-span-1 md:col-span-4 bg-slate-900 text-white">
          <CardContent className="p-8 flex items-center justify-between">
            <div>
              <div className="text-sm text-slate-400 mb-1">OVERALL HEALTH SCORE</div>
              <div className="text-6xl font-bold flex items-baseline gap-2">
                {healthScore} <span className="text-xl font-medium text-slate-400">/ 100</span>
              </div>
            </div>
            <div className={`text-4xl font-black tracking-widest uppercase ${statusColor}`}>
              GREEN
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Bug Density</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1.2%</div>
            <p className="text-xs text-emerald-500 mt-1">↓ 0.4% from last sprint</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Velocity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">42 pts/wk</div>
            <p className="text-xs text-emerald-500 mt-1">↑ 5 pts from last sprint</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Customer Score</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">4.8 / 5</div>
            <p className="text-xs text-slate-500 mt-1">Based on 12 reviews</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Release Stability</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">99.9%</div>
            <p className="text-xs text-slate-500 mt-1">Last 30 days</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>AI Risk Analysis</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="p-4 rounded-md bg-indigo-50 border border-indigo-100 text-sm text-indigo-900">
            <strong>Copilot Insight:</strong> The product is highly stable. However, Velocity has plateaued. 
            Consider allocating an additional frontend engineer to the "Beta Dashboard" project to prevent bottlenecking next week.
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
