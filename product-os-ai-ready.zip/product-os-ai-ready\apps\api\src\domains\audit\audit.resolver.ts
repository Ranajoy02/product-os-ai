import { Resolver, Query, Mutation, Args } from '@nestjs/graphql';
import { AuditService } from './audit.service';
import { AuditLog, CreateAuditLogInput } from './models/audit.model';

@Resolver(() => AuditLog)
export class AuditResolver {
  constructor(private readonly auditService: AuditService) {}

  @Query(() => [AuditLog])
  getAuditEvents() {
    return this.auditService.getAuditLogs();
  }

  @Mutation(() => AuditLog)
  createAuditLog(@Args('input') input: CreateAuditLogInput) {
    return this.auditService.createAuditLog(input);
  }
}
