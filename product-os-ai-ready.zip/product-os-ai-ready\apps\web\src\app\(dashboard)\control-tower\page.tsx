'use client';

import React from 'react';
import { useQuery } from '@apollo/experimental-nextjs-app-support/ssr';
import { gql } from '@apollo/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Activity, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  FolderKanban, 
  LayoutDashboard, 
  Target, 
  TrendingUp, 
  Users,
  Loader2
} from 'lucide-react';

const GET_CONTROL_TOWER_METRICS = gql`
  query GetControlTowerMetrics {
    controlTowerMetrics {
      activeProducts {
        count
        trend
      }
      inFlightProjects {
        count
        onTrackPercentage
      }
      totalTeams {
        count
        avgUtilization
      }
      deliveryHealth {
        score
        grade
      }
      risks {
        title
        project
        severity
        impact
      }
      actionItems {
        pendingPrdApprovals
        pendingChangeRequests
        offTrackOkrs
      }
    }
  }
`;

export default function ControlTower() {
  const { data, loading, error } = useQuery<any>(GET_CONTROL_TOWER_METRICS);

  if (loading) {
    return (
      <div className="flex h-[calc(100vh-4rem)] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-indigo-600" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-8 max-w-[1600px] mx-auto text-red-500">
        Error loading control tower metrics: {error.message}
      </div>
    );
  }

  const metrics = data?.controlTowerMetrics;

  return (
    <div className="p-8 space-y-8 max-w-[1600px] mx-auto">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-slate-900">PM Control Tower</h1>
          <p className="text-muted-foreground mt-2 text-sm">
            Real-time delivery intelligence across all products, projects, and teams.
          </p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="bg-white">Export Report</Button>
          <Button className="bg-indigo-600 hover:bg-indigo-700">Generate Insights</Button>
        </div>
      </div>

      {/* Primary KPI Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-white shadow-sm border-slate-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500 mb-1">Active Products</p>
                <h3 className="text-3xl font-bold text-slate-900">{metrics?.activeProducts.count || 0}</h3>
              </div>
              <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center">
                <LayoutDashboard className="w-6 h-6" />
              </div>
            </div>
            <div className="mt-4 flex items-center text-sm">
              <TrendingUp className="w-4 h-4 text-emerald-500 mr-1" />
              <span className="text-emerald-600 font-medium">+{metrics?.activeProducts.trend || 0}</span>
              <span className="text-slate-500 ml-1">this quarter</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-slate-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500 mb-1">In-Flight Projects</p>
                <h3 className="text-3xl font-bold text-slate-900">{metrics?.inFlightProjects.count || 0}</h3>
              </div>
              <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center">
                <FolderKanban className="w-6 h-6" />
              </div>
            </div>
            <div className="mt-4 flex items-center text-sm">
              <span className="text-indigo-600 font-medium">{metrics?.inFlightProjects.onTrackPercentage || 0}%</span>
              <span className="text-slate-500 ml-1">on track</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-slate-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500 mb-1">Total Teams</p>
                <h3 className="text-3xl font-bold text-slate-900">{metrics?.totalTeams.count || 0}</h3>
              </div>
              <div className="w-12 h-12 bg-purple-50 text-purple-600 rounded-xl flex items-center justify-center">
                <Users className="w-6 h-6" />
              </div>
            </div>
            <div className="mt-4 flex items-center text-sm">
              <span className="text-purple-600 font-medium">{metrics?.totalTeams.avgUtilization || 0}%</span>
              <span className="text-slate-500 ml-1">avg utilization</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-slate-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500 mb-1">Delivery Health</p>
                <h3 className="text-3xl font-bold text-slate-900">{metrics?.deliveryHealth.grade || 'N/A'}</h3>
              </div>
              <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center">
                <Activity className="w-6 h-6" />
              </div>
            </div>
            <div className="mt-4 flex items-center text-sm">
              <TrendingUp className="w-4 h-4 text-emerald-500 mr-1" />
              <span className="text-emerald-600 font-medium">{metrics?.deliveryHealth.score || 0}</span>
              <span className="text-slate-500 ml-1">score</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Risk Radar */}
        <Card className="col-span-1 lg:col-span-2 bg-white shadow-sm border-slate-200">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-lg">Delivery Risk Radar</CardTitle>
                <CardDescription>AI-detected anomalies and bottlenecks</CardDescription>
              </div>
              <Button variant="outline" size="sm" className="h-8 text-xs">View All</Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {metrics?.risks.map((risk: any, i: number) => (
                <div key={i} className="flex items-start gap-4 p-4 rounded-lg bg-slate-50 border border-slate-100">
                  <div className={`mt-0.5 w-2 h-2 rounded-full ${risk.severity === 'high' ? 'bg-red-500' : 'bg-amber-500'}`} />
                  <div className="flex-1">
                    <h4 className="text-sm font-semibold text-slate-900">{risk.title}</h4>
                    <p className="text-xs text-slate-500 mt-1">Project: {risk.project}</p>
                    <div className="mt-2 text-xs font-medium text-slate-700 bg-white inline-flex px-2 py-1 rounded border border-slate-200">
                      Impact: {risk.impact}
                    </div>
                  </div>
                  <Button variant="outline" size="sm" className="h-8 text-xs shrink-0">Mitigate</Button>
                </div>
              ))}
              {(!metrics?.risks || metrics.risks.length === 0) && (
                <p className="text-sm text-slate-500">No active risks detected.</p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Action Center */}
        <Card className="bg-white shadow-sm border-slate-200">
          <CardHeader>
            <CardTitle className="text-lg">Action Center</CardTitle>
            <CardDescription>Items requiring your attention</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 rounded-lg border border-slate-100 hover:bg-slate-50 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-slate-900">PRD Approvals</p>
                    <p className="text-xs text-slate-500">{metrics?.actionItems.pendingPrdApprovals || 0} pending review</p>
                  </div>
                </div>
                <Button size="sm" variant="ghost" className="h-8 px-2 text-indigo-600">Review</Button>
              </div>

              <div className="flex items-center justify-between p-3 rounded-lg border border-slate-100 hover:bg-slate-50 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center">
                    <AlertTriangle className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-slate-900">Change Requests</p>
                    <p className="text-xs text-slate-500">{metrics?.actionItems.pendingChangeRequests || 0} waiting for decision</p>
                  </div>
                </div>
                <Button size="sm" variant="ghost" className="h-8 px-2 text-indigo-600">Review</Button>
              </div>

              <div className="flex items-center justify-between p-3 rounded-lg border border-slate-100 hover:bg-slate-50 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center">
                    <Target className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-slate-900">Strategic OKRs</p>
                    <p className="text-xs text-slate-500">{metrics?.actionItems.offTrackOkrs || 0} off track</p>
                  </div>
                </div>
                <Button size="sm" variant="ghost" className="h-8 px-2 text-indigo-600">View</Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Ongoing Roadmaps Timeline Stub */}
      <Card className="bg-white shadow-sm border-slate-200">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg">Enterprise Roadmap Status</CardTitle>
              <CardDescription>High-level portfolio view across all verticals</CardDescription>
            </div>
            <Button variant="outline" size="sm" className="h-8 text-xs">Full Roadmap</Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-64 rounded-lg bg-slate-50 border border-slate-100 flex flex-col items-center justify-center text-slate-400">
            <Clock className="w-8 h-8 mb-3 opacity-50" />
            <p className="text-sm font-medium">Gantt Visualization Rendering...</p>
            <p className="text-xs mt-1">Connecting to Roadmap Intelligence Engine</p>
          </div>
        </CardContent>
      </Card>

    </div>
  );
}
