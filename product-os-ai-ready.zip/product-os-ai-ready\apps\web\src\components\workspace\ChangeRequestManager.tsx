'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { PlusCircle, Search } from 'lucide-react';

type ChangeRequestStatus = 'Pending' | 'Review' | 'Approved' | 'Rejected' | 'Closed';

interface ChangeRequest {
  id: string;
  title: string;
  description: string;
  status: ChangeRequestStatus;
  date: string;
}

const INITIAL_REQUESTS: ChangeRequest[] = [
  { id: 'CR-101', title: 'Update Auth Flow', description: 'Add support for OAuth providers', status: 'Approved', date: '2023-10-24' },
  { id: 'CR-102', title: 'Modify Schema', description: 'Add new fields for user profile', status: 'Review', date: '2023-10-25' },
  { id: 'CR-103', title: 'API Rate Limiting', description: 'Implement rate limiting on public endpoints', status: 'Pending', date: '2023-10-26' },
];

const STATUS_COLORS: Record<ChangeRequestStatus, string> = {
  Pending: 'bg-yellow-100 text-yellow-800 hover:bg-yellow-100',
  Review: 'bg-blue-100 text-blue-800 hover:bg-blue-100',
  Approved: 'bg-green-100 text-green-800 hover:bg-green-100',
  Rejected: 'bg-red-100 text-red-800 hover:bg-red-100',
  Closed: 'bg-gray-100 text-gray-800 hover:bg-gray-100',
};

export function ChangeRequestManager() {
  const [requests, setRequests] = useState<ChangeRequest[]>(INITIAL_REQUESTS);
  const [searchTerm, setSearchTerm] = useState('');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDescription, setNewDescription] = useState('');

  const filteredRequests = requests.filter(cr => 
    cr.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
    cr.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleAddRequest = () => {
    if (!newTitle.trim()) return;
    
    const newRequest: ChangeRequest = {
      id: `CR-${100 + requests.length + 1}`,
      title: newTitle,
      description: newDescription,
      status: 'Pending',
      date: new Date().toISOString().split('T')[0],
    };
    
    setRequests([newRequest, ...requests]);
    setNewTitle('');
    setNewDescription('');
    setIsFormOpen(false);
  };

  return (
    <Card className="h-full flex flex-col min-h-[400px]">
      <CardHeader className="pb-3 flex flex-row items-center justify-between space-y-0 flex-shrink-0">
        <div>
          <CardTitle className="text-lg">Change Requests</CardTitle>
          <CardDescription>Track and manage updates</CardDescription>
        </div>
        <Button size="sm" variant="outline" onClick={() => setIsFormOpen(!isFormOpen)}>
          <PlusCircle className="h-4 w-4 mr-2" />
          New CR
        </Button>
      </CardHeader>
      <CardContent className="flex-grow flex flex-col overflow-hidden">
        {isFormOpen && (
          <div className="mb-4 space-y-3 p-3 border rounded-md bg-slate-50/50">
            <Input 
              placeholder="Request Title" 
              value={newTitle} 
              onChange={(e) => setNewTitle(e.target.value)} 
            />
            <Textarea 
              placeholder="Description & impact" 
              value={newDescription} 
              onChange={(e) => setNewDescription(e.target.value)}
              className="resize-none text-sm h-20"
            />
            <div className="flex justify-end gap-2">
              <Button size="sm" variant="ghost" onClick={() => setIsFormOpen(false)}>Cancel</Button>
              <Button size="sm" onClick={handleAddRequest} disabled={!newTitle.trim()}>Submit</Button>
            </div>
          </div>
        )}

        {!isFormOpen && (
          <div className="relative mb-4 flex-shrink-0">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search requests..."
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        )}

        <ScrollArea className="flex-grow min-h-0 pr-4">
          <div className="space-y-3 pb-4">
            {filteredRequests.map((cr) => (
              <div key={cr.id} className="p-3 border rounded-lg hover:bg-slate-50 transition-colors">
                <div className="flex justify-between items-start mb-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono text-muted-foreground">{cr.id}</span>
                    <h4 className="text-sm font-semibold truncate max-w-[150px] sm:max-w-[180px]">{cr.title}</h4>
                  </div>
                  <Badge variant="secondary" className={`text-[10px] uppercase font-bold px-1.5 ${STATUS_COLORS[cr.status]}`}>
                    {cr.status}
                  </Badge>
                </div>
                <p className="text-xs text-muted-foreground line-clamp-2 mb-2">
                  {cr.description}
                </p>
                <div className="text-[10px] text-muted-foreground flex justify-end">
                  {cr.date}
                </div>
              </div>
            ))}
            {filteredRequests.length === 0 && (
              <div className="text-center py-8 text-sm text-muted-foreground">
                No change requests found.
              </div>
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
