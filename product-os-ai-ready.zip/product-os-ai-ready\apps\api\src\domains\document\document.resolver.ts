import { Resolver, Query, Mutation, Args, ID } from '@nestjs/graphql';
import { DocumentService } from './document.service';
import {
  Document,
  CreateDocumentInput,
  UpdateDocumentInput,
} from './document.model';

@Resolver(() => Document)
export class DocumentResolver {
  constructor(private readonly documentService: DocumentService) {}

  @Query(() => [Document], { name: 'documents' })
  async getDocuments() {
    return this.documentService.findAll();
  }

  @Query(() => Document, { name: 'document', nullable: true })
  async getDocument(@Args('id', { type: () => ID }) id: string) {
    return this.documentService.findById(id);
  }

  @Mutation(() => Document)
  async createDocument(@Args('input') input: CreateDocumentInput) {
    return this.documentService.create(input);
  }

  @Mutation(() => Document)
  async updateDocument(
    @Args('id', { type: () => ID }) id: string,
    @Args('input') input: UpdateDocumentInput,
  ) {
    return this.documentService.update(id, input);
  }

  @Mutation(() => Document)
  async deleteDocument(@Args('id', { type: () => ID }) id: string) {
    return this.documentService.delete(id);
  }
}
