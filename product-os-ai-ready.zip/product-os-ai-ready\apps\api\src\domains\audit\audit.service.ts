import { Injectable } from '@nestjs/common';
import { AuditLog, CreateAuditLogInput } from './models/audit.model';

@Injectable()
export class AuditService {
  private logs: AuditLog[] = [];

  getAuditLogs(): AuditLog[] {
    return this.logs;
  }

  createAuditLog(input: CreateAuditLogInput): AuditLog {
    const newLog = {
      id: Math.random().toString(36).substring(7),
      ...input,
    };
    this.logs.push(newLog);
    return newLog;
  }
}
