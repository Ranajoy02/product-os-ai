import { Resolver, Query, Mutation, Args } from '@nestjs/graphql';
import { MigrationService } from './migration.service';
import {
  MigrationSimulation,
  FieldMapping,
  MigrationValidationResult,
  MigrationConversionStatus,
  VerificationResult,
  StartSimulationInput,
  CreateFieldMappingInput,
} from './models/migration.model';

@Resolver()
export class MigrationResolver {
  constructor(private readonly migrationService: MigrationService) {}

  @Query(() => MigrationSimulation, { nullable: true })
  async migrationSimulation(@Args('id') id: string) {
    return this.migrationService.getSimulation(id);
  }

  @Query(() => [MigrationSimulation])
  async getMigrationSimulations() {
    return this.migrationService.getSimulations();
  }

  @Mutation(() => MigrationSimulation)
  async startSimulation(@Args('input') input: StartSimulationInput) {
    return this.migrationService.startSimulation(input);
  }

  @Query(() => [FieldMapping])
  async fieldMappings() {
    return this.migrationService.getFieldMappings();
  }

  @Mutation(() => FieldMapping)
  async createFieldMapping(@Args('input') input: CreateFieldMappingInput) {
    return this.migrationService.createFieldMapping(input);
  }

  @Query(() => MigrationValidationResult, { nullable: true })
  async migrationValidationResult(@Args('id') id: string) {
    return this.migrationService.getValidationResult(id);
  }

  @Query(() => MigrationConversionStatus, { nullable: true })
  async migrationConversionStatus(@Args('id') id: string) {
    return this.migrationService.getConversionStatus(id);
  }

  @Query(() => VerificationResult, { nullable: true })
  async verificationResult(@Args('id') id: string) {
    return this.migrationService.getVerificationResult(id);
  }
}
