import { Controller, Get, Param, Post, Body, UseGuards } from '@nestjs/common';
import { RoadmapService } from './roadmap.service';
import { JwtAuthGuard } from '../../core/auth/jwt-auth.guard';
import { RoadmapType } from '@prisma/client';

@UseGuards(JwtAuthGuard)
@Controller('roadmap')
export class RoadmapController {
  constructor(private readonly roadmapService: RoadmapService) {}

  @Get(':id/tree')
  async getRoadmapTree(@Param('id') id: string) {
    return this.roadmapService.getRoadmapTree(id);
  }

  @Post()
  async createRoadmap(@Body() body: { name: string; type: RoadmapType }) {
    return this.roadmapService.createRoadmap(body.name, body.type);
  }

  @Post('goals')
  async createStrategicGoal(@Body('name') name: string) {
    return this.roadmapService.createStrategicGoal(name);
  }

  @Post('objectives')
  async createObjective(@Body() body: { goalId: string; name: string }) {
    return this.roadmapService.createObjective(body.goalId, body.name);
  }

  @Post('initiatives')
  async createInitiative(@Body() body: { objectiveId: string; name: string }) {
    return this.roadmapService.createInitiative(body.objectiveId, body.name);
  }

  @Post('items')
  async createRoadmapItem(
    @Body()
    body: {
      roadmapId: string;
      initiativeId: string;
      startDate: string;
      endDate: string;
      status: string;
    },
  ) {
    return this.roadmapService.createRoadmapItem(
      body.roadmapId,
      body.initiativeId,
      new Date(body.startDate),
      new Date(body.endDate),
      body.status,
    );
  }
}
