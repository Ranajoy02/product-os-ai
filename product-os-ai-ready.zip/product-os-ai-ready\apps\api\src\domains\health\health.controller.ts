import { Controller, Get, Param, Query, UseGuards } from '@nestjs/common';
import { HealthService } from './health.service';
import { JwtAuthGuard } from '../../core/auth/jwt-auth.guard';

@UseGuards(JwtAuthGuard)
@Controller('health')
export class HealthController {
  constructor(private readonly healthService: HealthService) {}

  @Get('products/:productId')
  async getProductHealth(@Param('productId') productId: string) {
    return this.healthService.getProductHealth(productId);
  }

  @Get('products/:productId/trend')
  async getProductHealthTrend(
    @Param('productId') productId: string,
    @Query('days') days?: string,
  ) {
    return this.healthService.getHealthTrend(
      productId,
      days ? parseInt(days, 10) : 30,
    );
  }
}
