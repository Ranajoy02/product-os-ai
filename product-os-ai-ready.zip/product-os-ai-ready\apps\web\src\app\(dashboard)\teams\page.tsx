'use client';

import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  BarChart,
  Calendar,
  ChevronRight,
  MoreVertical,
  Plus,
  Search,
  Users
} from 'lucide-react';
import { useQuery } from '@apollo/experimental-nextjs-app-support/ssr';
import { gql } from '@apollo/client';
import { toast } from 'sonner';

const GET_TEAMS = gql`
  query GetTeams {
    getTeams {
      id
      name
      capacity
      velocity
      utilization
      members {
        id
        user {
          id
          firstName
          lastName
          role
        }
      }
    }
  }
`;

export default function Teams() {
  const { data, loading, error } = useQuery<any>(GET_TEAMS);

  if (loading) return <div className="p-8">Loading teams...</div>;
  if (error) return <div className="p-8 text-red-500">Error loading teams: {error.message}</div>;

  const teams = data?.getTeams || [];

  return (
    <div className="p-8 space-y-8 max-w-[1600px] mx-auto">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-slate-900">Team Management</h1>
          <p className="text-muted-foreground mt-2 text-sm">
            Manage team workspaces, track capacity, and map organizational skills.
          </p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="bg-white" onClick={() => toast.info('Generating Capacity Report...')}>
            <BarChart className="w-4 h-4 mr-2" /> Capacity Report
          </Button>
          <Button className="bg-indigo-600 hover:bg-indigo-700 text-white" onClick={() => toast.success('Opening Team Creation Wizard...')}>
            <Plus className="w-4 h-4 mr-2" /> Create Team
          </Button>
        </div>
      </div>

      <div className="flex items-center gap-4 border-b border-slate-200 pb-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input 
            placeholder="Search teams or members..." 
            className="pl-9 h-10 bg-white border-slate-200"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {teams.map((team: any, index: number) => {
          // Dynamic styling logic similar to original UI
          const iconColors = ['bg-blue-100 text-blue-600', 'bg-emerald-100 text-emerald-600', 'bg-purple-100 text-purple-600', 'bg-amber-100 text-amber-600'];
          const avatarColors = [
            'bg-blue-200 text-blue-700', 
            'bg-purple-200 text-purple-700', 
            'bg-amber-200 text-amber-700', 
            'bg-emerald-200 text-emerald-700',
            'bg-red-200 text-red-700'
          ];
          
          return (
            <Card key={team.id} className="bg-white shadow-sm border-slate-200">
              <CardHeader className="pb-4">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-xl flex items-center gap-2">
                      <div className={`w-8 h-8 rounded flex items-center justify-center shrink-0 ${iconColors[index % iconColors.length]}`}>
                        <Users className="w-4 h-4" />
                      </div>
                      {team.name}
                    </CardTitle>
                    <CardDescription className="mt-1">Team Overview and Capacity</CardDescription>
                  </div>
                  <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-slate-400">
                    <MoreVertical className="w-4 h-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-4 mb-6">
                  <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
                    <p className="text-xs text-slate-500 font-medium uppercase tracking-wider mb-1">Capacity</p>
                    <p className="text-xl font-bold text-slate-900">{team.capacity}<span className="text-sm font-normal text-slate-500">pts</span></p>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
                    <p className="text-xs text-slate-500 font-medium uppercase tracking-wider mb-1">Utilization</p>
                    <p className={`text-xl font-bold ${team.utilization > 100 ? 'text-amber-600' : 'text-emerald-600'}`}>{team.utilization}%</p>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-50 border border-slate-100">
                    <p className="text-xs text-slate-500 font-medium uppercase tracking-wider mb-1">Velocity</p>
                    <p className="text-xl font-bold text-slate-900">{team.velocity}<span className="text-sm font-normal text-slate-500">/sp</span></p>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm font-semibold text-slate-900">Key Members ({team.members?.length || 0})</h4>
                    <Button variant="link" size="sm" className="h-auto p-0 text-indigo-600">Manage</Button>
                  </div>
                  <div className="flex -space-x-2">
                    {team.members?.slice(0, 4).map((member: any, mIdx: number) => {
                      const initials = `${member.user.firstName?.[0] || ''}${member.user.lastName?.[0] || ''}`.toUpperCase() || 'U';
                      return (
                        <div key={member.id} className={`w-8 h-8 rounded-full border-2 border-white flex items-center justify-center text-xs font-bold z-${(mIdx + 1) * 10} ${avatarColors[mIdx % avatarColors.length]}`} title={`${member.user.firstName} ${member.user.lastName}`}>
                          {initials}
                        </div>
                      )
                    })}
                    {team.members?.length > 4 && (
                      <div className="w-8 h-8 rounded-full border-2 border-white bg-slate-100 flex items-center justify-center text-xs text-slate-600 font-bold z-50">
                        +{team.members.length - 4}
                      </div>
                    )}
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
                  <div className="flex items-center gap-2 text-sm text-slate-600">
                    <Calendar className="w-4 h-4" /> Current Sprint
                  </div>
                  <Button variant="ghost" size="sm" className="text-indigo-600 font-medium">Workspace <ChevronRight className="w-4 h-4 ml-1" /></Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
