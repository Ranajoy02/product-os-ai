import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../core/prisma/prisma.service';
import { EventsGateway } from '../../core/events/events.gateway';
import { TaskStatus } from '@prisma/client';

@Injectable()
export class TaskService {
  constructor(
    private prisma: PrismaService,
    private eventsGateway: EventsGateway,
  ) {}

  async createTask(
    projectId: string,
    data: {
      title: string;
      description: string;
      status?: TaskStatus;
      assigneeId?: string;
    },
  ) {
    const task = await this.prisma.task.create({
      data: { ...data, projectId },
    });
    this.eventsGateway.broadcastTaskUpdate(projectId, {
      action: 'created',
      task,
    });
    return task;
  }

  async updateTaskStatus(taskId: string, status: TaskStatus) {
    const task = await this.prisma.task.update({
      where: { id: taskId },
      data: { status },
    });
    this.eventsGateway.broadcastTaskUpdate(task.projectId, {
      action: 'updated',
      task,
    });

    // Core AI Value Prop: If moved to REVIEW, trigger Approval Engine (stubbed for now)
    if (status === 'REVIEW') {
      await this.triggerApprovalEngine(task.id);
    }

    return task;
  }

  async getTasksByProject(projectId: string) {
    return this.prisma.task.findMany({ where: { projectId } });
  }

  private async triggerApprovalEngine(taskId: string) {
    console.log(`[Approval Engine] Triggered for task ${taskId}`);
    // In Phase 3, this will invoke AI to check DoD and assign approvers.
    await this.prisma.approval.create({
      data: {
        taskId,
        approverId: 'system-or-manager-id', // Stub
        status: 'PENDING',
      },
    });
  }
}
