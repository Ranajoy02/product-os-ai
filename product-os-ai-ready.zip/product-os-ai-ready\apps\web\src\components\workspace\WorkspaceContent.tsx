'use client';

import React from 'react';
import { useWorkspaceStore } from '@/store/workspace-context';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, MessageSquare } from 'lucide-react';
import { OverviewTab } from './OverviewTab';
import { LifecycleTab } from './LifecycleTab';
import { OutcomeDashboard } from './OutcomeDashboard';
import { AIDeliveryBrain } from '../intelligence/AIDeliveryBrain';
import { DigitalTwin } from '../intelligence/DigitalTwin';

export function WorkspaceContent() {
  const { activeTab, activeLifecycleStage, entityType, entityId } = useWorkspaceStore();

  // Subagents will build these out. For now, placeholders to prove routing.
  
  if (activeTab === 'Overview') {
    return <OverviewTab />;
  }

  if (activeTab === 'Lifecycle') {
    return <LifecycleTab />;
  }

  if (activeTab === 'Insights') {
    return (
      <div className="space-y-6">
        <OutcomeDashboard />
        <AIDeliveryBrain entityId={entityId || 'default'} />
        <DigitalTwin entityId={entityId || 'default'} />
      </div>
    );
  }

  if (activeTab === 'Communication') {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center text-slate-500">
          <MessageSquare className="h-12 w-12 mx-auto mb-4 text-slate-300" />
          <h2 className="text-xl font-medium text-slate-900 dark:text-slate-100">Communication Hub</h2>
          <p className="mt-2">Select a thread in the right drawer to begin.</p>
        </div>
      </div>
    );
  }

  // Fallback for other tabs
  return (
    <div className="flex items-center justify-center h-full text-slate-500">
      <div className="text-center">
        <p className="text-lg font-medium">{activeTab} Context</p>
        <p className="text-sm">Delegated to subagents.</p>
      </div>
    </div>
  );
}
