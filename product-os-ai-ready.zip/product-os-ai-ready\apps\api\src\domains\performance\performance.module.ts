import { Module } from '@nestjs/common';
import { PerformanceService } from './performance.service';
import { PerformanceResolver } from './performance.resolver';

@Module({
  providers: [PerformanceService, PerformanceResolver],
  exports: [PerformanceService, PerformanceResolver],
})
export class PerformanceModule {}
