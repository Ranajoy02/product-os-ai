'use client';

import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Shield, Key, Fingerprint, Users, Clock, Globe } from 'lucide-react';

export default function IdentityAccessPage() {
  const [ssoEnabled, setSsoEnabled] = useState(true);

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Identity & Access Center</h1>
        <p className="text-slate-500 mt-1">Enterprise SSO, SCIM provisioning, and Zero-Trust policies.</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {/* SSO Settings */}
        <Card className="lg:col-span-2 border-slate-200 shadow-sm">
          <CardHeader className="border-b border-slate-100 bg-slate-50/50 pb-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Globe className="w-5 h-5 text-indigo-500" />
                <CardTitle className="text-lg">Single Sign-On (SAML/OIDC)</CardTitle>
              </div>
              <div className={`px-2 py-1 rounded text-xs font-semibold ${ssoEnabled ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>
                {ssoEnabled ? 'Active' : 'Disabled'}
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-6 space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 border rounded-xl border-indigo-200 bg-indigo-50/50 flex flex-col gap-2">
                <span className="font-bold text-slate-900">Okta Identity Cloud</span>
                <span className="text-sm text-slate-500">Primary IdP • SAML 2.0</span>
                <Button variant="outline" size="sm" className="w-fit mt-2 bg-white">Configure</Button>
              </div>
              <div className="p-4 border rounded-xl border-slate-200 bg-slate-50 flex flex-col gap-2 opacity-60 hover:opacity-100 transition-opacity">
                <span className="font-bold text-slate-900">Azure Active Directory</span>
                <span className="text-sm text-slate-500">OIDC Connect</span>
                <Button variant="outline" size="sm" className="w-fit mt-2 bg-white">Connect</Button>
              </div>
            </div>
            
            <div className="pt-4 border-t border-slate-100">
              <label className="text-sm font-semibold text-slate-700">SCIM Provisioning URL</label>
              <div className="flex gap-2 mt-2">
                <Input value="https://api.product-os.ai/scim/v2/tenant-1a2b" readOnly className="bg-slate-50 font-mono text-xs" />
                <Button variant="outline">Copy</Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* MFA & Policies */}
        <Card className="border-slate-200 shadow-sm">
          <CardHeader className="border-b border-slate-100 bg-slate-50/50 pb-4">
            <div className="flex items-center gap-2">
              <Fingerprint className="w-5 h-5 text-indigo-500" />
              <CardTitle className="text-lg">Authentication Policies</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="pt-6 space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium text-slate-900">Require MFA</div>
                <div className="text-sm text-slate-500">Enforce hardware keys or TOTP</div>
              </div>
              <div className="w-10 h-5 bg-indigo-500 rounded-full relative">
                <div className="w-4 h-4 bg-white rounded-full absolute right-0.5 top-0.5"></div>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium text-slate-900">Session Timeout</div>
                <div className="text-sm text-slate-500">Idle timeout duration</div>
              </div>
              <select className="border-slate-200 rounded p-1 text-sm bg-slate-50">
                <option>4 Hours</option>
                <option>12 Hours</option>
                <option selected>24 Hours</option>
              </select>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium text-slate-900">IP Allowlist</div>
                <div className="text-sm text-slate-500">Restrict access by CIDR</div>
              </div>
              <Button variant="outline" size="sm">Manage IPs</Button>
            </div>
          </CardContent>
        </Card>

        {/* Roles & ABAC */}
        <Card className="md:col-span-2 lg:col-span-3 border-slate-200 shadow-sm mt-4">
          <CardHeader className="border-b border-slate-100 bg-slate-50/50 pb-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-indigo-500" />
                <CardTitle className="text-lg">Role & Attribute Based Access Control (ABAC)</CardTitle>
              </div>
              <Button size="sm" className="bg-indigo-600">Create Custom Role</Button>
            </div>
          </CardHeader>
          <CardContent className="pt-6">
             <div className="overflow-x-auto">
               <table className="w-full text-sm text-left">
                 <thead className="text-xs text-slate-500 uppercase bg-slate-50 border-b border-slate-200">
                   <tr>
                     <th className="px-6 py-3">Role Name</th>
                     <th className="px-6 py-3">Type</th>
                     <th className="px-6 py-3">Assigned Users</th>
                     <th className="px-6 py-3">ABAC Conditions</th>
                     <th className="px-6 py-3">Actions</th>
                   </tr>
                 </thead>
                 <tbody className="divide-y divide-slate-100">
                   <tr className="hover:bg-slate-50">
                     <td className="px-6 py-4 font-bold text-slate-900">Organization Admin</td>
                     <td className="px-6 py-4"><span className="px-2 py-1 bg-rose-100 text-rose-700 rounded text-xs font-semibold">System</span></td>
                     <td className="px-6 py-4 font-medium text-slate-600">3 Users</td>
                     <td className="px-6 py-4 text-slate-500">None (Global Access)</td>
                     <td className="px-6 py-4"><Button variant="ghost" size="sm">Edit</Button></td>
                   </tr>
                   <tr className="hover:bg-slate-50">
                     <td className="px-6 py-4 font-bold text-slate-900">Product Manager</td>
                     <td className="px-6 py-4"><span className="px-2 py-1 bg-indigo-100 text-indigo-700 rounded text-xs font-semibold">Custom</span></td>
                     <td className="px-6 py-4 font-medium text-slate-600">42 Users</td>
                     <td className="px-6 py-4 text-slate-500"><code className="bg-slate-100 px-1 py-0.5 rounded text-xs">resource.team == user.team</code></td>
                     <td className="px-6 py-4"><Button variant="ghost" size="sm">Edit</Button></td>
                   </tr>
                   <tr className="hover:bg-slate-50">
                     <td className="px-6 py-4 font-bold text-slate-900">External Vendor</td>
                     <td className="px-6 py-4"><span className="px-2 py-1 bg-amber-100 text-amber-700 rounded text-xs font-semibold">Custom</span></td>
                     <td className="px-6 py-4 font-medium text-slate-600">12 Users</td>
                     <td className="px-6 py-4 text-slate-500"><code className="bg-slate-100 px-1 py-0.5 rounded text-xs">resource.type == 'Public'</code></td>
                     <td className="px-6 py-4"><Button variant="ghost" size="sm">Edit</Button></td>
                   </tr>
                 </tbody>
               </table>
             </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
