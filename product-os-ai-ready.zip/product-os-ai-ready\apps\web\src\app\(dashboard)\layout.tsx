import React from 'react';
import Link from 'next/link';
import { AIAdvisorDrawer } from '@/components/shared/AIAdvisorDrawer';
import { InvestorTour } from '@/components/shared/InvestorTour';
import { DemoProvider } from '@/store/demo-context';

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <DemoProvider>
      <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <aside className="w-64 border-r bg-card flex flex-col">
        <div className="h-16 flex items-center px-6 border-b font-semibold text-lg text-primary">
          ProductOS AI
        </div>
        <nav className="flex-1 overflow-y-auto py-4">
          <ul className="space-y-1 px-3 pb-8">
            <li className="pt-2 pb-1 px-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Home</li>
            <li>
              <Link href="/" className="flex items-center gap-3 px-3 py-2 rounded-md hover:bg-muted text-sm font-medium text-indigo-600">
                Command Center
              </Link>
            </li>
            <li>
              <Link href="/control-tower" className="flex items-center gap-3 px-3 py-2 rounded-md hover:bg-muted text-sm font-medium">
                PM Control Tower
              </Link>
            </li>

            <li className="pt-4 pb-1 px-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Product & Strategy</li>
            <li>
              <Link href="/strategy" className="flex items-center gap-3 px-3 py-2 rounded-md hover:bg-muted text-sm font-medium">
                Strategy
              </Link>
            </li>
            <li>
              <Link href="/documents" className="flex items-center gap-3 px-3 py-2 rounded-md hover:bg-muted text-sm font-medium">
                Requirements & Docs
              </Link>
            </li>

            <li className="pt-4 pb-1 px-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Planning</li>
            <li>
              <Link href="/roadmap-command" className="flex items-center gap-3 px-3 py-2 rounded-md hover:bg-muted text-sm font-medium">
                Roadmap Command
              </Link>
            </li>
            <li>
              <Link href="/workflow-studio" className="flex items-center gap-3 px-3 py-2 rounded-md hover:bg-muted text-sm font-medium">
                Workflow Studio
              </Link>
            </li>

            <li className="pt-4 pb-1 px-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Execution</li>
            <li>
              <Link href="/execution" className="flex items-center gap-3 px-3 py-2 rounded-md hover:bg-muted text-sm font-medium">
                Project Workspace
              </Link>
            </li>
            <li>
              <Link href="/approvals" className="flex items-center justify-between px-3 py-2 rounded-md hover:bg-muted text-sm font-medium text-amber-600">
                <span>Approvals</span> <span className="bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full text-xs">2</span>
              </Link>
            </li>

            <li className="pt-4 pb-1 px-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Team & Comms</li>
            <li>
              <Link href="/teams" className="flex items-center gap-3 px-3 py-2 rounded-md hover:bg-muted text-sm font-medium">
                Team Management
              </Link>
            </li>
            <li>
              <Link href="/communication" className="flex items-center gap-3 px-3 py-2 rounded-md hover:bg-muted text-sm font-medium">
                Communication Hub
              </Link>
            </li>

            <li className="pt-4 pb-1 px-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Intelligence & Admin</li>
            <li>
              <Link href="/knowledge-center" className="flex items-center gap-3 px-3 py-2 rounded-md hover:bg-muted text-sm font-medium">
                Knowledge Center
              </Link>
            </li>
            <li>
              <Link href="/performance" className="flex items-center gap-3 px-3 py-2 rounded-md hover:bg-muted text-sm font-medium">
                Performance Ops
              </Link>
            </li>
            <li>
              <Link href="/administration" className="flex items-center gap-3 px-3 py-2 rounded-md hover:bg-muted text-sm font-medium">
                Administration
              </Link>
            </li>
            <li className="pt-4 pb-1 px-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Enterprise Readiness</li>
            <li>
              <Link href="/governance/identity" className="flex items-center gap-3 px-3 py-2 rounded-md hover:bg-muted text-sm font-medium">
                Identity & Access
              </Link>
            </li>
            <li>
              <Link href="/governance/compliance" className="flex items-center gap-3 px-3 py-2 rounded-md hover:bg-muted text-sm font-medium">
                Compliance Center
              </Link>
            </li>
            <li>
              <Link href="/governance/audit" className="flex items-center gap-3 px-3 py-2 rounded-md hover:bg-muted text-sm font-medium">
                Audit Command
              </Link>
            </li>
            <li>
              <Link href="/integrations" className="flex items-center gap-3 px-3 py-2 rounded-md hover:bg-muted text-sm font-medium">
                Integration Marketplace
              </Link>
            </li>
            <li>
              <Link href="/migration" className="flex items-center gap-3 px-3 py-2 rounded-md hover:bg-muted text-sm font-medium">
                Migration Center
              </Link>
            </li>
          </ul>
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <header className="h-16 flex items-center justify-between px-6 border-b bg-background">
          <div className="text-sm text-muted-foreground flex-1 cursor-text bg-slate-100 px-4 py-2 rounded-md max-w-md">Search Everything (Cmd+K)</div>
          <div className="flex items-center gap-4">
            <div className="w-8 h-8 rounded-full bg-indigo-200"></div>
          </div>
        </header>
        <div className="flex-1 overflow-y-auto bg-slate-50/50">
          {children}
        </div>
      </main>

      {/* Global AI Advisor */}
      <AIAdvisorDrawer />
      <InvestorTour />
    </div>
    </DemoProvider>
  );
}
