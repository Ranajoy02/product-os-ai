'use client';

import { useState } from 'react';
import { Button } from './ui/button';

export function AICopilotDrawer() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{role: 'user' | 'ai', content: string}[]>([
    { role: 'ai', content: 'Hi there! I am ProductOS AI. You can ask me to analyze a PRD, summarize blocked tasks, or estimate timelines based on team velocity.' }
  ]);
  const [input, setInput] = useState('');

  const toggleDrawer = () => setIsOpen(!isOpen);

  const handleSend = () => {
    if (!input.trim()) return;
    setMessages([...messages, { role: 'user', content: input }]);
    setInput('');
    
    // Mock AI response
    setTimeout(() => {
      setMessages(prev => [...prev, { role: 'ai', content: "I've analyzed the request. I found 3 related tickets in 'Project Alpha'. Would you like me to draft an update?" }]);
    }, 1000);
  };

  return (
    <>
      {/* Floating Action Button for AI if sidebar is collapsed, or just relying on sidebar button */}
      <div 
        className={`fixed top-0 right-0 h-full w-96 bg-background border-l shadow-2xl transform transition-transform duration-300 z-50 flex flex-col ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}
      >
        <div className="h-16 border-b flex items-center justify-between px-6 bg-indigo-50/50">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground text-xs font-bold">AI</div>
            <h2 className="font-semibold text-primary">AI Copilot</h2>
          </div>
          <button onClick={toggleDrawer} className="text-muted-foreground hover:text-foreground">
            ✕
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50/50">
          {messages.map((msg, i) => (
            <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[85%] p-3 rounded-lg text-sm ${msg.role === 'user' ? 'bg-primary text-primary-foreground' : 'bg-white border shadow-sm text-foreground'}`}>
                {msg.content}
              </div>
            </div>
          ))}
        </div>

        <div className="p-4 border-t bg-background">
          <div className="flex gap-2">
            <input 
              type="text" 
              placeholder="Ask AI Copilot..." 
              className="flex-1 border rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            />
            <Button onClick={handleSend} size="sm">Send</Button>
          </div>
        </div>
      </div>

      {/* Inject a global listener or context to open this drawer. For simplicity, we expose a button here if needed, or we attach it to the window. */}
      {!isOpen && (
        <button 
          onClick={toggleDrawer}
          className="fixed bottom-6 right-6 w-14 h-14 bg-primary text-primary-foreground rounded-full shadow-lg flex items-center justify-center hover:bg-primary/90 transition-colors z-40"
        >
          AI
        </button>
      )}
    </>
  );
}
