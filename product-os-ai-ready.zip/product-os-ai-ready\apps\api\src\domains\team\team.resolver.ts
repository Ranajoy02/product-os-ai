import {
  Resolver,
  Query,
  ObjectType,
  Field,
  ID,
  Float,
  Args,
} from '@nestjs/graphql';
import { TeamService } from './team.service';

@ObjectType()
export class User {
  @Field(() => ID)
  id: string;

  @Field()
  email: string;

  @Field({ nullable: true })
  firstName?: string;

  @Field({ nullable: true })
  lastName?: string;

  @Field()
  role: string;
}

@ObjectType()
export class TeamMember {
  @Field(() => ID)
  id: string;

  @Field(() => [String])
  skills: string[];

  @Field(() => User)
  user: User;
}

@ObjectType()
export class Team {
  @Field(() => ID)
  id: string;

  @Field()
  name: string;

  @Field(() => Float)
  capacity: number;

  @Field(() => Float)
  velocity: number;

  @Field(() => Float)
  utilization: number;

  @Field(() => [TeamMember], { nullable: 'itemsAndList' })
  members?: TeamMember[];
}

@Resolver(() => Team)
export class TeamResolver {
  constructor(private teamService: TeamService) {}

  @Query(() => [Team])
  async getTeams() {
    return this.teamService.getTeams();
  }

  @Query(() => Team, { nullable: true })
  async getTeam(@Args('id', { type: () => ID }) id: string) {
    return this.teamService.getTeam(id);
  }
}
