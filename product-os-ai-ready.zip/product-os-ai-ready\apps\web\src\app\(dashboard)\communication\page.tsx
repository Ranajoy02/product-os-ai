"use client";
import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useQuery } from '@apollo/experimental-nextjs-app-support/ssr';
import { gql } from '@apollo/client';
import { 
  Bell,
  Hash,
  MessageSquare,
  MoreVertical,
  Paperclip,
  Search,
  Send,
  Smile,
  Users,
  LayoutDashboard
} from 'lucide-react';

const GET_CHANNELS = gql`
  query GetChannels {
    channels {
      id
      name
      type
    }
  }
`;

const GET_MESSAGES = gql`
  query GetMessages($channelId: ID!) {
    messages(channelId: $channelId) {
      id
      content
      senderId
    }
  }
`;

export default function Communication() {
  const { data: channelsData, loading: channelsLoading } = useQuery<any>(GET_CHANNELS);
  const [activeChannelId, setActiveChannelId] = useState<string | null>(null);

  const channels = channelsData?.channels || [];
  const projectChannels = channels.filter((c: any) => c.type !== 'DIRECT_MESSAGE');
  const directMessages = channels.filter((c: any) => c.type === 'DIRECT_MESSAGE');

  useEffect(() => {
    if (channels.length > 0 && !activeChannelId) {
      setActiveChannelId(channels[0].id);
    }
  }, [channels, activeChannelId]);

  const { data: messagesData, loading: messagesLoading } = useQuery<any>(GET_MESSAGES, {
    variables: { channelId: activeChannelId },
    skip: !activeChannelId,
  });

  const activeChannel = channels.find((c: any) => c.id === activeChannelId);

  return (
    <div className="flex h-[calc(100vh-4rem)]">
      {/* Sidebar */}
      <div className="w-64 border-r bg-slate-50 flex flex-col">
        <div className="p-4 border-b">
          <h2 className="font-semibold text-lg text-slate-900">Workspace Chat</h2>
        </div>
        
        <div className="p-3">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-500" />
            <Input placeholder="Search messages..." className="pl-9 bg-white h-9 text-sm" />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-3 space-y-6">
          {channelsLoading ? (
            <p className="text-sm text-slate-500 px-2">Loading channels...</p>
          ) : (
            <>
              <div>
                <div className="flex items-center justify-between px-2 mb-2">
                  <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Project Channels</span>
                  <Button variant="ghost" size="sm" className="h-4 w-4 p-0 text-slate-400 hover:text-slate-900">+</Button>
                </div>
                <ul className="space-y-0.5">
                  {projectChannels.map((c: any) => (
                    <li key={c.id}>
                      <button 
                        onClick={() => setActiveChannelId(c.id)}
                        className={`w-full flex items-center gap-2 px-2 py-1.5 rounded-md text-sm font-medium ${
                          activeChannelId === c.id 
                            ? 'bg-indigo-100 text-indigo-700' 
                            : 'hover:bg-slate-200 text-slate-700'
                        }`}
                      >
                        <Hash className="h-4 w-4" />
                        {c.name}
                      </button>
                    </li>
                  ))}
                  {projectChannels.length === 0 && (
                     <li className="text-xs text-slate-500 px-2">No project channels</li>
                  )}
                </ul>
              </div>

              <div>
                <div className="flex items-center justify-between px-2 mb-2">
                  <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Direct Messages</span>
                  <Button variant="ghost" size="sm" className="h-4 w-4 p-0 text-slate-400 hover:text-slate-900">+</Button>
                </div>
                <ul className="space-y-0.5">
                  {directMessages.map((c: any) => (
                     <li key={c.id}>
                     <button 
                       onClick={() => setActiveChannelId(c.id)}
                       className={`w-full flex items-center gap-2 px-2 py-1.5 rounded-md text-sm font-medium ${
                         activeChannelId === c.id 
                           ? 'bg-indigo-100 text-indigo-700' 
                           : 'hover:bg-slate-200 text-slate-700'
                       }`}
                     >
                       <div className="relative">
                         <div className="w-5 h-5 rounded bg-blue-200 text-blue-700 flex items-center justify-center text-xs">
                           {c.name.charAt(0).toUpperCase()}
                         </div>
                         <div className="absolute -bottom-0.5 -right-0.5 w-2 h-2 bg-emerald-500 border border-white rounded-full"></div>
                       </div>
                       {c.name}
                     </button>
                   </li>
                  ))}
                  {directMessages.length === 0 && (
                     <li className="text-xs text-slate-500 px-2">No direct messages</li>
                  )}
                </ul>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col bg-white">
        {/* Chat Header */}
        <div className="h-14 border-b flex items-center justify-between px-6 bg-white">
          {activeChannel ? (
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-slate-900 flex items-center gap-1">
                {activeChannel.type === 'DIRECT_MESSAGE' ? '@' : <Hash className="h-5 w-5 text-slate-400" />}
                {activeChannel.name}
              </h3>
            </div>
          ) : (
            <div className="flex items-center gap-2">
               <h3 className="font-bold text-slate-900">Select a channel</h3>
            </div>
          )}
          
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" className="text-slate-500">
              <Bell className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm" className="text-slate-500">
              <MoreVertical className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {messagesLoading && <p className="text-sm text-slate-500 text-center">Loading messages...</p>}
          
          {!messagesLoading && messagesData?.messages?.length === 0 && (
             <div className="flex flex-col items-center justify-center h-full text-slate-400">
               <MessageSquare className="w-12 h-12 mb-4 opacity-20" />
               <p>No messages yet in this channel.</p>
             </div>
          )}

          {!messagesLoading && messagesData?.messages?.map((msg: any) => (
             <div key={msg.id} className="flex gap-4 group">
               <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center text-blue-700 font-bold shrink-0">
                 {msg.senderId ? msg.senderId.slice(0, 2).toUpperCase() : 'U'}
               </div>
               <div className="flex-1">
                 <div className="flex items-baseline gap-2">
                   <span className="font-semibold text-slate-900">{msg.senderId || 'Unknown User'}</span>
                 </div>
                 <p className="text-slate-700 mt-1 leading-relaxed">
                   {msg.content}
                 </p>
               </div>
             </div>
          ))}

          {/* Hardcoded Sample UI to show original styling on blank state */}
          {!messagesLoading && messagesData?.messages?.length === 0 && (
             <div className="opacity-40 pointer-events-none mt-10 border-t pt-10">
                <p className="text-xs text-center text-slate-400 mb-6">Sample UI Placeholder</p>
                <div className="flex gap-4 group">
                  <div className="w-10 h-10 rounded-lg bg-indigo-600 flex items-center justify-center text-white font-bold shrink-0">AI</div>
                  <div className="flex-1">
                    <div className="flex items-baseline gap-2">
                      <span className="font-semibold text-slate-900">ProductOS AI</span>
                      <span className="bg-indigo-100 text-indigo-700 text-[10px] px-1.5 py-0.5 rounded font-bold uppercase tracking-wider">Assistant</span>
                    </div>
                    <p className="text-slate-700 mt-1 leading-relaxed">
                      I've analyzed the conversation and automatically linked the Figma file. Would you like me to draft the user stories?
                    </p>
                  </div>
                </div>
             </div>
          )}
        </div>

        {/* Message Input */}
        <div className="p-4 bg-white border-t">
          <div className="flex flex-col border border-slate-300 rounded-lg shadow-sm focus-within:ring-1 focus-within:ring-indigo-500 focus-within:border-indigo-500 bg-white">
            <textarea 
              className="w-full p-3 resize-none outline-none max-h-32 min-h-[80px] text-sm text-slate-900 rounded-t-lg bg-transparent"
              placeholder={activeChannel ? `Message ${activeChannel.type === 'DIRECT_MESSAGE' ? '@' : '#'}${activeChannel.name}...` : "Select a channel..."}
              disabled={!activeChannel}
            />
            <div className="flex items-center justify-between p-2 bg-slate-50 rounded-b-lg border-t border-slate-100">
              <div className="flex items-center gap-1">
                <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-slate-500 hover:text-slate-700">
                  <Paperclip className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-slate-500 hover:text-slate-700">
                  <Smile className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-slate-500 hover:text-slate-700 font-bold font-serif italic">
                  @
                </Button>
              </div>
              <Button size="sm" className="h-8 bg-indigo-600 hover:bg-indigo-700 px-3 flex gap-2" disabled={!activeChannel}>
                Send <Send className="w-3 h-3" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
