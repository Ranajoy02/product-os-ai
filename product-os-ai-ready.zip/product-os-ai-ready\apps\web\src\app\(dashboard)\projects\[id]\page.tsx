import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const MOCK_TASKS = {
  BACKLOG: [{ id: '1', title: 'Setup database' }],
  READY: [{ id: '2', title: 'Build auth API' }],
  IN_PROGRESS: [{ id: '3', title: 'Kanban UI UI' }],
  REVIEW: [{ id: '4', title: 'Login Screen' }],
  COMPLETED: [{ id: '5', title: 'Project Scaffold' }]
};

export default function KanbanBoardPage() {
  return (
    <div className="p-8 h-full flex flex-col">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Project Alpha</h1>
          <p className="text-muted-foreground">Sprint 2 • Ends in 4 days</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline">AI Analyze Timeline</Button>
          <Button>Add Task</Button>
        </div>
      </div>

      <div className="flex-1 flex gap-4 overflow-x-auto pb-4">
        {Object.entries(MOCK_TASKS).map(([column, tasks]) => (
          <div key={column} className="flex flex-col w-80 shrink-0 bg-slate-100/50 rounded-lg p-3">
            <div className="flex items-center justify-between mb-3 px-1">
              <h3 className="font-semibold text-sm text-slate-700">{column.replace('_', ' ')}</h3>
              <span className="text-xs text-muted-foreground">{tasks.length}</span>
            </div>
            <div className="space-y-3 flex-1 overflow-y-auto">
              {tasks.map(task => (
                <Card key={task.id} className="cursor-grab hover:border-primary transition-colors">
                  <CardContent className="p-4">
                    <p className="font-medium text-sm">{task.title}</p>
                    <div className="mt-3 flex items-center justify-between">
                      <div className="text-xs text-muted-foreground">T-{task.id}</div>
                      <div className="w-6 h-6 rounded-full bg-slate-200"></div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            <Button variant="ghost" className="w-full mt-3 text-muted-foreground justify-start">+ Add card</Button>
          </div>
        ))}
      </div>
    </div>
  );
}
