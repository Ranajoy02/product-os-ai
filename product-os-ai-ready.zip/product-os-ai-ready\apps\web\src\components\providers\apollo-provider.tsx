'use client';

import React, { ReactNode } from 'react';
import { HttpLink } from '@apollo/client';
import { ApolloNextAppProvider, NextSSRApolloClient, NextSSRInMemoryCache } from '@apollo/experimental-nextjs-app-support/ssr';

function makeClient() {
  const uri = process.env.NEXT_PUBLIC_GRAPHQL_URI || 'http://localhost:3001/graphql';
  return new NextSSRApolloClient({
    cache: new NextSSRInMemoryCache(),
    link: new HttpLink({ uri }),
  });
}

export function ApolloProvider({ children }: { children: ReactNode }) {
  return (
    <ApolloNextAppProvider makeClient={makeClient}>
      {children}
    </ApolloNextAppProvider>
  );
}
