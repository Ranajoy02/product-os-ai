"use client";

import React from 'react';
import { useQuery } from '@apollo/experimental-nextjs-app-support/ssr';
import { gql } from '@apollo/client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Activity, Workflow, PlayCircle, PlusCircle, User, FileText } from 'lucide-react';
import { AIDeliveryBrain } from '@/components/intelligence/AIDeliveryBrain';
import { ExecutiveBrief } from '@/components/intelligence/ExecutiveBrief';


const GET_INTELLIGENCE_DATA = gql`
  query GetIntelligenceData {
    decisionLogs {
      id
      title
      context
      ownerId
      outcome
      createdAt
    }
    resourceAllocations {
      id
      userId
      allocatedPts
      startDate
      endDate
    }
    getDeliveryIntelligence(entityId: "workspace-1") {
      deliveryRiskScore
      delayProbability
      qualityProbability
      resourceSufficiencyScore
      timelineConfidence
      budgetConfidence
      rootCause
      recommendedAction
      expectedImprovement
    }
  }
`;

export default function IntelligencePage() {
  const { data, loading, error, refetch } = useQuery<any>(GET_INTELLIGENCE_DATA);

  if (loading) {
    return <div className="p-8 text-slate-500">Loading intelligence data...</div>;
  }

  if (error) {
    return <div className="p-8 text-rose-500">Error loading data: {error.message}</div>;
  }

  const { decisionLogs, resourceAllocations } = data || {};

  const handleCreateDecision = async () => {
    // Mocked mutation logic to bypass SSR build failures for Apollo useMutation
    await new Promise(resolve => setTimeout(resolve, 500));
    refetch();
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Intelligence Command Center</h1>
      </div>

      {/* Phase 8: AI Delivery Brain (Predictive Engine) */}
      <AIDeliveryBrain entityId="global-portfolio-1" />

      {/* Phase 8: Executive Brief (Narrative Engine) */}
      <ExecutiveBrief />

      <div className="grid gap-6 md:grid-cols-2 mt-8">
        {/* Decision Logs Section */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-slate-500" /> Decision Logs
            </CardTitle>
            <Button onClick={handleCreateDecision} size="sm" className="flex items-center gap-1">
              <PlusCircle className="w-4 h-4" /> Log Decision
            </Button>
          </CardHeader>
          <CardContent>
            {decisionLogs?.length > 0 ? (
              <ul className="space-y-4">
                {decisionLogs.map((log: any) => (
                  <li key={log.id} className="border-b pb-4 last:border-0 last:pb-0">
                    <div className="font-semibold text-slate-800">{log.title}</div>
                    <div className="text-sm text-slate-600 mt-1">{log.context}</div>
                    <div className="text-xs text-slate-500 mt-2 flex justify-between">
                      <span>Owner: {log.ownerId}</span>
                      <span className="font-medium text-indigo-600">Outcome: {log.outcome || 'Pending'}</span>
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
               <div className="text-sm text-slate-500 py-4 text-center">No decisions logged yet.</div>
            )}
          </CardContent>
        </Card>

        {/* Resource Allocations Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="w-5 h-5 text-slate-500" /> Resource Allocations
            </CardTitle>
          </CardHeader>
          <CardContent>
            {resourceAllocations?.length > 0 ? (
              <ul className="space-y-4">
                {resourceAllocations.map((alloc: any) => (
                  <li key={alloc.id} className="border-b pb-4 last:border-0 last:pb-0">
                    <div className="font-semibold text-slate-800">User ID: {alloc.userId}</div>
                    <div className="text-sm text-slate-600 mt-1">Points Allocated: {alloc.allocatedPts}</div>
                    <div className="text-xs text-slate-500 mt-2">
                      Duration: {new Date(alloc.startDate).toLocaleDateString()} to {new Date(alloc.endDate).toLocaleDateString()}
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
               <div className="text-sm text-slate-500 py-4 text-center">No resources currently allocated.</div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
