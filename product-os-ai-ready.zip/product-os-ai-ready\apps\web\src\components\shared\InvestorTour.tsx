'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useRouter, usePathname } from 'next/navigation';
import { useDemoContext } from '../../store/demo-context';
import { PlayCircle, SkipForward, ArrowRight, X } from 'lucide-react';
import { useAIContext } from '../../store/ai-context';

const TOUR_STEPS = [
  { path: '/', title: 'Delivery Intelligence Center', desc: 'Observe global health, blocked tasks, and active narratives at a glance. Notice the Business Impact Layer quantifying risks.' },
  { path: '/workflow-studio', title: 'Workflow Studio', desc: 'Analyze bottlenecks. The AI has detected QA Review is overflowing capacity. Toggle the heatmap to see structural flaws.' },
  { path: '/roadmap-command', title: 'Roadmap Command Center', desc: 'Forecast dependencies. The blocked JWT task cascades a 4-day delay onto the Q3 Security strategic goal.' },
  { path: '/knowledge-center', title: 'Knowledge Center', desc: 'Trace semantic lineage. The entire delivery chain from PRD to Release is mapped to guarantee compliance.' },
  { path: 'advisor', title: 'AI Delivery Advisor', desc: 'Consult the AI. Ask preconfigured Executive Questions to get instant, deterministic analysis on business risks.' }
];

export function InvestorTour() {
  const router = useRouter();
  const pathname = usePathname();
  const { isDemoMode, activeNarrative, setNarrative } = useDemoContext();
  const { toggleAdvisor } = useAIContext();
  const [tourActive, setTourActive] = useState(false);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);

  if (!isDemoMode) return null;

  const handleNext = () => {
    if (currentStepIndex < TOUR_STEPS.length - 1) {
      const nextIdx = currentStepIndex + 1;
      const step = TOUR_STEPS[nextIdx];
      
      setCurrentStepIndex(nextIdx);
      
      if (step.path === 'advisor') {
        toggleAdvisor();
      } else {
        router.push(step.path);
      }
    } else {
      setTourActive(false);
      setCurrentStepIndex(0);
    }
  };

  const startTour = () => {
    setTourActive(true);
    setCurrentStepIndex(0);
    router.push(TOUR_STEPS[0].path);
  };

  return (
    <>
      {!tourActive && (
        <button 
          onClick={startTour}
          className="fixed bottom-6 left-6 bg-emerald-600 text-white px-4 py-2 rounded-full shadow-lg flex items-center gap-2 hover:bg-emerald-500 transition-colors z-40 text-sm font-medium"
        >
          <PlayCircle className="w-4 h-4" /> Start Investor Tour
        </button>
      )}

      <AnimatePresence>
        {tourActive && (
          <motion.div 
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 100, opacity: 0 }}
            className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-slate-900 border border-slate-700 text-white p-5 rounded-xl shadow-2xl z-50 w-[500px]"
          >
            <div className="flex justify-between items-start mb-3">
              <div>
                <div className="text-emerald-400 text-xs font-bold uppercase tracking-wider mb-1">
                  Step {currentStepIndex + 1} of {TOUR_STEPS.length}
                </div>
                <h3 className="font-semibold text-lg">{TOUR_STEPS[currentStepIndex].title}</h3>
              </div>
              <button onClick={() => setTourActive(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <p className="text-sm text-slate-300 leading-relaxed mb-6">
              {TOUR_STEPS[currentStepIndex].desc}
            </p>

            <div className="flex items-center justify-between border-t border-slate-700 pt-4">
              <select 
                className="bg-slate-800 border-slate-700 rounded text-xs px-2 py-1 text-slate-300"
                value={activeNarrative}
                onChange={(e) => setNarrative(e.target.value as any)}
              >
                <option value="enterprise_saas">Scenario: Enterprise SaaS</option>
                <option value="security_incident">Scenario: Security Incident</option>
                <option value="ai_launch">Scenario: AI Product Launch</option>
              </select>

              <button 
                onClick={handleNext}
                className="bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded flex items-center gap-2 text-sm font-medium transition-colors"
              >
                {currentStepIndex === TOUR_STEPS.length - 1 ? 'Finish Tour' : 'Next Step'} <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
