import { DemoNarrative } from './demo-context';

export const DemoData: Record<DemoNarrative, any> = {
  enterprise_saas: {
    name: 'Enterprise SaaS Launch',
    health: 89,
    blockedTasks: 3,
    pendingApprovals: 2,
    delayedReleases: 1,
    aiAnswers: {
      'Why is this release delayed?': 'The "Enterprise SSO" epic is delayed because the external security audit took 4 days longer than expected.',
      'Which team is overloaded?': 'The Security team is operating at 115% capacity, causing a bottleneck in the QA/Review step.',
      'What is the highest roadmap risk?': 'The Q3 Compliance Certification is at high risk because the SSO task is blocking the final release package.',
      'What approvals are blocking delivery?': 'The "CISO Sign-off" on the Security Audit approval step is pending.',
      'What is the projected business impact?': 'If delayed past Friday, the Enterprise Tier launch will miss the primary marketing window, potentially impacting Q3 enterprise sales targets by 15%.'
    }
  },
  security_incident: {
    name: 'Security Incident Response',
    health: 42,
    blockedTasks: 12,
    pendingApprovals: 5,
    delayedReleases: 3,
    aiAnswers: {
      'Why is this release delayed?': 'All feature work was halted to patch the zero-day vulnerability in the database authentication layer.',
      'Which team is overloaded?': 'The DevSecOps team is overwhelmed, handling 14 critical incident response tasks concurrently.',
      'What is the highest roadmap risk?': 'All Q3 feature roadmap goals are frozen until the incident is fully resolved and post-mortem is approved.',
      'What approvals are blocking delivery?': 'The emergency hotfix requires immediate VP Engineering approval.',
      'What is the projected business impact?': 'SLA breaches may result in $120k in customer credits if the patch is not deployed within 4 hours.'
    }
  },
  ai_launch: {
    name: 'AI Product Launch',
    health: 95,
    blockedTasks: 0,
    pendingApprovals: 1,
    delayedReleases: 0,
    aiAnswers: {
      'Why is this release delayed?': 'This release is not delayed. It is currently tracking 2 days ahead of schedule.',
      'Which team is overloaded?': 'No teams are overloaded. The ML Engineering team has balanced capacity at 78%.',
      'What is the highest roadmap risk?': 'The only minor risk is API rate limiting from OpenAI if the launch traffic exceeds 10,000 req/min.',
      'What approvals are blocking delivery?': 'Final Legal Review of the AI Terms of Service is the last remaining gate.',
      'What is the projected business impact?': 'On-time delivery will unlock the new AI-tier pricing, projecting a 22% increase in ARPU for Q4.'
    }
  }
};
