'use client';

import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Network, Activity, Clock, AlertTriangle, Zap, CheckCircle2, ArrowRight } from 'lucide-react';
import { gql } from '@apollo/client';
import { useQuery } from '@apollo/experimental-nextjs-app-support/ssr';


const GET_INTEGRATIONS = gql`
  query GetIntegrationStates {
    connectionStatuses {
      id
      provider
      status
      lastSyncAt
      errorMessage
    }
  }
`;

export default function IntegrationsMarketplace() {
  const { data, loading, error } = useQuery<any>(GET_INTEGRATIONS);
  const [activeSimulation, setActiveSimulation] = useState<string | null>(null);

  if (loading) return <div className="p-8 text-slate-500 animate-pulse">Loading Integration Marketplace...</div>;
  if (error) return <div className="p-8 text-rose-500">Error: {error.message}</div>;

  const integrations = data?.connectionStatuses || [];

  const getIcon = (provider: string) => {
    switch(provider) {
      case 'GitHub': return <div className="w-10 h-10 bg-slate-900 rounded-lg flex items-center justify-center text-white font-bold">GH</div>;
      case 'Slack': return <div className="w-10 h-10 bg-[#E01E5A] rounded-lg flex items-center justify-center text-white font-bold">SL</div>;
      case 'Salesforce': return <div className="w-10 h-10 bg-[#00A1E0] rounded-lg flex items-center justify-center text-white font-bold">SF</div>;
      case 'Figma': return <div className="w-10 h-10 bg-[#F24E1E] rounded-lg flex items-center justify-center text-white font-bold">FG</div>;
      case 'Jira': return <div className="w-10 h-10 bg-[#0052CC] rounded-lg flex items-center justify-center text-white font-bold">JR</div>;
      default: return <div className="w-10 h-10 bg-indigo-500 rounded-lg flex items-center justify-center text-white font-bold">{provider.substring(0,2)}</div>;
    }
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Integration Marketplace</h1>
        <p className="text-slate-500 mt-1">Manage external connections, monitor sync health, and orchestrate automated event flows.</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
        {integrations.map((integration: any) => (
          <Card key={integration.id} className="border-slate-200 shadow-sm flex flex-col group hover:border-indigo-300 transition-colors">
            <CardHeader className="flex flex-row items-start justify-between pb-2 border-b border-slate-100 bg-slate-50/50">
              <div className="flex items-center gap-3">
                {getIcon(integration.provider)}
                <div>
                  <CardTitle className="text-lg">{integration.provider}</CardTitle>
                  <div className="flex items-center gap-1 mt-1">
                    <span className={`w-2 h-2 rounded-full ${integration.status === 'Connected' ? 'bg-emerald-500' : 'bg-rose-500'}`}></span>
                    <span className="text-xs font-semibold text-slate-500">{integration.status}</span>
                  </div>
                </div>
              </div>
              <Button 
                variant="outline" 
                size="sm" 
                className="bg-white"
                onClick={() => setActiveSimulation(integration.provider)}
              >
                Simulate Flow
              </Button>
            </CardHeader>
            <CardContent className="pt-4 flex-1">
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div>
                  <div className="text-xs text-slate-500 flex items-center gap-1 mb-1"><Activity className="w-3 h-3" /> Sync Health</div>
                  <div className="text-lg font-bold text-slate-900">99.9%</div>
                </div>
                <div>
                  <div className="text-xs text-slate-500 flex items-center gap-1 mb-1"><AlertTriangle className="w-3 h-3" /> Errors (24h)</div>
                  <div className="text-lg font-bold text-slate-900">0</div>
                </div>
              </div>
              
              <div className="flex items-center justify-between text-xs text-slate-500 bg-slate-50 p-2 rounded border border-slate-100">
                <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> Last Sync</span>
                <span className="font-mono">{new Date(integration.lastSync).toLocaleTimeString()}</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Simulation Dialog overlay */}
      {activeSimulation && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl overflow-hidden border border-slate-200">
            <div className="p-6 border-b border-slate-100 bg-slate-50/50">
              <h2 className="flex items-center gap-2 text-xl font-bold text-slate-900">
                <Zap className="w-5 h-5 text-indigo-500" />
                Event Flow Simulation: {activeSimulation}
              </h2>
              <p className="text-slate-500 text-sm mt-1">
                Demonstrating how ProductOS AI processes automated webhooks from {activeSimulation}.
              </p>
            </div>

            <div className="p-6">
              <div className="p-6 bg-slate-50 rounded-xl border border-slate-100">
                <div className="flex items-center justify-between relative">
                  <div className="absolute left-0 top-1/2 w-full h-0.5 bg-indigo-100 -translate-y-1/2 z-0"></div>
                  
                  {activeSimulation === 'GitHub' && (
                    <>
                      <FlowStep title="Webhook" desc="PR Merged" icon={<Network className="w-5 h-5" />} />
                      <FlowStep title="ProductOS API" desc="Parse Payload" icon={<Activity className="w-5 h-5" />} />
                      <FlowStep title="Workflow Studio" desc="Move Task -> Done" icon={<CheckCircle2 className="w-5 h-5" />} />
                      <FlowStep title="Release Gen" desc="Auto-Release Notes" icon={<Zap className="w-5 h-5" />} />
                    </>
                  )}

                  {activeSimulation === 'Slack' && (
                    <>
                      <FlowStep title="Message" desc="@ProductOS AI" icon={<Network className="w-5 h-5" />} />
                      <FlowStep title="AI Brain" desc="Intent Extraction" icon={<Activity className="w-5 h-5" />} />
                      <FlowStep title="Project Mgmt" desc="Task Created" icon={<CheckCircle2 className="w-5 h-5" />} />
                      <FlowStep title="Notification" desc="Reply in Thread" icon={<Zap className="w-5 h-5" />} />
                    </>
                  )}

                  {activeSimulation === 'Salesforce' && (
                    <>
                      <FlowStep title="Opp Closed" desc="Status: Won" icon={<Network className="w-5 h-5" />} />
                      <FlowStep title="Data Sync" desc="Fetch Custom Fields" icon={<Activity className="w-5 h-5" />} />
                      <FlowStep title="Roadmap Cmd" desc="Create Initiative" icon={<CheckCircle2 className="w-5 h-5" />} />
                      <FlowStep title="Notification" desc="Alert PM Team" icon={<Zap className="w-5 h-5" />} />
                    </>
                  )}

                  {!['GitHub', 'Slack', 'Salesforce'].includes(activeSimulation || '') && (
                    <div className="w-full text-center text-slate-500 z-10 bg-slate-50 py-4 font-medium">
                      Standard bi-directional sync initiated...
                    </div>
                  )}
                </div>
              </div>
              
              <div className="mt-6 flex justify-end">
                 <Button onClick={() => setActiveSimulation(null)}>Close Simulation</Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function FlowStep({ title, desc, icon }: { title: string, desc: string, icon: React.ReactNode }) {
  return (
    <div className="z-10 flex flex-col items-center bg-slate-50 px-2">
      <div className="w-12 h-12 bg-indigo-600 text-white rounded-full flex items-center justify-center shadow-lg ring-4 ring-indigo-50">
        {icon}
      </div>
      <div className="mt-3 text-center">
        <div className="text-sm font-bold text-slate-900">{title}</div>
        <div className="text-xs text-slate-500 font-medium">{desc}</div>
      </div>
    </div>
  );
}
