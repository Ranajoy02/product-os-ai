'use client';

import React from 'react';
import { useWorkspaceStore, LifecycleStage } from '@/store/workspace-context';
import { CheckCircle2, Circle, Sparkles, Clock } from 'lucide-react';

const STAGES: LifecycleStage[] = [
  'Objective', 'Business Case', 'BRD', 'PRD', 'Roadmap', 'Workflow', 
  'Resource Planning', 'Design', 'Development', 'Testing', 'Approval', 
  'Release', 'Post Release Review', 'Outcome', 'Knowledge Capture'
];

export function WorkspaceSidebar() {
  const { activeLifecycleStage, setLifecycleStage } = useWorkspaceStore();

  return (
    <div className="w-64 border-r bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 flex flex-col h-full overflow-y-auto">
      <div className="p-4 font-semibold text-sm tracking-tight border-b border-slate-100 dark:border-slate-800">
        Lifecycle Navigator
      </div>
      
      <div className="p-4 space-y-1">
        {STAGES.map((stage, idx) => {
          const isActive = activeLifecycleStage === stage;
          // Mock state logic: first 3 done, 4th active, rest pending
          const isDone = idx < 3;
          const isPending = idx > 3;

          return (
            <button
              key={stage}
              onClick={() => setLifecycleStage(stage)}
              className={`w-full flex items-center text-left px-2 py-2 rounded-md text-sm transition-colors ${
                isActive 
                  ? 'bg-indigo-50 text-indigo-700 font-medium dark:bg-indigo-950 dark:text-indigo-300' 
                  : 'text-slate-600 hover:bg-slate-50 dark:text-slate-400 dark:hover:bg-slate-800/50'
              }`}
            >
              <div className="mr-3 flex-shrink-0">
                {isDone && <CheckCircle2 className="h-4 w-4 text-emerald-500" />}
                {isActive && <Circle className="h-4 w-4 text-indigo-600 fill-indigo-600 animate-pulse" />}
                {isPending && <Circle className="h-4 w-4 text-slate-300 dark:text-slate-700" />}
              </div>
              <span className="truncate">{stage}</span>
              
              {isActive && idx === 3 && (
                <Sparkles className="h-3 w-3 ml-auto text-amber-500" />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
