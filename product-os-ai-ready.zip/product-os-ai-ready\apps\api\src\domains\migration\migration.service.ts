import { Injectable } from '@nestjs/common';
import {
  MigrationSimulation,
  FieldMapping,
  MigrationValidationResult,
  MigrationConversionStatus,
  VerificationResult,
  StartSimulationInput,
  CreateFieldMappingInput,
} from './models/migration.model';

@Injectable()
export class MigrationService {
  private simulations: MigrationSimulation[] = [
    {
      id: 'sim-1',
      status: 'COMPLETED',
      totalRecords: 10000,
      estimatedTime: '2 hours',
      predictedErrors: 15,
    },
  ];

  private mappings: FieldMapping[] = [
    {
      id: 'map-1',
      sourceField: 'first_name',
      targetField: 'firstName',
      confidenceScore: 0.99,
    },
  ];

  private validationResults: MigrationValidationResult[] = [
    {
      id: 'val-1',
      isValid: false,
      errors: ['Missing required field: email'],
    },
  ];

  private conversionStatuses: MigrationConversionStatus[] = [
    {
      id: 'conv-1',
      recordsProcessed: 5000,
      recordsFailed: 5,
      status: 'IN_PROGRESS',
    },
  ];

  private verificationResults: VerificationResult[] = [
    {
      id: 'ver-1',
      dataIntegrityScore: 99.9,
      status: 'VERIFIED',
    },
  ];

  async getSimulation(id: string): Promise<MigrationSimulation | undefined> {
    return this.simulations.find(s => s.id === id);
  }

  async getSimulations(): Promise<MigrationSimulation[]> {
    return this.simulations;
  }

  async startSimulation(input: StartSimulationInput): Promise<MigrationSimulation> {
    const newSim = {
      id: `sim-${Date.now()}`,
      status: 'RUNNING',
      totalRecords: 0,
      estimatedTime: 'Calculating...',
      predictedErrors: 0,
    };
    this.simulations.push(newSim);
    return newSim;
  }

  async getFieldMappings(): Promise<FieldMapping[]> {
    return this.mappings;
  }

  async createFieldMapping(input: CreateFieldMappingInput): Promise<FieldMapping> {
    const newMapping = {
      id: `map-${Date.now()}`,
      sourceField: input.sourceField,
      targetField: input.targetField,
      confidenceScore: 1.0,
    };
    this.mappings.push(newMapping);
    return newMapping;
  }

  async getValidationResult(id: string): Promise<MigrationValidationResult | undefined> {
    return this.validationResults.find(v => v.id === id);
  }

  async getConversionStatus(id: string): Promise<MigrationConversionStatus | undefined> {
    return this.conversionStatuses.find(c => c.id === id);
  }

  async getVerificationResult(id: string): Promise<VerificationResult | undefined> {
    return this.verificationResults.find(v => v.id === id);
  }
}
