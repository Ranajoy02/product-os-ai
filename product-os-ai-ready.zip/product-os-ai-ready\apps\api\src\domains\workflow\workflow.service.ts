import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../core/prisma/prisma.service';

@Injectable()
export class WorkflowService {
  constructor(private prisma: PrismaService) {}

  async getWorkflows(organizationId: string) {
    return this.prisma.workflow.findMany({
      where: { organizationId },
      include: { steps: { include: { transitions: true } } },
    });
  }

  async getWorkflow(id: string) {
    return this.prisma.workflow.findUnique({
      where: { id },
      include: { steps: { include: { transitions: true } } },
    });
  }

  async createWorkflow(
    organizationId: string,
    name: string,
    description?: string,
  ) {
    return this.prisma.workflow.create({
      data: { organizationId, name, description },
    });
  }

  async addStep(workflowId: string, name: string, type: any, config: any) {
    return this.prisma.workflowStep.create({
      data: { workflowId, name, type, config },
    });
  }

  async addTransition(sourceId: string, targetId: string, condition?: any) {
    return this.prisma.workflowTransition.create({
      data: { sourceId, targetId, condition },
    });
  }

  async executeStep(
    workflowId: string,
    targetId: string,
    targetType: string,
    actionPayload: any,
  ) {
    // 1. Find the current execution state
    let execution = await this.prisma.workflowExecution.findFirst({
      where: { workflowId, targetId, targetType },
      orderBy: { id: 'desc' }, // simplification
    });

    if (!execution) {
      execution = await this.prisma.workflowExecution.create({
        data: { workflowId, targetId, targetType, status: 'STARTED' },
      });
    }

    // 2. Fetch the workflow and its steps
    const workflow = await this.prisma.workflow.findUnique({
      where: { id: workflowId },
      include: { steps: { include: { transitions: true } } },
    });

    if (!workflow) throw new NotFoundException('Workflow not found');

    // Here we would implement the complex state machine:
    // 1. Evaluate current step
    // 2. Run actionPayload against all outgoing transitions' conditions
    // 3. If condition met, move to target step
    // 4. Fire any SLA or Webhook config embedded in the target step config
    // For MVP, we simulate a successful progression

    await this.prisma.workflowExecution.update({
      where: { id: execution.id },
      data: { status: 'PROGRESSED' },
    });

    return execution;
  }
}
