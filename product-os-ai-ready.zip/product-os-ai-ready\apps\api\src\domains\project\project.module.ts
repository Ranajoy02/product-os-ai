import { Module } from '@nestjs/common';
import { ProjectService } from './project.service';
import { TaskService } from './task.service';
import { ProjectController } from './project.controller';
import { ProjectResolver } from './project.resolver';

@Module({
  controllers: [ProjectController],
  providers: [ProjectService, TaskService, ProjectResolver],
})
export class ProjectModule {}
