'use client';

import React from 'react';
import { useQuery } from '@apollo/experimental-nextjs-app-support/ssr';
import { gql } from '@apollo/client';
import { toast } from 'sonner';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  FileText, 
  Folder, 
  Image as ImageIcon, 
  Link as LinkIcon, 
  MoreVertical, 
  Plus, 
  Search, 
  Upload, 
  Lock,
  Clock,
  User as UserIcon
} from 'lucide-react';

const GET_DOCUMENTS = gql`
  query GetDocuments {
    documents {
      id
      title
      content
      type
      version
      updatedAt
    }
  }
`;

export default function Documents() {
  const { data, loading, error } = useQuery<any>(GET_DOCUMENTS);

  return (
    <div className="p-8 space-y-6 max-w-[1600px] mx-auto">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-slate-900">Requirements & Docs</h1>
          <p className="text-muted-foreground mt-2 text-sm">
            Central repository for PRDs, architectures, assets, and design files.
          </p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="bg-white" onClick={() => toast.info('Opening File Picker...')}>
            <Upload className="w-4 h-4 mr-2" /> Upload Asset
          </Button>
          <Button className="bg-indigo-600 hover:bg-indigo-700" onClick={() => toast.success('Created new Draft Document.')}>
            <Plus className="w-4 h-4 mr-2" /> New Document
          </Button>
        </div>
      </div>

      {/* Toolbar */}
      <div className="flex flex-col md:flex-row gap-4 items-center justify-between border-b border-slate-200 pb-4">
        <div className="flex items-center gap-2 w-full md:w-auto">
          <div className="relative flex-1 md:w-80">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input 
              placeholder="Search documents or AI-generated PRDs..." 
              className="pl-9 h-10 bg-white border-slate-200"
            />
          </div>
          <Button variant="outline" size="sm" className="h-10 bg-white">Filters</Button>
        </div>
        
        <div className="flex items-center gap-1 text-sm bg-slate-100 p-1 rounded-lg">
          <Button variant="ghost" size="sm" className="h-8 bg-white shadow-sm font-medium">All Files</Button>
          <Button variant="ghost" size="sm" className="h-8 text-slate-600">My Docs</Button>
          <Button variant="ghost" size="sm" className="h-8 text-slate-600">Approvals</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 lg:grid-cols-5 gap-6">
        {/* Navigation Sidebar */}
        <div className="md:col-span-1 border-r pr-4 hidden md:block">
          <div className="space-y-6">
            <div>
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Workspaces</h4>
              <ul className="space-y-1">
                <li>
                  <button className="w-full flex items-center justify-between px-3 py-2 rounded-md bg-indigo-50 text-indigo-700 text-sm font-medium">
                    <div className="flex items-center gap-2"><Folder className="w-4 h-4" /> Merchant Dashboard</div>
                  </button>
                </li>
                <li>
                  <button className="w-full flex items-center justify-between px-3 py-2 rounded-md hover:bg-slate-100 text-slate-700 text-sm font-medium transition-colors">
                    <div className="flex items-center gap-2"><Folder className="w-4 h-4" /> Payment API v2</div>
                  </button>
                </li>
                <li>
                  <button className="w-full flex items-center justify-between px-3 py-2 rounded-md hover:bg-slate-100 text-slate-700 text-sm font-medium transition-colors">
                    <div className="flex items-center gap-2"><Folder className="w-4 h-4" /> Global Design System</div>
                  </button>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Types</h4>
              <ul className="space-y-1">
                <li>
                  <button className="w-full flex items-center gap-2 px-3 py-2 rounded-md hover:bg-slate-100 text-slate-700 text-sm font-medium transition-colors">
                    <FileText className="w-4 h-4 text-blue-500" /> PRDs & BRDs
                  </button>
                </li>
                <li>
                  <button className="w-full flex items-center gap-2 px-3 py-2 rounded-md hover:bg-slate-100 text-slate-700 text-sm font-medium transition-colors">
                    <ImageIcon className="w-4 h-4 text-purple-500" /> Design Assets
                  </button>
                </li>
                <li>
                  <button className="w-full flex items-center gap-2 px-3 py-2 rounded-md hover:bg-slate-100 text-slate-700 text-sm font-medium transition-colors">
                    <LinkIcon className="w-4 h-4 text-emerald-500" /> External Links
                  </button>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Main Content Area */}
        <div className="md:col-span-3 lg:col-span-4">
          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm">
            {/* Table Header */}
            <div className="grid grid-cols-12 gap-4 px-6 py-3 border-b border-slate-100 bg-slate-50 text-xs font-semibold text-slate-500 uppercase tracking-wider">
              <div className="col-span-6">Name</div>
              <div className="col-span-2 hidden sm:block">Status</div>
              <div className="col-span-3 hidden md:block">Last Modified</div>
              <div className="col-span-1 text-right"></div>
            </div>

            {/* Table Rows */}
            <div className="divide-y divide-slate-100">
              {loading && <div className="p-6 text-center text-slate-500">Loading documents...</div>}
              {error && <div className="p-6 text-center text-red-500">Error loading documents</div>}
              
              {!loading && !error && data?.documents?.length === 0 && (
                <div className="p-6 text-center text-slate-500">No documents found.</div>
              )}

              {!loading && !error && data?.documents?.map((doc: any) => (
                <div key={doc.id} className="grid grid-cols-12 gap-4 px-6 py-4 items-center hover:bg-slate-50 transition-colors group cursor-pointer">
                  <div className="col-span-11 sm:col-span-6 flex items-center gap-3">
                    <div className="w-10 h-10 rounded bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                      <FileText className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <p className="font-medium text-slate-900 truncate group-hover:text-indigo-600 transition-colors">
                        {doc.title} (v{doc.version})
                      </p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-xs text-slate-500">{doc.type}</span>
                      </div>
                    </div>
                  </div>
                  <div className="col-span-2 hidden sm:flex items-center">
                    <span className="inline-flex items-center gap-1.5 bg-slate-100 text-slate-700 px-2.5 py-1 rounded-full text-xs font-medium border border-slate-200">
                      Document
                    </span>
                  </div>
                  <div className="col-span-3 hidden md:flex flex-col">
                    <span className="text-sm text-slate-900">
                      {new Date(doc.updatedAt).toLocaleDateString()}
                    </span>
                    <span className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                      <UserIcon className="w-3 h-3"/> System
                    </span>
                  </div>
                  <div className="col-span-1 flex justify-end">
                    <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity">
                      <MoreVertical className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
