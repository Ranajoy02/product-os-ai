import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../../core/prisma/prisma.service';

@Injectable()
export class OrganizationService {
  constructor(private prisma: PrismaService) {}

  async getOrganization(id: string) {
    const org = await this.prisma.organization.findUnique({
      where: { id },
      include: { workspaces: true },
    });
    if (!org) throw new NotFoundException('Organization not found');
    return org;
  }

  async updateOrganization(id: string, data: { name?: string }) {
    return this.prisma.organization.update({
      where: { id },
      data,
    });
  }

  async getWorkspaces(orgId: string) {
    return this.prisma.workspace.findMany({
      where: { organizationId: orgId },
    });
  }
}
