'use client';

import React from 'react';

export function RoadmapGantt() {
  const months = ['Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  
  const items = [
    { id: 1, title: 'Strategic Goal: Q3 Security', start: 0, width: 4, type: 'goal', progress: 60, health: 'Good', risk: 'Low', deps: 0, forecast: 'On Track' },
    { id: 2, title: 'Epic: OAuth Implementation', start: 0.5, width: 2, type: 'epic', progress: 80, health: 'Warning', risk: 'Medium', deps: 2, forecast: '2 Days Delay' },
    { id: 3, title: 'Task: JWT Service', start: 1, width: 1, type: 'task', progress: 100, health: 'Critical', risk: 'High', deps: 1, forecast: 'Blocked' },
    { id: 4, title: 'Release 2.4', start: 2.5, width: 0.2, type: 'milestone', progress: 0, health: 'Good', risk: 'Low', deps: 3, forecast: 'Dependent on JWT' },
  ];

  return (
    <div className="w-full overflow-x-auto">
      <div className="min-w-[800px]">
        {/* Timeline Header */}
        <div className="flex border-b border-slate-200">
          <div className="w-64 shrink-0 p-4 font-semibold text-sm border-r border-slate-200">Roadmap Hierarchy</div>
          <div className="flex-1 flex">
            {months.map(m => (
              <div key={m} className="flex-1 p-2 text-center text-xs font-medium text-slate-500 border-r border-slate-100">
                {m} 2026
              </div>
            ))}
          </div>
        </div>

        {/* Timeline Body */}
        <div className="relative">
          {items.map((item, idx) => (
            <div key={item.id} className="flex border-b border-slate-100 hover:bg-slate-50 transition-colors">
              <div className="w-64 shrink-0 p-4 border-r border-slate-200 flex flex-col justify-center">
                <span className={`text-sm font-medium ${item.type === 'goal' ? 'text-indigo-700 font-bold' : item.type === 'epic' ? 'text-purple-700 ml-4' : item.type === 'task' ? 'text-slate-700 ml-8' : 'text-emerald-700 ml-8 font-bold'}`}>
                  {item.title}
                </span>
                <div className="flex gap-2 mt-1 text-[10px] uppercase font-bold tracking-wider">
                  <span className={item.health === 'Good' ? 'text-emerald-500' : item.health === 'Warning' ? 'text-amber-500' : 'text-rose-500'}>
                    Health: {item.health}
                  </span>
                  <span className="text-slate-400">&bull;</span>
                  <span className={item.risk === 'Low' ? 'text-emerald-500' : item.risk === 'Medium' ? 'text-amber-500' : 'text-rose-500'}>
                    Risk: {item.risk}
                  </span>
                </div>
              </div>
              <div className="flex-1 relative py-4">
                {/* Background Grid Lines */}
                <div className="absolute inset-0 flex pointer-events-none">
                  {months.map((_, i) => (
                    <div key={i} className="flex-1 border-r border-slate-100 border-dashed" />
                  ))}
                </div>
                
                {/* Gantt Bar */}
                <div 
                  className={`absolute h-8 rounded-md flex items-center px-3 text-xs font-medium text-white shadow-sm overflow-hidden group cursor-pointer
                    ${item.type === 'goal' ? 'bg-indigo-500' : item.type === 'epic' ? 'bg-purple-500' : item.type === 'task' ? 'bg-slate-500' : 'bg-emerald-500 w-4 rounded-full rotate-45'}
                  `}
                  style={{ 
                    left: `calc(${(item.start / months.length) * 100}%)`,
                    width: item.type === 'milestone' ? '16px' : `calc(${(item.width / months.length) * 100}%)`,
                    top: '50%',
                    transform: item.type === 'milestone' ? 'translateY(-50%) rotate(45deg)' : 'translateY(-50%)'
                  }}
                >
                  {item.type !== 'milestone' && (
                    <>
                      <div className="absolute inset-0 bg-black/10" style={{ width: `${item.progress}%` }} />
                      <span className="relative z-10 truncate">{item.progress}%</span>
                    </>
                  )}
                  
                  {/* Tooltip Overlay */}
                  <div className="absolute hidden group-hover:block z-50 bg-slate-900 text-white p-3 rounded shadow-xl -top-16 left-0 min-w-[200px] text-xs space-y-1">
                    <p className="font-bold text-sm mb-2">{item.title}</p>
                    <p>AI Forecast: <span className="text-indigo-300">{item.forecast}</span></p>
                    <p>Dependencies: {item.deps}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
