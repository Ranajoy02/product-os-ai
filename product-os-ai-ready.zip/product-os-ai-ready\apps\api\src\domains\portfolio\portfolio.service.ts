import { Injectable } from '@nestjs/common';
import {
  PortfolioIntelligence,
  SimulatePortfolioAllocationInput,
  SimulatedOutcome,
} from './models/portfolio.model';

@Injectable()
export class PortfolioService {
  getPortfolioIntelligence(): PortfolioIntelligence {
    return {
      roi: 15.5,
      valueCreation: 1200000,
      overloadedTeams: 3,
      delayedInitiatives: 2,
      items: [
        { id: '1', name: 'AI Feature Launch', type: 'Feature' },
        { id: '2', name: 'Infrastructure Migration', type: 'Tech Debt' },
      ],
    };
  }

  simulatePortfolioAllocation(
    input: SimulatePortfolioAllocationInput,
  ): SimulatedOutcome {
    let roi = 15.5;
    let valueCreation = 1200000;
    let overloadedTeams = 3;
    let delayedInitiatives = 2;
    let itemsImpacted = 0;

    if (input.shiftPriorities) {
      roi += 2.0;
      itemsImpacted += 1;
    }
    if (input.delayRelease) {
      delayedInitiatives += 1;
      overloadedTeams -= 1;
      itemsImpacted += 2;
    }
    if (input.reallocateTeams) {
      overloadedTeams -= 2;
      valueCreation += 150000;
      itemsImpacted += 1;
    }

    return {
      newRoi: roi,
      newValueCreation: valueCreation,
      newOverloadedTeams: Math.max(0, overloadedTeams),
      newDelayedInitiatives: delayedInitiatives,
      itemsImpacted,
    };
  }
}
