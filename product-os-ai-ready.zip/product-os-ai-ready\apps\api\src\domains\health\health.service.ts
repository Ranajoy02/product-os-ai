import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../core/prisma/prisma.service';

@Injectable()
export class HealthService {
  constructor(private prisma: PrismaService) {}

  async calculateProductHealth(productId: string) {
    const product = await this.prisma.product.findUnique({
      where: { id: productId },
      include: { releases: true },
    });

    if (!product) throw new NotFoundException('Product not found');

    // Simulate metrics
    const mockBugDensity = Math.random() * 10;
    const mockVelocity = Math.random() * 100;
    const mockCustomerFeedback = Math.random() * 5;

    let score =
      100 - mockBugDensity * 2 + mockVelocity * 0.1 + mockCustomerFeedback * 2;
    score = Math.min(Math.max(score, 0), 100);

    let category: 'GREEN' | 'YELLOW' | 'RED' = 'GREEN';
    if (score < 70) category = 'YELLOW';
    if (score < 40) category = 'RED';

    // Upsert the core ProductHealth record
    const productHealth = await this.prisma.productHealth.upsert({
      where: { productId },
      update: { score, category },
      create: { productId, score, category },
    });

    // Save a historical snapshot
    await this.prisma.healthSnapshot.create({
      data: {
        healthId: productHealth.id,
        score,
      },
    });

    // Save specific metrics
    await this.prisma.healthMetric.createMany({
      data: [
        {
          healthId: productHealth.id,
          type: 'DEFECT_DENSITY',
          value: mockBugDensity,
        },
        { healthId: productHealth.id, type: 'VELOCITY', value: mockVelocity },
        {
          healthId: productHealth.id,
          type: 'CUSTOMER_FEEDBACK',
          value: mockCustomerFeedback,
        },
      ],
    });

    // Also update the cached score on the Product model
    await this.prisma.product.update({
      where: { id: productId },
      data: { healthScore: score },
    });

    return {
      productId,
      healthScore: Math.round(score),
      category,
      metrics: {
        bugDensity: mockBugDensity.toFixed(2),
        velocity: mockVelocity.toFixed(2),
        customerFeedback: mockCustomerFeedback.toFixed(2),
      },
    };
  }

  async getProductHealth(productId: string) {
    return this.calculateProductHealth(productId);
  }

  async getHealthTrend(productId: string, days: number = 30) {
    const health = await this.prisma.productHealth.findUnique({
      where: { productId },
      include: {
        snapshots: {
          orderBy: { recordedAt: 'asc' },
          take: days,
        },
      },
    });

    if (!health) throw new NotFoundException('Health record not found');
    return health.snapshots;
  }
}
