'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';

export default function OnboardingPage() {
  const [step, setStep] = useState(1);
  const [orgName, setOrgName] = useState('');

  const nextStep = () => setStep((s) => s + 1);

  return (
    <div className="animate-in fade-in zoom-in duration-500">
      {step === 1 && (
        <Card className="border shadow-sm">
          <CardHeader>
            <CardTitle>Welcome to ProductOS</CardTitle>
            <CardDescription>Let's set up your organization in 5 minutes.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="orgName">Organization Name</Label>
              <Input
                id="orgName"
                placeholder="e.g. Acme Corp"
                value={orgName}
                onChange={(e) => setOrgName(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="workspaceName">First Workspace</Label>
              <Input id="workspaceName" placeholder="e.g. Internal Products" defaultValue="Main Workspace" />
            </div>
          </CardContent>
          <CardFooter>
            <Button className="w-full" onClick={nextStep} disabled={!orgName}>
              Continue
            </Button>
          </CardFooter>
        </Card>
      )}

      {step === 2 && (
        <Card className="border shadow-sm">
          <CardHeader>
            <CardTitle>Invite Your Team</CardTitle>
            <CardDescription>ProductOS is better with your team.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Email Addresses</Label>
              <Input placeholder="alice@acme.com, bob@acme.com" />
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="ghost" onClick={() => setStep(1)}>Back</Button>
            <div className="flex gap-2">
              <Button variant="outline" onClick={nextStep}>Skip</Button>
              <Button onClick={nextStep}>Send Invites</Button>
            </div>
          </CardFooter>
        </Card>
      )}

      {step === 3 && (
        <Card className="border shadow-sm">
          <CardHeader>
            <CardTitle>How do you want to start?</CardTitle>
            <CardDescription>ProductOS AI can automatically build your project structure.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4">
            <Button variant="outline" className="h-20 justify-start px-6" onClick={nextStep}>
              <div className="text-left">
                <div className="font-semibold">Upload a PRD / Spec</div>
                <div className="text-xs text-muted-foreground">AI will extract tasks, features, and estimates</div>
              </div>
            </Button>
            <Button variant="outline" className="h-20 justify-start px-6" onClick={nextStep}>
              <div className="text-left">
                <div className="font-semibold">Chat with AI Copilot</div>
                <div className="text-xs text-muted-foreground">Brainstorm a project from scratch</div>
              </div>
            </Button>
            <Button variant="ghost" className="h-20 justify-start px-6" onClick={nextStep}>
              <div className="text-left">
                <div className="font-semibold">Start Blank</div>
                <div className="text-xs text-muted-foreground">Create my own Epic and Tasks manually</div>
              </div>
            </Button>
          </CardContent>
        </Card>
      )}

      {step === 4 && (
        <Card className="border shadow-sm bg-primary text-primary-foreground">
          <CardHeader>
            <CardTitle>All Set!</CardTitle>
            <CardDescription className="text-primary-foreground/80">Taking you to the Command Center...</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
