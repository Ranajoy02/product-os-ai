import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { BrainCircuit, AlertTriangle, CheckCircle, TrendingUp, TrendingDown, Info } from 'lucide-react';
import { gql } from '@apollo/client';
import { useQuery } from '@apollo/experimental-nextjs-app-support/ssr';

const GET_PREDICTIONS = gql`
  query GetDeliveryIntelligence($entityId: ID!) {
    getDeliveryIntelligence(entityId: $entityId) {
      deliveryRiskScore
      delayProbability
      qualityProbability
      resourceSufficiencyScore
      timelineConfidence
      budgetConfidence
      rootCause
      recommendedAction
      expectedImprovement
    }
  }
`;

export function AIDeliveryBrain({ entityId }: { entityId: string }) {
  const { data, loading, error } = useQuery<any>(GET_PREDICTIONS, {
    variables: { entityId },
  });

  if (loading) return <div className="animate-pulse h-64 bg-indigo-50 rounded-lg"></div>;
  if (error || !data?.getDeliveryIntelligence) return <div className="text-rose-500">Failed to load AI predictions</div>;

  const metrics = data.getDeliveryIntelligence;

  return (
    <Card className="border-indigo-200 shadow-md bg-gradient-to-br from-indigo-50 to-white overflow-hidden">
      <div className="bg-indigo-600 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2 text-white">
          <BrainCircuit className="h-6 w-6" />
          <h2 className="text-xl font-bold tracking-wide">AI Delivery Brain</h2>
        </div>
        <div className="bg-white/20 px-3 py-1 rounded-full text-white text-xs font-medium backdrop-blur-sm">
          Predictive Model: Active
        </div>
      </div>
      
      <CardContent className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          
          <div className="bg-white rounded-xl p-5 border border-slate-100 shadow-sm flex flex-col items-center justify-center text-center relative overflow-hidden">
            <div className={`absolute top-0 left-0 w-full h-1 ${metrics.timelineConfidence > 75 ? 'bg-emerald-500' : metrics.timelineConfidence > 50 ? 'bg-amber-400' : 'bg-rose-500'}`}></div>
            <p className="text-slate-500 text-sm font-medium mb-1 uppercase tracking-wider">Timeline Confidence</p>
            <div className="text-4xl font-black text-slate-800">{metrics.timelineConfidence}%</div>
            <p className="text-xs text-slate-400 mt-2">Probability of on-time delivery</p>
          </div>

          <div className="bg-white rounded-xl p-5 border border-slate-100 shadow-sm flex flex-col items-center justify-center text-center relative overflow-hidden">
            <div className={`absolute top-0 left-0 w-full h-1 ${metrics.budgetConfidence > 80 ? 'bg-emerald-500' : metrics.budgetConfidence > 60 ? 'bg-amber-400' : 'bg-rose-500'}`}></div>
            <p className="text-slate-500 text-sm font-medium mb-1 uppercase tracking-wider">Budget Confidence</p>
            <div className="text-4xl font-black text-slate-800">{metrics.budgetConfidence}%</div>
            <p className="text-xs text-slate-400 mt-2">Probability of staying within budget</p>
          </div>

          <div className="bg-white rounded-xl p-5 border border-slate-100 shadow-sm flex flex-col items-center justify-center text-center relative overflow-hidden">
            <div className={`absolute top-0 left-0 w-full h-1 ${metrics.deliveryRiskScore < 30 ? 'bg-emerald-500' : metrics.deliveryRiskScore < 70 ? 'bg-amber-400' : 'bg-rose-500'}`}></div>
            <p className="text-slate-500 text-sm font-medium mb-1 uppercase tracking-wider">Delivery Risk Score</p>
            <div className="text-4xl font-black text-slate-800">{metrics.deliveryRiskScore}</div>
            <p className="text-xs text-slate-400 mt-2">Aggregate execution risk (0-100)</p>
          </div>
          
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
           <div className="text-center p-3 rounded-lg bg-slate-50">
             <div className="text-xs text-slate-500 mb-1">Delay Probability</div>
             <div className="font-bold text-slate-700">{metrics.delayProbability}%</div>
           </div>
           <div className="text-center p-3 rounded-lg bg-slate-50">
             <div className="text-xs text-slate-500 mb-1">Quality Probability</div>
             <div className="font-bold text-slate-700">{metrics.qualityProbability}%</div>
           </div>
           <div className="text-center p-3 rounded-lg bg-slate-50">
             <div className="text-xs text-slate-500 mb-1">Resource Sufficiency</div>
             <div className="font-bold text-slate-700">{metrics.resourceSufficiencyScore}/100</div>
           </div>
           <div className="text-center p-3 rounded-lg bg-slate-50">
             <div className="text-xs text-slate-500 mb-1">Prediction Variance</div>
             <div className="font-bold text-slate-700">±4.2%</div>
           </div>
        </div>

        <div className="bg-rose-50 border border-rose-100 rounded-xl p-5 mb-4">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-rose-600 mt-0.5 shrink-0" />
            <div>
              <h4 className="font-bold text-rose-900">Predicted Root Cause of Risk</h4>
              <p className="text-rose-700 mt-1">{metrics.rootCause}</p>
            </div>
          </div>
        </div>

        <div className="bg-emerald-50 border border-emerald-100 rounded-xl p-5 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-10">
            <BrainCircuit className="w-24 h-24 text-emerald-600" />
          </div>
          <div className="flex items-start gap-3 relative z-10">
            <CheckCircle className="w-5 h-5 text-emerald-600 mt-0.5 shrink-0" />
            <div>
              <h4 className="font-bold text-emerald-900">AI Recommended Action</h4>
              <p className="text-emerald-800 mt-1 font-medium">{metrics.recommendedAction}</p>
              <div className="mt-3 flex items-center gap-2 bg-white/60 inline-flex px-3 py-1.5 rounded-md border border-emerald-200">
                <TrendingUp className="w-4 h-4 text-emerald-600" />
                <span className="text-sm font-semibold text-emerald-700">Expected Improvement: {metrics.expectedImprovement}</span>
              </div>
            </div>
          </div>
        </div>

      </CardContent>
    </Card>
  );
}
