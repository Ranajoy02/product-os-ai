import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../core/prisma/prisma.service';

@Injectable()
export class ProjectService {
  constructor(private prisma: PrismaService) {}

  async createProject(
    workspaceId: string,
    data: { name: string; description?: string },
  ) {
    return this.prisma.project.create({
      data: { ...data, workspaceId },
    });
  }

  async getProjectsByWorkspace(workspaceId: string) {
    return this.prisma.project.findMany({ where: { workspaceId } });
  }

  async getProjectDetails(projectId: string) {
    const project = await this.prisma.project.findUnique({
      where: { id: projectId },
      include: { tasks: true, milestones: true },
    });
    if (!project) throw new NotFoundException('Project not found');
    return project;
  }
}
