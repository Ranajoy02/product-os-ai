import { ObjectType, Field, Int, Float, InputType } from '@nestjs/graphql';

@ObjectType()
export class PortfolioItem {
  @Field()
  id: string;

  @Field()
  name: string;

  @Field()
  type: string;
}

@ObjectType()
export class PortfolioIntelligence {
  @Field(() => Float)
  roi: number;

  @Field(() => Float)
  valueCreation: number;

  @Field(() => Int)
  overloadedTeams: number;

  @Field(() => Int)
  delayedInitiatives: number;

  @Field(() => [PortfolioItem])
  items: PortfolioItem[];
}

@InputType()
export class SimulatePortfolioAllocationInput {
  @Field({ nullable: true })
  shiftPriorities?: boolean;

  @Field({ nullable: true })
  delayRelease?: boolean;

  @Field({ nullable: true })
  reallocateTeams?: boolean;
}

@ObjectType()
export class SimulatedOutcome {
  @Field(() => Float)
  newRoi: number;

  @Field(() => Float)
  newValueCreation: number;

  @Field(() => Int)
  newOverloadedTeams: number;

  @Field(() => Int)
  newDelayedInitiatives: number;

  @Field(() => Int)
  itemsImpacted: number;
}
