import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../core/prisma/prisma.service';

@Injectable()
export class PerformanceService {
  constructor(private prisma: PrismaService) {}

  async getPerformanceScores() {
    return this.prisma.performanceScore.findMany({
      include: {
        user: true,
      },
    });
  }

  async getPerformanceScoreByUser(userId: string) {
    return this.prisma.performanceScore.findUnique({
      where: { userId },
      include: {
        user: true,
      },
    });
  }
}
