import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Network, Activity, ArrowRight, ShieldCheck, Zap, AlertTriangle, Layers } from 'lucide-react';
import { gql } from '@apollo/client';
import { useQuery } from '@apollo/experimental-nextjs-app-support/ssr';

const GET_DIGITAL_TWIN = gql`
  query GetDigitalTwin($entityId: ID!) {
    getDigitalTwin(entityId: $entityId) {
      entityId
      scenarios {
        name
        type
        status
        risk
        progress
        capacity
        expectedCompletion
        expectedCost
        bottlenecks
      }
    }
  }
`;

export function DigitalTwin({ entityId }: { entityId: string }) {
  const { data, loading, error } = useQuery<any>(GET_DIGITAL_TWIN, {
    variables: { entityId },
  });
  
  const [activeScenarioType, setActiveScenarioType] = useState<string>('RECOMMENDED');

  if (loading) return <div className="animate-pulse h-96 bg-slate-50 border border-slate-200 rounded-lg"></div>;
  if (error || !data?.getDigitalTwin) return <div className="text-rose-500">Failed to load Digital Twin data</div>;

  const twin = data.getDigitalTwin;
  const scenarios = twin.scenarios;
  const activeScenario = scenarios.find((s: any) => s.type === activeScenarioType) || scenarios[0];
  const currentState = scenarios.find((s: any) => s.type === 'CURRENT');

  const getRiskColor = (risk: string) => {
    switch (risk.toLowerCase()) {
      case 'low': return 'text-emerald-600 bg-emerald-50 border-emerald-200';
      case 'medium': return 'text-amber-600 bg-amber-50 border-amber-200';
      case 'high': return 'text-rose-600 bg-rose-50 border-rose-200';
      default: return 'text-slate-600 bg-slate-50 border-slate-200';
    }
  };

  return (
    <Card className="border-slate-200 shadow-sm bg-white overflow-hidden">
      <div className="bg-slate-900 px-6 py-4 flex items-center justify-between border-b border-slate-800">
        <div className="flex items-center gap-2 text-white">
          <Network className="h-5 w-5 text-indigo-400" />
          <h2 className="text-lg font-bold tracking-tight">Delivery Digital Twin</h2>
        </div>
        <div className="flex items-center gap-2 bg-slate-800 p-1 rounded-lg">
          {scenarios.map((s: any) => (
            <button
              key={s.type}
              onClick={() => setActiveScenarioType(s.type)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                activeScenarioType === s.type
                  ? 'bg-indigo-500 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-700'
              }`}
            >
              {s.name}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-slate-200">
        
        {/* Left Column: Current State (Always Visible for Comparison) */}
        <div className="p-6 bg-slate-50/50">
           <div className="flex items-center justify-between mb-6">
             <h3 className="text-sm font-bold text-slate-500 uppercase tracking-wider flex items-center gap-2">
               <Activity className="w-4 h-4" /> Current Trajectory
             </h3>
             <span className="px-2.5 py-1 text-xs font-bold bg-slate-200 text-slate-700 rounded-full">Baseline</span>
           </div>

           <div className="space-y-4">
             <div className="grid grid-cols-2 gap-4">
               <div className="p-4 bg-white border border-slate-200 rounded-lg shadow-sm">
                 <div className="text-xs text-slate-500 mb-1">Status</div>
                 <div className={`font-semibold ${currentState?.status === 'At Risk' ? 'text-rose-600' : 'text-slate-900'}`}>{currentState?.status}</div>
               </div>
               <div className={`p-4 border rounded-lg shadow-sm ${getRiskColor(currentState?.risk)}`}>
                 <div className="text-xs opacity-70 mb-1 font-medium">Predicted Risk</div>
                 <div className="font-bold">{currentState?.risk}</div>
               </div>
             </div>

             <div className="p-4 bg-white border border-slate-200 rounded-lg shadow-sm">
                 <div className="flex justify-between items-end mb-2">
                   <div className="text-xs text-slate-500">Expected Completion</div>
                   <div className={`font-semibold ${currentState?.expectedCompletion.includes('Delayed') ? 'text-rose-600' : 'text-slate-900'}`}>{currentState?.expectedCompletion}</div>
                 </div>
                 <div className="w-full bg-slate-100 rounded-full h-2 mb-4">
                    <div className="bg-indigo-500 h-2 rounded-full" style={{ width: currentState?.progress }}></div>
                 </div>
                 <div className="flex justify-between items-center text-sm">
                   <span className="text-slate-500">Predicted Cost</span>
                   <span className="font-semibold text-rose-600">{currentState?.expectedCost}</span>
                 </div>
             </div>

             <div className="p-4 bg-white border border-slate-200 rounded-lg shadow-sm">
               <div className="text-xs text-slate-500 mb-1">Capacity & Bottlenecks</div>
               <div className="font-medium text-slate-900 mb-2">{currentState?.capacity}</div>
               <div className="text-sm flex items-start gap-2 text-amber-700 bg-amber-50 p-2 rounded">
                 <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
                 <span>Primary Bottleneck: {currentState?.bottlenecks}</span>
               </div>
             </div>
           </div>
        </div>

        {/* Right Column: Selected Scenario */}
        <div className={`p-6 transition-colors ${activeScenarioType === 'RECOMMENDED' ? 'bg-indigo-50/30' : activeScenarioType === 'ALTERNATIVE' ? 'bg-emerald-50/30' : 'bg-white'}`}>
           <div className="flex items-center justify-between mb-6">
             <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider flex items-center gap-2">
               {activeScenarioType === 'RECOMMENDED' ? <Zap className="w-4 h-4 text-indigo-500" /> : <Layers className="w-4 h-4 text-emerald-500" />} 
               {activeScenarioType === 'CURRENT' ? 'Current Details' : 'Simulated Outcome'}
             </h3>
             <span className={`px-2.5 py-1 text-xs font-bold rounded-full ${activeScenarioType === 'RECOMMENDED' ? 'bg-indigo-100 text-indigo-700' : activeScenarioType === 'ALTERNATIVE' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-200 text-slate-700'}`}>
               {activeScenario?.name}
             </span>
           </div>

           <div className="space-y-4">
             <div className="grid grid-cols-2 gap-4">
               <div className="p-4 bg-white border border-slate-200 rounded-lg shadow-sm">
                 <div className="text-xs text-slate-500 mb-1">Simulated Status</div>
                 <div className="font-semibold text-emerald-600">{activeScenario?.status}</div>
               </div>
               <div className={`p-4 border rounded-lg shadow-sm ${getRiskColor(activeScenario?.risk)}`}>
                 <div className="text-xs opacity-70 mb-1 font-medium">Simulated Risk</div>
                 <div className="font-bold">{activeScenario?.risk}</div>
               </div>
             </div>

             <div className="p-4 bg-white border border-slate-200 rounded-lg shadow-sm relative overflow-hidden">
                 {activeScenarioType !== 'CURRENT' && (
                   <div className="absolute top-0 right-0 p-4 opacity-5">
                     <ShieldCheck className="w-20 h-20" />
                   </div>
                 )}
                 <div className="flex justify-between items-end mb-2 relative z-10">
                   <div className="text-xs text-slate-500">Expected Completion</div>
                   <div className="font-semibold text-emerald-600">{activeScenario?.expectedCompletion}</div>
                 </div>
                 <div className="w-full bg-slate-100 rounded-full h-2 mb-4 relative z-10">
                    <div className={`h-2 rounded-full ${activeScenarioType === 'ALTERNATIVE' ? 'bg-emerald-500' : 'bg-indigo-500'}`} style={{ width: activeScenario?.progress }}></div>
                 </div>
                 <div className="flex justify-between items-center text-sm relative z-10">
                   <span className="text-slate-500">Predicted Cost</span>
                   <span className="font-semibold text-emerald-600">{activeScenario?.expectedCost}</span>
                 </div>
             </div>

             <div className="p-4 bg-white border border-slate-200 rounded-lg shadow-sm">
               <div className="text-xs text-slate-500 mb-1">Simulated Capacity</div>
               <div className="font-medium text-slate-900 mb-2">{activeScenario?.capacity}</div>
               <div className="text-sm flex items-start gap-2 text-slate-600 bg-slate-50 p-2 rounded">
                 <ShieldCheck className="w-4 h-4 mt-0.5 shrink-0 text-slate-400" />
                 <span>Resolved Bottlenecks: {activeScenario?.bottlenecks}</span>
               </div>
             </div>
           </div>
        </div>

      </div>

      {activeScenarioType !== 'CURRENT' && (
        <div className="bg-slate-50 border-t border-slate-200 px-6 py-4 flex items-center justify-between">
          <div className="text-sm text-slate-600">
            Applying this scenario will automatically generate Change Requests and Resource Reallocation tickets.
          </div>
          <button className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold rounded-lg flex items-center gap-2 transition-colors">
            Apply {activeScenario?.name} <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}
    </Card>
  );
}
