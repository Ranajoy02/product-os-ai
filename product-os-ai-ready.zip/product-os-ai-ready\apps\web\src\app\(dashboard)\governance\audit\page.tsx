'use client';

import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, ShieldAlert, History, UserX, DownloadCloud, Activity } from 'lucide-react';
import { gql } from '@apollo/client';
import { useQuery } from '@apollo/experimental-nextjs-app-support/ssr';

const GET_AUDIT_LOGS = gql`
  query GetAuditEvents {
    getAuditEvents {
      id
      entityType
      entityId
      action
      actorId
      timestamp
      ipAddress
      beforeState
      afterState
    }
  }
`;

export default function AuditCommandCenter() {
  const { data, loading, error } = useQuery<any>(GET_AUDIT_LOGS);
  const [searchTerm, setSearchTerm] = useState('');

  if (loading) return <div className="p-8 text-slate-500 animate-pulse">Loading Audit Command Center...</div>;
  if (error) return <div className="p-8 text-rose-500">Error: {error.message}</div>;

  const events = data?.getAuditEvents || [];
  
  const filteredEvents = events.filter((e: any) => 
    e.action.toLowerCase().includes(searchTerm.toLowerCase()) || 
    e.actorId.toLowerCase().includes(searchTerm.toLowerCase()) ||
    e.entityType.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Audit Command Center</h1>
        <p className="text-slate-500 mt-1">Immutable ledger of entity history, user actions, and security events.</p>
      </div>

      {/* Enterprise Security Dashboard */}
      <div className="grid gap-6 md:grid-cols-4">
        <Card className="border-slate-200 shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">Failed Logins (24h)</CardTitle>
            <UserX className="h-4 w-4 text-rose-500" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-slate-900">14</div>
            <p className="text-xs text-slate-500 mt-1">From 3 distinct IPs</p>
          </CardContent>
        </Card>

        <Card className="border-slate-200 shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">Security Events</CardTitle>
            <ShieldAlert className="h-4 w-4 text-amber-500" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-slate-900">2</div>
            <p className="text-xs text-slate-500 mt-1">API Key Rotations</p>
          </CardContent>
        </Card>

        <Card className="border-slate-200 shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">Data Export Events</CardTitle>
            <DownloadCloud className="h-4 w-4 text-indigo-500" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-slate-900">8</div>
            <p className="text-xs text-slate-500 mt-1">CSV/JSON dumps</p>
          </CardContent>
        </Card>

        <Card className="border-slate-200 shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">Permission Escalations</CardTitle>
            <Activity className="h-4 w-4 text-emerald-500" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-slate-900">0</div>
            <p className="text-xs text-slate-500 mt-1">No admin assignments</p>
          </CardContent>
        </Card>
      </div>

      {/* Searchable Audit Trail */}
      <Card className="border-slate-200 shadow-sm">
        <CardHeader className="border-b border-slate-100 bg-slate-50/50 pb-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <History className="w-5 h-5 text-indigo-500" />
              <CardTitle className="text-lg">Immutable Audit Trail</CardTitle>
            </div>
            <div className="relative w-full md:w-96">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input 
                placeholder="Search by action, user, or entity type..." 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9 h-9"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="text-xs text-slate-500 uppercase bg-slate-50 border-b border-slate-200">
                <tr>
                  <th className="px-6 py-3">Timestamp</th>
                  <th className="px-6 py-3">Action</th>
                  <th className="px-6 py-3">Entity Type</th>
                  <th className="px-6 py-3">Actor ID</th>
                  <th className="px-6 py-3">IP Address</th>
                  <th className="px-6 py-3">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredEvents.length === 0 ? (
                  <tr><td colSpan={6} className="px-6 py-8 text-center text-slate-500">No events found.</td></tr>
                ) : (
                  filteredEvents.map((event: any) => (
                    <tr key={event.id} className="hover:bg-slate-50">
                      <td className="px-6 py-4 text-slate-500 whitespace-nowrap">{new Date(event.timestamp).toLocaleString()}</td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-1 rounded text-xs font-bold ${
                          event.action === 'CREATE' ? 'bg-emerald-100 text-emerald-700' :
                          event.action === 'DELETE' ? 'bg-rose-100 text-rose-700' :
                          event.action === 'UPDATE' ? 'bg-amber-100 text-amber-700' :
                          'bg-indigo-100 text-indigo-700'
                        }`}>
                          {event.action}
                        </span>
                      </td>
                      <td className="px-6 py-4 font-medium text-slate-900">{event.entityType}</td>
                      <td className="px-6 py-4 text-slate-600">{event.actorId}</td>
                      <td className="px-6 py-4 text-slate-500 font-mono text-xs">{event.ipAddress}</td>
                      <td className="px-6 py-4 text-indigo-600 font-medium cursor-pointer hover:underline">View Diff</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
