import { Resolver, Query, Mutation, Args } from '@nestjs/graphql';
import { GovernanceService } from './governance.service';
import { GovernancePolicy, CreateGovernancePolicyInput } from './models/governance.model';

@Resolver(() => GovernancePolicy)
export class GovernanceResolver {
  constructor(private readonly governanceService: GovernanceService) {}

  @Query(() => [GovernancePolicy])
  getGovernancePolicies() {
    return this.governanceService.getGovernancePolicies();
  }

  @Mutation(() => GovernancePolicy)
  createGovernancePolicy(@Args('input') input: CreateGovernancePolicyInput) {
    return this.governanceService.createGovernancePolicy(input);
  }
}
