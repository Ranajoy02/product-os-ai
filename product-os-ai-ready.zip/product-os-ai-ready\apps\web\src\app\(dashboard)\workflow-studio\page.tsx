'use client';

import React, { useState } from 'react';
import { WorkflowCanvas } from '@/components/workflow/WorkflowCanvas';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Activity, Clock, AlertTriangle, Layers, TrendingUp, Target } from 'lucide-react';

export default function WorkflowStudioPage() {
  const [activeVersion, setActiveVersion] = useState('v2.4 (Current)');
  const [heatmapEnabled, setHeatmapEnabled] = useState(false);

  return (
    <div className="p-8 max-w-[1600px] mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Workflow Studio</h1>
          <p className="text-slate-500 mt-2">Visually design, analyze, and optimize execution flows</p>
        </div>
        <div className="flex gap-4">
          <select 
            className="border rounded-md px-3 py-2 text-sm bg-white"
            value={activeVersion}
            onChange={(e) => setActiveVersion(e.target.value)}
          >
            <option>v2.4 (Current)</option>
            <option>v2.3 (Previous)</option>
            <option>v2.2</option>
          </select>
          <Button 
            variant={heatmapEnabled ? "default" : "outline"}
            onClick={() => setHeatmapEnabled(!heatmapEnabled)}
          >
            {heatmapEnabled ? 'Heatmap: ON' : 'Heatmap: OFF'}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Left Sidebar: Analytics */}
        <div className="space-y-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Activity className="w-4 h-4 text-indigo-500" />
                Performance Metrics
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="text-2xl font-bold">14.2 days</div>
                <p className="text-xs text-slate-500">Avg. Cycle Time (-1.2d)</p>
              </div>
              <div>
                <div className="text-2xl font-bold text-emerald-600">94%</div>
                <p className="text-xs text-slate-500">First-pass Approval Rate</p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-rose-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2 text-rose-700">
                <AlertTriangle className="w-4 h-4" />
                Bottleneck Detection
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="bg-rose-50 p-3 rounded-md border border-rose-100">
                  <p className="text-sm font-medium text-rose-800">QA Review Phase</p>
                  <p className="text-xs text-rose-600 mt-1">SLA exceeded by 48hrs</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-500" />
                SLA Tracking
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Ideation</span>
                  <span className="text-emerald-600">On Track</span>
                </div>
                <div className="flex justify-between">
                  <span>Development</span>
                  <span className="text-emerald-600">On Track</span>
                </div>
                <div className="flex justify-between font-medium">
                  <span>QA Review</span>
                  <span className="text-rose-600">Breached</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Center: Workflow Canvas */}
        <div className="lg:col-span-3 space-y-6 flex flex-col">
          <div className="bg-white border rounded-lg shadow-sm flex-1 min-h-[600px]">
            <WorkflowCanvas heatmapEnabled={heatmapEnabled} />
          </div>

          {/* Visual Intelligence Block */}
          <Card className="bg-slate-900 text-white border-slate-800">
            <CardHeader className="pb-2 border-b border-slate-800">
              <CardTitle className="text-lg font-semibold flex items-center gap-2">
                <span className="text-indigo-400">✦</span> Visual Intelligence Analysis
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4">
              <div className="grid md:grid-cols-4 gap-6 text-sm">
                <div>
                  <span className="text-slate-400 font-semibold block mb-1 uppercase tracking-wider text-xs">What is happening?</span>
                  <p className="text-slate-100">Tasks are accumulating at the 'QA Review' step, forming a structural bottleneck.</p>
                </div>
                <div>
                  <span className="text-slate-400 font-semibold block mb-1 uppercase tracking-wider text-xs">Why is it happening?</span>
                  <p className="text-slate-100">QA team capacity is at 110% while 3 complex PRs were merged simultaneously.</p>
                </div>
                <div>
                  <span className="text-slate-400 font-semibold block mb-1 uppercase tracking-wider text-xs">What happens next?</span>
                  <p className="text-slate-100">Release 2.4 will be delayed by 2 days if the queue isn't cleared within 24 hours.</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-indigo-950 text-slate-100 border-indigo-900">
            <CardHeader className="pb-3 border-b border-indigo-900">
              <CardTitle className="text-lg font-semibold flex items-center gap-2 text-indigo-300">
                <Target className="w-5 h-5" /> Business Impact Layer
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4 flex items-center justify-between gap-2 text-xs overflow-x-auto">
              <div className="flex flex-col items-center flex-1 bg-indigo-900 p-3 rounded border border-indigo-800 min-w-[120px]">
                <span className="text-slate-400 mb-1">Task</span>
                <span className="font-semibold text-center">JWT Service</span>
                <span className="text-rose-400 font-bold mt-2">BLOCKED</span>
              </div>
              <div className="text-indigo-500 font-bold">→</div>
              <div className="flex flex-col items-center flex-1 bg-indigo-900 p-3 rounded border border-indigo-800 min-w-[120px]">
                <span className="text-slate-400 mb-1">Milestone</span>
                <span className="font-semibold text-center">Auth Upgrade</span>
                <span className="text-amber-400 font-bold mt-2">AT RISK</span>
              </div>
              <div className="text-indigo-500 font-bold">→</div>
              <div className="flex flex-col items-center flex-1 bg-indigo-900 p-3 rounded border border-indigo-800 min-w-[120px]">
                <span className="text-slate-400 mb-1">Release</span>
                <span className="font-semibold text-center">v2.4</span>
                <span className="text-amber-400 font-bold mt-2">AT RISK</span>
              </div>
              <div className="text-indigo-500 font-bold">→</div>
              <div className="flex flex-col items-center flex-1 bg-indigo-900 p-3 rounded border border-indigo-800 min-w-[120px]">
                <span className="text-slate-400 mb-1">Roadmap</span>
                <span className="font-semibold text-center">Q3 Security</span>
                <span className="text-rose-400 font-bold mt-2">DELAYED</span>
              </div>
              <div className="text-indigo-500 font-bold">→</div>
              <div className="flex flex-col items-center flex-1 bg-indigo-900 p-3 rounded border border-rose-900/50 min-w-[120px]">
                <span className="text-slate-400 mb-1">Business Outcome</span>
                <span className="font-semibold text-center text-white">Enterprise Sales</span>
                <span className="text-rose-400 font-bold mt-2 text-center">-$120k ARR<br/>Q3 Miss</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
