import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../core/prisma/prisma.service';
import { RoadmapType } from '@prisma/client';

@Injectable()
export class RoadmapService {
  constructor(private prisma: PrismaService) {}

  async createStrategicGoal(name: string) {
    return this.prisma.strategicGoal.create({
      data: { name },
    });
  }

  async createObjective(goalId: string, name: string) {
    return this.prisma.objective.create({
      data: { goalId, name },
    });
  }

  async createInitiative(objectiveId: string, name: string) {
    return this.prisma.initiative.create({
      data: { objectiveId, name },
    });
  }

  async createRoadmap(name: string, type: RoadmapType) {
    return this.prisma.roadmap.create({
      data: { name, type },
    });
  }

  async createRoadmapItem(
    roadmapId: string,
    initiativeId: string,
    startDate: Date,
    endDate: Date,
    status: string,
  ) {
    return this.prisma.roadmapItem.create({
      data: {
        roadmapId,
        initiativeId,
        startDate,
        endDate,
        status,
      },
    });
  }

  async getRoadmapTree(roadmapId: string) {
    const roadmap = await this.prisma.roadmap.findUnique({
      where: { id: roadmapId },
      include: {
        items: {
          include: {
            initiative: {
              include: {
                objective: {
                  include: {
                    goal: true,
                  },
                },
              },
            },
          },
        },
      },
    });

    if (!roadmap) throw new NotFoundException('Roadmap not found');
    return roadmap;
  }

  async getRoadmaps() {
    return this.prisma.roadmap.findMany();
  }
}
