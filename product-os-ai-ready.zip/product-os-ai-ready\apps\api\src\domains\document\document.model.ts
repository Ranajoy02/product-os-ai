import {
  ObjectType,
  Field,
  ID,
  Int,
  registerEnumType,
  InputType,
} from '@nestjs/graphql';

export enum DocumentType {
  PRD = 'PRD',
  BRD = 'BRD',
  SOP = 'SOP',
  DESIGN = 'DESIGN',
  ARCHITECTURE = 'ARCHITECTURE',
  MEETING_NOTES = 'MEETING_NOTES',
  CLIENT_DOC = 'CLIENT_DOC',
}

registerEnumType(DocumentType, {
  name: 'DocumentType',
});

@ObjectType()
export class Document {
  @Field(() => ID)
  id: string;

  @Field()
  title: string;

  @Field()
  content: string;

  @Field(() => DocumentType)
  type: DocumentType;

  @Field(() => Int)
  version: number;

  @Field(() => String, { nullable: true })
  productId?: string;

  @Field()
  createdAt: Date;

  @Field()
  updatedAt: Date;
}

@InputType()
export class CreateDocumentInput {
  @Field()
  title: string;

  @Field()
  content: string;

  @Field(() => DocumentType, { nullable: true })
  type?: DocumentType;

  @Field(() => String, { nullable: true })
  productId?: string;
}

@InputType()
export class UpdateDocumentInput {
  @Field(() => String, { nullable: true })
  title?: string;

  @Field(() => String, { nullable: true })
  content?: string;

  @Field(() => DocumentType, { nullable: true })
  type?: DocumentType;

  @Field(() => Int, { nullable: true })
  version?: number;

  @Field(() => String, { nullable: true })
  productId?: string;
}
