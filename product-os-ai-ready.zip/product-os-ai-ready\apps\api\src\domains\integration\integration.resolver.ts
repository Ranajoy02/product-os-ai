import { Resolver, Query, Mutation, Args } from '@nestjs/graphql';
import { IntegrationService } from './integration.service';
import { ConnectionStatus, SyncHealth, EventFlow, UpdateConnectionStatusInput } from './models/integration.model';

@Resolver()
export class IntegrationResolver {
  constructor(private readonly integrationService: IntegrationService) {}

  @Query(() => [ConnectionStatus])
  async connectionStatuses() {
    return this.integrationService.getConnectionStatuses();
  }

  @Query(() => SyncHealth, { nullable: true })
  async syncHealth(@Args('connectionId') connectionId: string) {
    return this.integrationService.getSyncHealth(connectionId);
  }

  @Query(() => [EventFlow])
  async eventFlows(@Args('connectionId') connectionId: string) {
    return this.integrationService.getEventFlows(connectionId);
  }

  @Mutation(() => ConnectionStatus)
  async updateConnectionStatus(@Args('input') input: UpdateConnectionStatusInput) {
    return this.integrationService.updateConnectionStatus(input);
  }
}
