'use client';

import React from 'react';
import { useQuery } from '@apollo/experimental-nextjs-app-support/ssr';
import { gql } from '@apollo/client';

const GET_PROJECTS = gql`
  query GetProjects($workspaceId: String!) {
    projects(workspaceId: $workspaceId) {
      id
      name
      description
      createdAt
      updatedAt
    }
  }
`;

export default function PlanningPage() {
  // Hardcoded workspaceId for demonstration.
  // In a real app, this would likely come from context, URL, or auth.
  const workspaceId = 'default-workspace-id';

  const { data, loading, error } = useQuery<any>(GET_PROJECTS, {
    variables: { workspaceId },
  });

  if (loading) return <div className="p-8">Loading projects...</div>;
  if (error) return <div className="p-8 text-red-500">Error: {error.message}</div>;

  const projects = data?.projects || [];

  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-6">Planning</h1>
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-semibold mb-4">Projects</h2>
        {projects.length === 0 ? (
          <p className="text-gray-500">No projects found for this workspace.</p>
        ) : (
          <ul className="space-y-4">
            {projects.map((project: any) => (
              <li key={project.id} className="border-b pb-4 last:border-b-0">
                <h3 className="text-lg font-medium">{project.name}</h3>
                {project.description && (
                  <p className="text-gray-600 mt-1">{project.description}</p>
                )}
                <div className="text-sm text-gray-400 mt-2">
                  Created: {new Date(project.createdAt).toLocaleDateString()}
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
