import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { PrismaModule } from './core/prisma/prisma.module';
import { AuthModule } from './core/auth/auth.module';
import { OrganizationModule } from './domains/identity/organization/organization.module';
import { ProjectModule } from './domains/project/project.module';
import { EventsModule } from './core/events/events.module';
import { AiModule } from './domains/ai/ai.module';
import { HealthModule } from './domains/health/health.module';
import { KnowledgeModule } from './domains/knowledge/knowledge.module';
import { RoadmapModule } from './domains/roadmap/roadmap.module';

import { GraphQLModule } from '@nestjs/graphql';
import { ApolloDriver, ApolloDriverConfig } from '@nestjs/apollo';
import { join } from 'path';
import { IntelligenceModule } from './domains/intelligence/intelligence.module';
import { CommunicationModule } from './domains/communication/communication.module';
import { TeamModule } from './domains/team/team.module';
import { PerformanceModule } from './domains/performance/performance.module';
import { DocumentModule } from './domains/document/document.module';
import { ControlTowerModule } from './domains/control-tower/control-tower.module';
import { OutcomeModule } from './domains/outcome/outcome.module';
import { PortfolioModule } from './domains/portfolio/portfolio.module';
import { GovernanceModule } from './domains/governance/governance.module';
import { AuditModule } from './domains/audit/audit.module';
import { IntegrationModule } from './domains/integration/integration.module';
import { MigrationModule } from './domains/migration/migration.module';
import { WorkflowModule } from './domains/workflow/workflow.module';

@Module({
  imports: [
    GraphQLModule.forRoot<ApolloDriverConfig>({
      driver: ApolloDriver,
      autoSchemaFile: join(process.cwd(), 'src/schema.gql'),
    }),
    PrismaModule,
    AuthModule,
    OrganizationModule,
    ProjectModule,
    EventsModule,
    AiModule,
    HealthModule,
    KnowledgeModule,
    RoadmapModule,
    IntelligenceModule,
    CommunicationModule,
    TeamModule,
    PerformanceModule,
    DocumentModule,
    ControlTowerModule,
    OutcomeModule,
    PortfolioModule,
    GovernanceModule,
    AuditModule,
    IntegrationModule,
    MigrationModule,
    WorkflowModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
