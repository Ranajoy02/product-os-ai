import { ObjectType, Field, ID, InputType } from '@nestjs/graphql';

@ObjectType()
export class ConnectionStatus {
  @Field(() => ID)
  id: string;

  @Field()
  provider: string;

  @Field()
  status: string; // e.g., 'CONNECTED', 'DISCONNECTED', 'ERROR'

  @Field({ nullable: true })
  lastSyncAt?: string;

  @Field({ nullable: true })
  errorMessage?: string;
}

@ObjectType()
export class SyncHealth {
  @Field(() => ID)
  id: string;

  @Field()
  connectionId: string;

  @Field()
  successRate: number; // percentage

  @Field()
  pendingEventsCount: number;

  @Field()
  failedEventsCount: number;
}

@ObjectType()
export class EventFlow {
  @Field(() => ID)
  id: string;

  @Field()
  connectionId: string;

  @Field()
  eventType: string;

  @Field()
  status: string; // 'SUCCESS', 'FAILED', 'PENDING'

  @Field()
  timestamp: string;

  @Field({ nullable: true })
  payload?: string;
}

@InputType()
export class UpdateConnectionStatusInput {
  @Field(() => ID)
  id: string;

  @Field()
  status: string;

  @Field({ nullable: true })
  errorMessage?: string;
}
