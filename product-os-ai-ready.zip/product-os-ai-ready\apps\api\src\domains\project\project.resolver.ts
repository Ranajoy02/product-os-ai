import {
  Resolver,
  Query,
  Mutation,
  Args,
  ObjectType,
  Field,
  ID,
} from '@nestjs/graphql';
import { ProjectService } from './project.service';

@ObjectType()
export class Project {
  @Field(() => ID)
  id: string;

  @Field()
  name: string;

  @Field({ nullable: true })
  description?: string;

  @Field()
  workspaceId: string;

  @Field()
  createdAt: Date;

  @Field()
  updatedAt: Date;
}

@Resolver(() => Project)
export class ProjectResolver {
  constructor(private readonly projectService: ProjectService) {}

  @Query(() => [Project], { name: 'projects' })
  async getProjects(@Args('workspaceId') workspaceId: string) {
    return this.projectService.getProjectsByWorkspace(workspaceId);
  }

  @Query(() => Project, { name: 'project' })
  async getProject(@Args('id', { type: () => ID }) id: string) {
    return this.projectService.getProjectDetails(id);
  }

  @Mutation(() => Project)
  async createProject(
    @Args('workspaceId') workspaceId: string,
    @Args('name') name: string,
    @Args('description', { nullable: true }) description?: string,
  ) {
    return this.projectService.createProject(workspaceId, {
      name,
      description,
    });
  }
}
