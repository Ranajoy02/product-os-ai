import { ObjectType, Field, ID, registerEnumType } from '@nestjs/graphql';

export enum ChannelType {
  GENERAL = 'GENERAL',
  PRODUCT = 'PRODUCT',
  PROJECT = 'PROJECT',
  TEAM = 'TEAM',
  DIRECT_MESSAGE = 'DIRECT_MESSAGE',
}

registerEnumType(ChannelType, {
  name: 'ChannelType',
});

@ObjectType()
export class Channel {
  @Field(() => ID)
  id: string;

  @Field()
  name: string;

  @Field(() => ChannelType)
  type: ChannelType;

  @Field({ nullable: true })
  productId?: string;

  @Field({ nullable: true })
  projectId?: string;

  @Field({ nullable: true })
  teamId?: string;
}

@ObjectType()
export class ChannelMember {
  @Field(() => ID)
  id: string;

  @Field()
  userId: string;

  @Field()
  channelId: string;
}

@ObjectType()
export class Message {
  @Field(() => ID)
  id: string;

  @Field()
  content: string;

  @Field()
  channelId: string;

  @Field()
  senderId: string;

  @Field({ nullable: true })
  threadId?: string;
}
