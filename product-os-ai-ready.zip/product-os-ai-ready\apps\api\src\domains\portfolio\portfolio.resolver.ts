import { Resolver, Query, Mutation, Args } from '@nestjs/graphql';
import { PortfolioService } from './portfolio.service';
import {
  PortfolioIntelligence,
  SimulatePortfolioAllocationInput,
  SimulatedOutcome,
} from './models/portfolio.model';

@Resolver(() => PortfolioIntelligence)
export class PortfolioResolver {
  constructor(private readonly portfolioService: PortfolioService) {}

  @Query(() => PortfolioIntelligence)
  getPortfolioIntelligence(): PortfolioIntelligence {
    return this.portfolioService.getPortfolioIntelligence();
  }

  @Mutation(() => SimulatedOutcome)
  simulatePortfolioAllocation(
    @Args('input') input: SimulatePortfolioAllocationInput,
  ): SimulatedOutcome {
    return this.portfolioService.simulatePortfolioAllocation(input);
  }
}
