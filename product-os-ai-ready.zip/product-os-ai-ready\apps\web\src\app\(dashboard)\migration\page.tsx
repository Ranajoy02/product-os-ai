'use client';

import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { DownloadCloud, Route, CheckSquare, RefreshCw, ShieldCheck, Play, Server, Layers, AlertCircle } from 'lucide-react';
import { gql } from '@apollo/client';
import { useQuery } from '@apollo/experimental-nextjs-app-support/ssr';
import { toast } from 'sonner';

const GET_MIGRATIONS = gql`
  query GetMigrationSimulations {
    getMigrationSimulations {
      id
      sourceSystem
      status
      totalRecords
      migratedRecords
      errorRecords
    }
  }
`;

export default function MigrationCenter() {
  const { data, loading, error } = useQuery<any>(GET_MIGRATIONS);
  const [activeTab, setActiveTab] = useState('Overview');

  if (loading) return <div className="p-8 text-slate-500 animate-pulse">Loading Migration Center...</div>;
  if (error) return <div className="p-8 text-rose-500">Error: {error.message}</div>;

  const migrations = data?.getMigrationSimulations || [];

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Enterprise Migration Center</h1>
          <p className="text-slate-500 mt-1">Seamlessly port legacy data from Jira, Asana, Monday, and Notion into ProductOS AI.</p>
        </div>
        <Button className="bg-indigo-600 hover:bg-indigo-700" onClick={() => toast.success('Initializing Migration Setup Wizard...')}>
          <Play className="w-4 h-4 mr-2 fill-current" /> Start New Migration
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Active Migrations List */}
        <div className="lg:col-span-1 space-y-4">
          <h3 className="font-bold text-slate-900 uppercase text-xs tracking-widest mb-4">Active & Past Migrations</h3>
          
          {migrations.map((migration: any) => (
            <Card key={migration.id} className="border-slate-200 shadow-sm cursor-pointer hover:border-indigo-300 transition-colors bg-white">
              <CardContent className="p-4 flex items-center gap-4">
                <div className="w-12 h-12 bg-slate-100 rounded-lg flex items-center justify-center">
                  <Server className="w-6 h-6 text-slate-600" />
                </div>
                <div className="flex-1">
                  <div className="font-bold text-slate-900">{migration.sourceSystem} Migration</div>
                  <div className="text-xs text-slate-500 flex items-center justify-between mt-1">
                    <span>{migration.status}</span>
                    <span className="font-mono text-indigo-600 font-bold">{Math.round((migration.migratedRecords / migration.totalRecords) * 100) || 0}%</span>
                  </div>
                  {/* Mini Progress Bar */}
                  <div className="w-full h-1.5 bg-slate-100 rounded-full mt-2 overflow-hidden">
                    <div 
                      className="h-full bg-indigo-500" 
                      style={{ width: `${(migration.migratedRecords / migration.totalRecords) * 100}%` }}
                    ></div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}

          <Card className="border-dashed border-2 border-slate-200 bg-transparent shadow-none cursor-pointer hover:bg-slate-50 transition-colors">
            <CardContent className="p-4 flex flex-col items-center justify-center text-center text-slate-500 gap-2 h-24">
              <span className="font-bold text-sm">+ Add System</span>
            </CardContent>
          </Card>
        </div>

        {/* Selected Migration Detail & Simulation Flow */}
        <div className="lg:col-span-2">
          <Card className="border-slate-200 shadow-sm h-full">
            <CardHeader className="border-b border-slate-100 bg-slate-50/50">
              <CardTitle className="text-xl">Migration Wizard: Jira Data Center</CardTitle>
              <p className="text-sm text-slate-500 mt-1">Simulated view of the 5-stage automated migration process.</p>
            </CardHeader>
            <CardContent className="p-8">
              
              {/* Vertical Stepper */}
              <div className="space-y-8 relative before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-slate-200 before:to-transparent">
                
                {/* Step 1 */}
                <div className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full border border-white bg-indigo-50 text-indigo-600 shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 z-10">
                    <DownloadCloud className="w-5 h-5" />
                  </div>
                  <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-4 rounded border border-indigo-100 bg-white shadow-sm">
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="font-bold text-slate-900">1. Data Import</h4>
                      <span className="text-xs font-bold bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded">Complete</span>
                    </div>
                    <p className="text-sm text-slate-500">Secure connection established via REST API. Extracted 42,000 Issues, 15 Projects, and 124 Users.</p>
                  </div>
                </div>

                {/* Step 2 */}
                <div className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full border border-white bg-indigo-50 text-indigo-600 shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 z-10">
                    <Route className="w-5 h-5" />
                  </div>
                  <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-4 rounded border border-indigo-100 bg-white shadow-sm">
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="font-bold text-slate-900">2. Schema Mapping</h4>
                      <span className="text-xs font-bold bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded">Complete</span>
                    </div>
                    <p className="text-sm text-slate-500">Jira Epics mapped to ProductOS Initiatives. Sprints mapped to Release Workflows. Custom fields auto-detected.</p>
                  </div>
                </div>

                {/* Step 3 */}
                <div className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full border border-white bg-indigo-600 text-white shadow ring-4 ring-indigo-100 shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 z-10">
                    <CheckSquare className="w-5 h-5" />
                  </div>
                  <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-4 rounded border-2 border-indigo-500 bg-indigo-50/30 shadow-md relative">
                    <div className="absolute -left-2 top-1/2 -translate-y-1/2 w-4 h-4 bg-indigo-500 rotate-45 hidden md:block md:group-odd:hidden"></div>
                    <div className="absolute -right-2 top-1/2 -translate-y-1/2 w-4 h-4 bg-indigo-500 rotate-45 hidden md:group-odd:block"></div>
                    
                    <div className="flex items-center justify-between mb-1 relative z-10">
                      <h4 className="font-bold text-indigo-900">3. Data Validation</h4>
                      <span className="text-xs font-bold bg-amber-100 text-amber-700 px-2 py-0.5 rounded flex items-center gap-1"><RefreshCw className="w-3 h-3 animate-spin" /> In Progress</span>
                    </div>
                    <p className="text-sm text-indigo-700/80 relative z-10">Checking referential integrity for issue links and attachments. 14 orphaned tasks detected and flagged for review.</p>
                    <div className="mt-3 flex gap-2 relative z-10">
                      <Button size="sm" variant="outline" className="bg-white">Review Orphans</Button>
                      <Button size="sm" className="bg-indigo-600 hover:bg-indigo-700">Auto-Resolve</Button>
                    </div>
                  </div>
                </div>

                {/* Step 4 */}
                <div className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group opacity-50">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full border border-white bg-slate-100 text-slate-400 shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 z-10">
                    <RefreshCw className="w-5 h-5" />
                  </div>
                  <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-4 rounded border border-slate-200 bg-white">
                    <h4 className="font-bold text-slate-900 mb-1">4. Conversion</h4>
                    <p className="text-sm text-slate-500">Transforming payloads and inserting into ProductOS Graph Database.</p>
                  </div>
                </div>

                {/* Step 5 */}
                <div className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group opacity-50">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full border border-white bg-slate-100 text-slate-400 shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 z-10">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-4 rounded border border-slate-200 bg-white">
                    <h4 className="font-bold text-slate-900 mb-1">5. Verification</h4>
                    <p className="text-sm text-slate-500">Final sanity check, relationship validation, and migration sign-off.</p>
                  </div>
                </div>

              </div>

            </CardContent>
          </Card>
        </div>

      </div>
    </div>
  );
}
