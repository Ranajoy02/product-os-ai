import { Field, ObjectType, ID, Float } from '@nestjs/graphql';

@ObjectType()
export class Outcome {
  @Field(() => ID)
  id: string;

  @Field()
  businessGoals: string;

  @Field()
  kpiTargets: string;

  @Field(() => Float)
  kpiAchievement: number;

  @Field(() => Float)
  roi: number;

  @Field()
  customerImpact: string;

  @Field()
  strategicSuccess: string;

  @Field()
  createdAt: Date;

  @Field()
  updatedAt: Date;
}
