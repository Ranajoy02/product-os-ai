'use client';

import React, { useCallback } from 'react';
import ReactFlow, { 
  Background, 
  Controls, 
  MiniMap, 
  useNodesState, 
  useEdgesState, 
  MarkerType 
} from 'reactflow';
import 'reactflow/dist/style.css';

const initialNodes = [
  { id: '1', position: { x: 50, y: 150 }, data: { label: 'Ideation' }, type: 'input', style: { background: '#fff', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '10px 20px', fontWeight: 'bold' } },
  { id: '2', position: { x: 250, y: 150 }, data: { label: 'Development' }, style: { background: '#fff', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '10px 20px', fontWeight: 'bold' } },
  { id: '3', position: { x: 450, y: 150 }, data: { label: 'QA Review' }, style: { background: '#fff', border: '2px solid #ef4444', borderRadius: '8px', padding: '10px 20px', fontWeight: 'bold', color: '#b91c1c' } }, // Bottleneck node
  { id: '4', position: { x: 650, y: 150 }, data: { label: 'Approval Gate' }, style: { background: '#eef2ff', border: '1px solid #c7d2fe', borderRadius: '8px', padding: '10px 20px', fontWeight: 'bold', color: '#4338ca' } },
  { id: '5', position: { x: 850, y: 150 }, data: { label: 'Release' }, type: 'output', style: { background: '#fff', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '10px 20px', fontWeight: 'bold' } },
];

const initialEdges = [
  { id: 'e1-2', source: '1', target: '2', type: 'smoothstep', markerEnd: { type: MarkerType.ArrowClosed, color: '#94a3b8' }, style: { stroke: '#94a3b8', strokeWidth: 2 } },
  { id: 'e2-3', source: '2', target: '3', type: 'smoothstep', markerEnd: { type: MarkerType.ArrowClosed, color: '#ef4444' }, style: { stroke: '#ef4444', strokeWidth: 3 }, animated: true, label: 'High Traffic' },
  { id: 'e3-4', source: '3', target: '4', type: 'smoothstep', markerEnd: { type: MarkerType.ArrowClosed, color: '#94a3b8' }, style: { stroke: '#94a3b8', strokeWidth: 2 } },
  { id: 'e4-5', source: '4', target: '5', type: 'smoothstep', markerEnd: { type: MarkerType.ArrowClosed, color: '#94a3b8' }, style: { stroke: '#94a3b8', strokeWidth: 2 } },
];

interface WorkflowCanvasProps {
  heatmapEnabled?: boolean;
}

export function WorkflowCanvas({ heatmapEnabled = false }: WorkflowCanvasProps) {
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);

  // Apply heatmap styling if enabled
  const styledNodes = heatmapEnabled ? nodes.map(node => {
    if (node.id === '3') {
      return { ...node, style: { ...node.style, background: '#fee2e2', boxShadow: '0 0 20px #ef4444' } };
    }
    return node;
  }) : nodes;

  return (
    <div className="w-full h-full rounded-lg overflow-hidden">
      <ReactFlow
        nodes={styledNodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        fitView
        attributionPosition="bottom-right"
      >
        <Background color={heatmapEnabled ? '#ef4444' : '#94a3b8'} gap={16} />
        <Controls />
        <MiniMap nodeStrokeColor={(n) => {
          if (n.id === '3') return '#ef4444';
          if (n.id === '4') return '#4338ca';
          return '#e2e8f0';
        }} nodeColor={(n) => {
          if (n.id === '3') return heatmapEnabled ? '#fee2e2' : '#fff';
          if (n.id === '4') return '#eef2ff';
          return '#fff';
        }} />
      </ReactFlow>
    </div>
  );
}
