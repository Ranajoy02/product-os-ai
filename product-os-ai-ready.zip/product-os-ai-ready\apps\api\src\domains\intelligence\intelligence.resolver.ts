import { Resolver, Query, Mutation, Args, ID } from '@nestjs/graphql';
import { IntelligenceService } from './intelligence.service';
import {
  DecisionLog,
  ResourceAllocation,
  DeliveryIntelligence,
  ExecutiveBrief,
  DigitalTwin,
} from './models/intelligence.model';

@Resolver()
export class IntelligenceResolver {
  constructor(private readonly intelligenceService: IntelligenceService) {}

  @Query(() => [DecisionLog])
  async decisionLogs(): Promise<DecisionLog[]> {
    return this.intelligenceService.getDecisionLogs();
  }

  @Query(() => [ResourceAllocation])
  async resourceAllocations(): Promise<ResourceAllocation[]> {
    return this.intelligenceService.getResourceAllocations();
  }

  @Query(() => DeliveryIntelligence)
  async getDeliveryIntelligence(
    @Args('entityId', { type: () => ID }) entityId: string,
  ): Promise<DeliveryIntelligence> {
    return this.intelligenceService.getDeliveryIntelligence(entityId);
  }

  @Query(() => ExecutiveBrief)
  async generateExecutiveBrief(): Promise<ExecutiveBrief> {
    return this.intelligenceService.generateExecutiveBrief();
  }

  @Query(() => DigitalTwin)
  async getDigitalTwin(
    @Args('entityId', { type: () => ID }) entityId: string,
  ): Promise<DigitalTwin> {
    return this.intelligenceService.getDigitalTwin(entityId);
  }

  @Mutation(() => DecisionLog)
  async createDecisionLog(
    @Args('title') title: string,
    @Args('context') context: string,
    @Args('ownerId') ownerId: string,
    @Args('outcome', { nullable: true }) outcome?: string,
  ): Promise<DecisionLog> {
    return this.intelligenceService.createDecisionLog({
      title,
      context,
      ownerId,
      outcome,
    });
  }
}
