'use client';

import React from 'react';
import { RoadmapGantt } from '@/components/roadmap/RoadmapGantt';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ShieldAlert, TrendingUp, Target, Activity } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';

const healthData = [
  { name: 'On Track', value: 60, color: '#10b981' },
  { name: 'At Risk', value: 25, color: '#f59e0b' },
  { name: 'Delayed', value: 15, color: '#ef4444' },
];

export default function RoadmapCommandCenterPage() {
  return (
    <div className="p-8 max-w-[1600px] mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Roadmap Command Center</h1>
        <p className="text-slate-500 mt-2">Forecast risk and track dependencies across your portfolio</p>
      </div>

      {/* Top Aggregation Panel */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="md:col-span-1">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Portfolio Health</CardTitle>
          </CardHeader>
          <CardContent className="relative">
            <ResponsiveContainer width="100%" height={160}>
              <PieChart>
                <Pie
                  data={healthData}
                  innerRadius={30}
                  outerRadius={50}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {healthData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none mt-4">
              <span className="text-lg font-bold">60%</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-rose-500" />
              Global Risk Score
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-rose-600 mb-2">High</div>
            <p className="text-sm text-slate-500">Driven by 3 blocked critical-path tasks.</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Activity className="w-4 h-4 text-indigo-500" />
              AI Delivery Forecast
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-indigo-600 mb-2">+4 Days</div>
            <p className="text-sm text-slate-500">Projected slip for Q3 Security Goal.</p>
          </CardContent>
        </Card>

        <Card className="bg-indigo-900 text-slate-100 border-indigo-800">
          <CardHeader className="pb-2 border-b border-indigo-800">
            <CardTitle className="text-sm font-medium flex items-center gap-2 text-indigo-300">
              <Target className="w-4 h-4" /> Impact Analysis Layer
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-4 space-y-3 text-xs">
            <div className="flex justify-between items-center bg-indigo-950 p-2 rounded border border-indigo-800">
              <span>Task: JWT Service</span>
              <span className="text-rose-400 font-bold">BLOCKED</span>
            </div>
            <div className="text-center text-indigo-500">↓ impacts</div>
            <div className="flex justify-between items-center bg-indigo-950 p-2 rounded border border-indigo-800">
              <span>Release 2.4</span>
              <span className="text-amber-400 font-bold">AT RISK</span>
            </div>
            <div className="text-center text-indigo-500">↓ impacts</div>
            <div className="flex justify-between items-center bg-indigo-950 p-2 rounded border border-indigo-800">
              <span>Goal: Q3 Security</span>
              <span className="text-rose-400 font-bold">DELAYED</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Gantt */}
      <div className="bg-white border rounded-lg shadow-sm overflow-hidden flex flex-col">
        <div className="p-4 border-b bg-slate-50 flex justify-between items-center">
          <h2 className="font-semibold">Strategic Roadmap</h2>
        </div>
        <RoadmapGantt />
      </div>

      {/* Visual Intelligence Block */}
      <Card className="bg-slate-900 text-slate-100 border-slate-800">
        <CardHeader className="pb-3 border-b border-slate-800">
          <CardTitle className="text-lg font-semibold flex items-center gap-2">
            <span className="text-indigo-400">✦</span> Visual Intelligence Analysis
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-4">
          <div className="grid md:grid-cols-4 gap-6 text-sm">
            <div>
              <span className="text-slate-400 font-semibold block mb-1 uppercase tracking-wider text-xs">What is happening?</span>
              <p>The "Q3 Security" strategic goal is currently stalled due to downstream dependencies.</p>
            </div>
            <div>
              <span className="text-slate-400 font-semibold block mb-1 uppercase tracking-wider text-xs">Why is it happening?</span>
              <p>A granular task ("JWT Service") under the "OAuth Implementation" epic is completely blocked.</p>
            </div>
            <div>
              <span className="text-slate-400 font-semibold block mb-1 uppercase tracking-wider text-xs">What happens next?</span>
              <p>The AI Forecast predicts a 4-day cascading delay to Release 2.4 if unmitigated.</p>
            </div>
            <div className="bg-indigo-950/50 p-3 rounded-md border border-indigo-900/50">
              <span className="text-indigo-300 font-semibold block mb-1 uppercase tracking-wider text-xs">Business Impact</span>
              <p className="text-rose-400 font-medium">Critical. Delaying Q3 Security impacts compliance deadlines for Enterprise clients.</p>
            </div>
          </div>
        </CardContent>
      </Card>

    </div>
  );
}
