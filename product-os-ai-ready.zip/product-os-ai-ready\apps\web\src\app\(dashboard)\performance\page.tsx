"use client";

import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Activity,
  AlertTriangle,
  Award,
  ChevronDown,
  Download,
  Flame,
  Search,
  TrendingUp,
  UserCheck
} from 'lucide-react';
import { useQuery } from '@apollo/experimental-nextjs-app-support/ssr';
import { gql } from '@apollo/client';

const GET_PERFORMANCE_SCORES = gql`
  query GetPerformanceScores {
    getPerformanceScores {
      id
      contributionScore
      deliveryScore
      collaborationScore
      burnoutRisk
      user {
        id
        firstName
        lastName
        email
        role
      }
    }
  }
`;

export default function Performance() {
  const { data, loading, error } = useQuery<any>(GET_PERFORMANCE_SCORES);

  const scores = data?.getPerformanceScores || [];

  const avgContribution = scores.length > 0
    ? (scores.reduce((acc: number, curr: any) => acc + curr.contributionScore, 0) / scores.length).toFixed(1)
    : "8.4";
  const avgDelivery = scores.length > 0
    ? (scores.reduce((acc: number, curr: any) => acc + curr.deliveryScore, 0) / scores.length).toFixed(0)
    : "92";
  const avgCollaboration = scores.length > 0
    ? (scores.reduce((acc: number, curr: any) => acc + curr.collaborationScore, 0) / scores.length).toFixed(1)
    : "7.8";

  const highBurnoutRiskUsers = scores.filter((score: any) => score.burnoutRisk > 0.7);
  const highBurnoutCount = scores.length > 0 ? highBurnoutRiskUsers.length : 3;

  return (
    <div className="p-8 space-y-8 max-w-[1600px] mx-auto">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-slate-900">Performance Intelligence</h1>
          <p className="text-muted-foreground mt-2 text-sm">
            AI-driven contribution tracking, delivery scoring, and burnout detection.
          </p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="bg-white">
            <Download className="w-4 h-4 mr-2" /> Export Data
          </Button>
          <Button className="bg-indigo-600 hover:bg-indigo-700">
            Generate Review Packets
          </Button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4 items-center justify-between border-b border-slate-200 pb-4">
        <div className="flex items-center gap-2 w-full md:w-auto">
          <div className="relative flex-1 md:w-80">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input 
              placeholder="Search employee or team..." 
              className="pl-9 h-10 bg-white border-slate-200"
            />
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="h-10 bg-white">
            Department: Engineering <ChevronDown className="w-4 h-4 ml-2" />
          </Button>
          <Button variant="outline" size="sm" className="h-10 bg-white">
            Period: Q3 2023 <ChevronDown className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-white shadow-sm border-slate-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500 mb-1">Avg Contribution Score</p>
                <h3 className="text-3xl font-bold text-slate-900">{avgContribution}<span className="text-lg text-slate-500 font-normal">/10</span></h3>
              </div>
              <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center">
                <Award className="w-6 h-6" />
              </div>
            </div>
            <div className="mt-4 flex items-center text-sm">
              <TrendingUp className="w-4 h-4 text-emerald-500 mr-1" />
              <span className="text-emerald-600 font-medium">+0.2</span>
              <span className="text-slate-500 ml-1">vs last quarter</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-slate-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500 mb-1">Avg Delivery Score</p>
                <h3 className="text-3xl font-bold text-slate-900">{avgDelivery}<span className="text-lg text-slate-500 font-normal">%</span></h3>
              </div>
              <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center">
                <Activity className="w-6 h-6" />
              </div>
            </div>
            <div className="mt-4 flex items-center text-sm">
              <TrendingUp className="w-4 h-4 text-emerald-500 mr-1" />
              <span className="text-emerald-600 font-medium">+5%</span>
              <span className="text-slate-500 ml-1">on-time delivery</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-sm border-slate-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500 mb-1">Collaboration Index</p>
                <h3 className="text-3xl font-bold text-slate-900">{avgCollaboration}<span className="text-lg text-slate-500 font-normal">/10</span></h3>
              </div>
              <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center">
                <UserCheck className="w-6 h-6" />
              </div>
            </div>
            <div className="mt-4 flex items-center text-sm">
              <span className="text-slate-500">Based on peer reviews & comms</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-rose-50 shadow-sm border-rose-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-rose-700 mb-1">High Burnout Risk</p>
                <h3 className="text-3xl font-bold text-rose-900">{highBurnoutCount}<span className="text-lg text-rose-700 font-normal"> Team Members</span></h3>
              </div>
              <div className="w-12 h-12 bg-rose-100 text-rose-600 rounded-xl flex items-center justify-center">
                <Flame className="w-6 h-6" />
              </div>
            </div>
            <div className="mt-4 flex items-center text-sm">
              <AlertTriangle className="w-4 h-4 text-rose-500 mr-1" />
              <span className="text-rose-700 font-medium">Requires immediate intervention</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Burnout Risk Alerts */}
      <Card className="border-rose-200 shadow-sm overflow-hidden">
        <div className="bg-rose-50 border-b border-rose-100 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2 text-rose-800">
            <Flame className="w-5 h-5" />
            <h3 className="font-semibold">Burnout Risk Alerts</h3>
          </div>
        </div>
        <div className="divide-y divide-slate-100 bg-white">
          {loading ? (
            <div className="p-8 text-center text-slate-500">Loading performance data...</div>
          ) : error ? (
            <div className="p-8 text-center text-rose-500">Failed to load performance data</div>
          ) : scores.length > 0 ? (
            highBurnoutRiskUsers.map((score: any) => {
              const initials = score.user.firstName && score.user.lastName 
                ? `${score.user.firstName[0]}${score.user.lastName[0]}`
                : 'U';
              return (
                <div key={score.id} className="p-4 px-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full border-2 border-white bg-rose-100 flex items-center justify-center text-xs text-rose-700 font-bold">
                      {initials}
                    </div>
                    <div>
                      <p className="font-semibold text-slate-900">{score.user.firstName} {score.user.lastName}</p>
                      <p className="text-xs text-slate-500">{score.user.role} • {score.user.email}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-6">
                    <div className="text-right">
                      <p className="text-xs text-slate-500 font-medium uppercase tracking-wider mb-1">Burnout Risk</p>
                      <p className="font-semibold text-rose-600">{(score.burnoutRisk * 100).toFixed(0)}%</p>
                    </div>
                    <Button size="sm" variant="outline" className="text-rose-700 hover:bg-rose-50 border-rose-200">Mitigate Plan</Button>
                  </div>
                </div>
              );
            })
          ) : (
            <>
              {/* Fallback to static UI if no data */}
              <div className="p-4 px-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full border-2 border-white bg-blue-200 flex items-center justify-center text-xs text-blue-700 font-bold">SJ</div>
                  <div>
                    <p className="font-semibold text-slate-900">Sarah Jenkins</p>
                    <p className="text-xs text-slate-500">Lead Frontend Engineer • Frontend Platform Squad</p>
                  </div>
                </div>
                <div className="flex items-center gap-6">
                  <div className="text-right">
                    <p className="text-xs text-slate-500 font-medium uppercase tracking-wider mb-1">Utilization</p>
                    <p className="font-semibold text-rose-600">145%</p>
                  </div>
                  <div className="text-right hidden sm:block">
                    <p className="text-xs text-slate-500 font-medium uppercase tracking-wider mb-1">Consecutive Weeks &gt; 100%</p>
                    <p className="font-semibold text-rose-600">4 weeks</p>
                  </div>
                  <Button size="sm" variant="outline" className="text-rose-700 hover:bg-rose-50 border-rose-200">Mitigate Plan</Button>
                </div>
              </div>
            </>
          )}
        </div>
      </Card>

      {/* Leaderboard Stub */}
      <Card className="bg-white shadow-sm border-slate-200">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg">Top Performers</CardTitle>
              <CardDescription>Based on aggregate contribution and delivery scores</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="h-64 rounded-lg bg-slate-50 border border-slate-100 flex flex-col items-center justify-center text-slate-400">
              <Award className="w-8 h-8 mb-3 opacity-50" />
              <p className="text-sm font-medium">Loading...</p>
            </div>
          ) : scores.length > 0 ? (
            <div className="divide-y divide-slate-100">
              {scores
                .sort((a: any, b: any) => (b.contributionScore + b.deliveryScore) - (a.contributionScore + a.deliveryScore))
                .slice(0, 5)
                .map((score: any, index: number) => (
                  <div key={score.id} className="py-3 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-slate-400 font-medium w-4">{index + 1}</span>
                      <p className="font-medium text-slate-900">{score.user.firstName} {score.user.lastName}</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="text-xs text-slate-500">Contribution</p>
                        <p className="font-semibold">{score.contributionScore.toFixed(1)}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-slate-500">Delivery</p>
                        <p className="font-semibold">{score.deliveryScore}%</p>
                      </div>
                    </div>
                  </div>
                ))}
            </div>
          ) : (
            <div className="h-64 rounded-lg bg-slate-50 border border-slate-100 flex flex-col items-center justify-center text-slate-400">
              <Award className="w-8 h-8 mb-3 opacity-50" />
              <p className="text-sm font-medium">Performance Leaderboard Loading...</p>
            </div>
          )}
        </CardContent>
      </Card>
      
    </div>
  );
}
