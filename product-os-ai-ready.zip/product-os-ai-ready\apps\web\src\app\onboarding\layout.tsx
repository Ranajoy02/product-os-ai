import React from 'react';

export default function OnboardingLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-xl">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-semibold tracking-tight">ProductOS AI</h1>
          <p className="text-muted-foreground mt-2">AI-Native Product Delivery Operating System</p>
        </div>
        {children}
      </div>
    </div>
  );
}
