import { Injectable } from '@nestjs/common';
import { ConnectionStatus, SyncHealth, EventFlow, UpdateConnectionStatusInput } from './models/integration.model';

@Injectable()
export class IntegrationService {
  private connections: ConnectionStatus[] = [
    {
      id: 'conn-1',
      provider: 'Salesforce',
      status: 'CONNECTED',
      lastSyncAt: new Date().toISOString(),
    },
  ];

  private syncHealths: SyncHealth[] = [
    {
      id: 'health-1',
      connectionId: 'conn-1',
      successRate: 99.5,
      pendingEventsCount: 0,
      failedEventsCount: 2,
    },
  ];

  private eventFlows: EventFlow[] = [
    {
      id: 'event-1',
      connectionId: 'conn-1',
      eventType: 'CONTACT_UPDATE',
      status: 'SUCCESS',
      timestamp: new Date().toISOString(),
      payload: '{"contactId": "123", "email": "test@example.com"}',
    },
  ];

  async getConnectionStatuses(): Promise<ConnectionStatus[]> {
    return this.connections;
  }

  async getSyncHealth(connectionId: string): Promise<SyncHealth | undefined> {
    return this.syncHealths.find(h => h.connectionId === connectionId);
  }

  async getEventFlows(connectionId: string): Promise<EventFlow[]> {
    return this.eventFlows.filter(e => e.connectionId === connectionId);
  }

  async updateConnectionStatus(input: UpdateConnectionStatusInput): Promise<ConnectionStatus> {
    const connIndex = this.connections.findIndex(c => c.id === input.id);
    if (connIndex > -1) {
      this.connections[connIndex] = {
        ...this.connections[connIndex],
        status: input.status,
        errorMessage: input.errorMessage,
        lastSyncAt: input.status === 'CONNECTED' ? new Date().toISOString() : this.connections[connIndex].lastSyncAt,
      };
      return this.connections[connIndex];
    }
    throw new Error('Connection not found');
  }
}
