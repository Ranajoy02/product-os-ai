import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../core/prisma/prisma.service';

@Injectable()
export class KnowledgeService {
  constructor(private prisma: PrismaService) {}

  /**
   * Traverses the knowledge graph starting from a specific node ID up to a certain depth.
   * Uses a recursive CTE to find all paths.
   */
  async traverseGraph(startNodeId: string, maxDepth: number = 3) {
    const rawQuery = `
      WITH RECURSIVE graph_path AS (
        -- Anchor member: start at the specific node's outgoing edges
        SELECT 
          sourceId, 
          targetId, 
          relation,
          1 as depth
        FROM "KnowledgeEdge"
        WHERE "sourceId" = $1

        UNION ALL

        -- Recursive member: follow the edges
        SELECT 
          e.sourceId, 
          e.targetId, 
          e.relation,
          gp.depth + 1
        FROM "KnowledgeEdge" e
        INNER JOIN graph_path gp ON e."sourceId" = gp.targetId
        WHERE gp.depth < $2
      )
      SELECT * FROM graph_path;
    `;

    // Wait until Prisma is available
    const edges = await this.prisma.$queryRawUnsafe(
      rawQuery,
      startNodeId,
      maxDepth,
    );
    return edges;
  }

  async createNode(entityId: string, entityType: string) {
    return this.prisma.knowledgeNode.create({
      data: {
        entityId,
        entityType,
      },
    });
  }

  async createEdge(sourceId: string, targetId: string, relation: string) {
    return this.prisma.knowledgeEdge.create({
      data: {
        sourceId,
        targetId,
        relation,
      },
    });
  }
}
