import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  MessageBody,
  ConnectedSocket,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { JwtService } from '@nestjs/jwt';

@WebSocketGateway({
  cors: {
    origin: '*',
  },
})
export class EventsGateway {
  @WebSocketServer()
  server: Server;

  constructor(private jwtService: JwtService) {}

  handleConnection(client: Socket) {
    try {
      const token = client.handshake.auth.token?.split(' ')[1];
      if (token) {
        const payload = this.jwtService.verify(token, {
          secret: process.env.JWT_SECRET || 'super-secret-key',
        });
        client.data.user = payload;

        // Join organization room automatically
        if (payload.organizationId) {
          client.join(`org_${payload.organizationId}`);
        }
      } else {
        client.disconnect();
      }
    } catch (e) {
      client.disconnect();
    }
  }

  @SubscribeMessage('joinProject')
  handleJoinProject(
    @MessageBody() projectId: string,
    @ConnectedSocket() client: Socket,
  ) {
    client.join(`project_${projectId}`);
    return { event: 'joined', data: projectId };
  }

  @SubscribeMessage('leaveProject')
  handleLeaveProject(
    @MessageBody() projectId: string,
    @ConnectedSocket() client: Socket,
  ) {
    client.leave(`project_${projectId}`);
  }

  broadcastTaskUpdate(projectId: string, task: any) {
    this.server.to(`project_${projectId}`).emit('taskUpdated', task);
  }
}
