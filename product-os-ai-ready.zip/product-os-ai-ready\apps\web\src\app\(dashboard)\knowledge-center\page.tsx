'use client';

import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Network, GitMerge, FileText, CheckCircle, Package, Layers, Activity, Target } from 'lucide-react';
import { motion } from 'framer-motion';
import ReactFlow, { Background, Controls } from 'reactflow';
import 'reactflow/dist/style.css';

// --- MOCK DATA FOR REACT FLOW (Mode 2) ---
const rfNodes = [
  { id: 'prd1', position: { x: 250, y: 50 }, data: { label: 'PRD: Secure Login' }, style: { background: '#f8fafc', border: '1px solid #cbd5e1' } },
  { id: 'epic1', position: { x: 250, y: 150 }, data: { label: 'Epic: OAuth Auth' }, style: { background: '#f8fafc', border: '1px solid #cbd5e1' } },
  { id: 'task1', position: { x: 150, y: 250 }, data: { label: 'Task: JWT Service' }, style: { background: '#fef2f2', border: '1px solid #fca5a5' } },
  { id: 'task2', position: { x: 350, y: 250 }, data: { label: 'Task: UI Form' }, style: { background: '#f0fdf4', border: '1px solid #86efac' } },
  { id: 'rel1', position: { x: 250, y: 350 }, data: { label: 'Release 2.4' }, style: { background: '#eef2ff', border: '1px solid #a5b4fc' } }
];

const rfEdges = [
  { id: 'e1', source: 'prd1', target: 'epic1', animated: true },
  { id: 'e2', source: 'epic1', target: 'task1' },
  { id: 'e3', source: 'epic1', target: 'task2' },
  { id: 'e4', source: 'task1', target: 'rel1' },
  { id: 'e5', source: 'task2', target: 'rel1' },
];

export default function KnowledgeCenterPage() {
  const [mode, setMode] = useState<'traceability' | 'explorer'>('traceability');

  return (
    <div className="p-8 max-w-[1400px] mx-auto space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Knowledge Center</h1>
          <p className="text-slate-500 mt-2">Explore the semantic relationships behind your product delivery</p>
        </div>
        <div className="bg-slate-100 p-1 rounded-lg flex border">
          <button 
            className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${mode === 'traceability' ? 'bg-white shadow-sm text-indigo-700' : 'text-slate-500 hover:text-slate-700'}`}
            onClick={() => setMode('traceability')}
          >
            Traceability View
          </button>
          <button 
            className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${mode === 'explorer' ? 'bg-white shadow-sm text-indigo-700' : 'text-slate-500 hover:text-slate-700'}`}
            onClick={() => setMode('explorer')}
          >
            Relationship Explorer
          </button>
        </div>
      </div>

      <div className="grid lg:grid-cols-4 gap-8">
        {/* Main Vis Area */}
        <div className="lg:col-span-3 bg-white border rounded-xl shadow-sm min-h-[600px] overflow-hidden flex flex-col">
          {mode === 'traceability' ? (
            <div className="p-8 flex-1 overflow-y-auto bg-slate-50/50">
              <div className="max-w-2xl mx-auto space-y-6">
                <h3 className="text-lg font-semibold text-slate-700 mb-8 border-b pb-4">Semantic Lineage Trace</h3>
                
                {[
                  { icon: FileText, title: 'PRD: Secure Authentication', desc: 'Auth v2.0 Requirements', color: 'text-blue-500', bg: 'bg-blue-100' },
                  { icon: GitMerge, title: 'Roadmap Item: Q3 Security', desc: 'Strategic Goal Alignment', color: 'text-indigo-500', bg: 'bg-indigo-100' },
                  { icon: Layers, title: 'Epic: OAuth Implementation', desc: 'Core Engineering Scope', color: 'text-purple-500', bg: 'bg-purple-100' },
                  { icon: CheckCircle, title: 'Task: Build JWT Service', desc: 'Backend assignment - Blocked', color: 'text-rose-500', bg: 'bg-rose-100' },
                  { icon: Activity, title: 'Approval: Security Audit', desc: 'Pending unblocking', color: 'text-amber-500', bg: 'bg-amber-100' },
                  { icon: Package, title: 'Release 2.4', desc: 'Targeting next week', color: 'text-emerald-500', bg: 'bg-emerald-100' }
                ].map((item, idx) => (
                  <motion.div 
                    key={idx}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.15 }}
                    className="relative pl-12"
                  >
                    {/* Connecting Line */}
                    {idx !== 5 && <div className="absolute left-[19px] top-10 bottom-[-24px] w-0.5 bg-slate-200" />}
                    
                    <div className="flex gap-4 items-start">
                      <div className={`absolute left-0 w-10 h-10 rounded-full ${item.bg} ${item.color} flex items-center justify-center border-4 border-slate-50 z-10`}>
                        <item.icon className="w-4 h-4" />
                      </div>
                      <div className="bg-white p-4 rounded-lg border shadow-sm flex-1 ml-2 hover:border-indigo-300 transition-colors cursor-pointer">
                        <h4 className="font-semibold text-slate-800">{item.title}</h4>
                        <p className="text-sm text-slate-500 mt-1">{item.desc}</p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          ) : (
            <div className="flex-1 w-full h-full relative">
               <ReactFlow nodes={rfNodes} edges={rfEdges} fitView attributionPosition="bottom-right">
                 <Background gap={16} />
                 <Controls />
               </ReactFlow>
            </div>
          )}
        </div>

        {/* Intelligence Context */}
        <div className="space-y-6">
          <Card className="bg-slate-900 text-slate-100 border-slate-800 shadow-xl">
            <CardHeader className="pb-3 border-b border-slate-800">
              <CardTitle className="text-lg font-semibold flex items-center gap-2">
                <span className="text-indigo-400">✦</span> Visual Intelligence
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4 space-y-5">
              <div>
                <span className="text-slate-400 font-semibold block mb-1 text-xs uppercase tracking-wider">What is happening?</span>
                <p className="text-sm">We are tracing the origin of <span className="font-semibold text-white">Release 2.4</span> backwards through its dependencies.</p>
              </div>
              <div>
                <span className="text-slate-400 font-semibold block mb-1 text-xs uppercase tracking-wider">Why is it happening?</span>
                <p className="text-sm">The "JWT Service" task is blocking the Security Audit approval, which is a hard dependency for this release.</p>
              </div>
              <div>
                <span className="text-slate-400 font-semibold block mb-1 text-xs uppercase tracking-wider">What happens next?</span>
                <p className="text-sm">If the task is resolved today, the lineage shows the Release can safely deploy.</p>
              </div>
              <div className="bg-indigo-950/50 p-3 rounded-md border border-indigo-900/50 mt-4">
                <span className="text-indigo-300 font-semibold block mb-1 text-xs uppercase tracking-wider">Business Impact</span>
                <p className="text-sm text-emerald-400">High Impact. Unblocking this lineage fulfills the "Q3 Security" Roadmap Strategic Goal.</p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-indigo-950 text-slate-100 border-indigo-900">
            <CardHeader className="pb-3 border-b border-indigo-900">
              <CardTitle className="text-lg font-semibold flex items-center gap-2 text-indigo-300">
                <Target className="w-5 h-5" /> Business Impact Layer
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4 flex items-center justify-between gap-2 text-xs overflow-x-auto">
              <div className="flex flex-col items-center flex-1 bg-indigo-900 p-3 rounded border border-indigo-800 min-w-[120px]">
                <span className="text-slate-400 mb-1">Task</span>
                <span className="font-semibold text-center">JWT Service</span>
                <span className="text-rose-400 font-bold mt-2">BLOCKED</span>
              </div>
              <div className="text-indigo-500 font-bold">→</div>
              <div className="flex flex-col items-center flex-1 bg-indigo-900 p-3 rounded border border-indigo-800 min-w-[120px]">
                <span className="text-slate-400 mb-1">Milestone</span>
                <span className="font-semibold text-center">Auth Upgrade</span>
                <span className="text-amber-400 font-bold mt-2">AT RISK</span>
              </div>
              <div className="text-indigo-500 font-bold">→</div>
              <div className="flex flex-col items-center flex-1 bg-indigo-900 p-3 rounded border border-indigo-800 min-w-[120px]">
                <span className="text-slate-400 mb-1">Release</span>
                <span className="font-semibold text-center">v2.4</span>
                <span className="text-amber-400 font-bold mt-2">AT RISK</span>
              </div>
              <div className="text-indigo-500 font-bold">→</div>
              <div className="flex flex-col items-center flex-1 bg-indigo-900 p-3 rounded border border-indigo-800 min-w-[120px]">
                <span className="text-slate-400 mb-1">Roadmap</span>
                <span className="font-semibold text-center">Q3 Security</span>
                <span className="text-rose-400 font-bold mt-2">DELAYED</span>
              </div>
              <div className="text-indigo-500 font-bold">→</div>
              <div className="flex flex-col items-center flex-1 bg-indigo-900 p-3 rounded border border-rose-900/50 min-w-[120px]">
                <span className="text-slate-400 mb-1">Business Outcome</span>
                <span className="font-semibold text-center text-white">Enterprise Sales</span>
                <span className="text-rose-400 font-bold mt-2 text-center">-$120k ARR<br/>Q3 Miss</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
