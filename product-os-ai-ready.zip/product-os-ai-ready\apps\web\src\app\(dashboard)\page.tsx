'use client';

import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Network, Activity, Workflow, AlertCircle, CheckCircle2, AlertTriangle, PlayCircle, Target } from 'lucide-react';
import { useDemoContext } from '@/store/demo-context';
import { DemoData } from '@/store/demo-data';

export default function HomeDeliveryIntelligence() {
  const { isDemoMode, activeNarrative } = useDemoContext();
  const data = isDemoMode ? DemoData[activeNarrative] : {
    health: 89,
    blockedTasks: 3,
    pendingApprovals: 2,
    delayedReleases: 1
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      {/* Attention Center Header */}
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold tracking-tight">Good Morning. Here is your Attention Center:</h1>
        <div className="flex gap-4 mt-4">
          <div className={`flex items-center gap-2 px-4 py-2 rounded-md font-medium ${data.blockedTasks > 0 ? 'bg-rose-100 text-rose-800' : 'bg-emerald-100 text-emerald-800'}`}>
            {data.blockedTasks > 0 ? <AlertCircle className="w-5 h-5" /> : <CheckCircle2 className="w-5 h-5" />} 
            {data.blockedTasks} Blocked Tasks
          </div>
          <div className="flex items-center gap-2 bg-amber-100 text-amber-800 px-4 py-2 rounded-md font-medium">
            <AlertTriangle className="w-5 h-5" /> {data.pendingApprovals} Pending Approvals
          </div>
          <div className={`flex items-center gap-2 px-4 py-2 rounded-md font-medium ${data.delayedReleases > 0 ? 'bg-rose-100 text-rose-800' : 'bg-emerald-100 text-emerald-800'}`}>
            {data.delayedReleases > 0 ? <AlertCircle className="w-5 h-5" /> : <CheckCircle2 className="w-5 h-5" />}
            {data.delayedReleases} Delayed Releases
          </div>
        </div>
      </div>

      {/* Intelligence Scorecards */}
      <div className="grid gap-6 md:grid-cols-3">
        <Card className={`border-${data.health > 80 ? 'emerald' : data.health > 50 ? 'amber' : 'rose'}-200`}>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">Product Health</CardTitle>
            <Activity className={`h-4 w-4 text-${data.health > 80 ? 'emerald' : data.health > 50 ? 'amber' : 'rose'}-500`} />
          </CardHeader>
          <CardContent>
            <div className={`text-3xl font-bold text-${data.health > 80 ? 'emerald' : data.health > 50 ? 'amber' : 'rose'}-600`}>{data.health} / 100</div>
            <p className={`text-xs mt-1 flex items-center gap-1 text-${data.health > 80 ? 'emerald' : data.health > 50 ? 'amber' : 'rose'}-600`}>
              {data.health > 80 ? <CheckCircle2 className="w-3 h-3" /> : <AlertTriangle className="w-3 h-3" />} 
              {data.health > 80 ? 'Trending UP' : 'Requires Attention'}
            </p>
          </CardContent>
        </Card>
        
        <Card className="border-amber-200">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">Workflow Health</CardTitle>
            <Workflow className="h-4 w-4 text-amber-500" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-amber-600">92 / 100</div>
            <p className="text-xs text-amber-600 mt-1 flex items-center gap-1">
              <AlertTriangle className="w-3 h-3" /> 2 Bottlenecks Detected
            </p>
          </CardContent>
        </Card>

        <Card className="border-slate-200">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">Release Readiness</CardTitle>
            <PlayCircle className="h-4 w-4 text-slate-500" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-slate-800">LOW RISK</div>
            <p className="text-xs text-slate-500 mt-1">
              ETA: On Track for Q3
            </p>
          </CardContent>
        </Card>
      </div>

      {/* AI Executive Summary */}
      <Card className="bg-indigo-50 border-indigo-100 shadow-sm">
        <CardContent className="p-6 flex flex-col md:flex-row items-start md:items-center gap-6">
          <div className="w-12 h-12 bg-indigo-600 rounded-full flex items-center justify-center flex-shrink-0 text-white font-bold text-xl">
            ✦
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-indigo-900 mb-1">AI Executive Summary</h3>
            <p className="text-indigo-800">
              "Release 2.1 is tracking well, but <span className="font-semibold">Backend Refactor</span> is currently blocked. Resolving this will clear 2 dependent approvals."
            </p>
            <div className="flex items-center gap-4 mt-3 text-sm font-medium text-indigo-600">
              <span className="bg-white/50 px-2 py-1 rounded">Confidence: 94%</span>
            </div>
          </div>
          <Button className="bg-indigo-600 hover:bg-indigo-700 text-white shrink-0">
            Resolve Now &rarr;
          </Button>
        </CardContent>
      </Card>

      {/* Bottom Drill-downs */}
      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Network className="w-4 h-4" /> Knowledge Insights
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-24 bg-slate-100 rounded-md border border-slate-200 flex items-center justify-center text-slate-400 mb-3">
              [Mini Graph View]
            </div>
            <p className="text-xs font-medium text-slate-600">+12% linked nodes this week</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              Team Capacity
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-slate-800 mb-2">85%</div>
            <div className="w-full bg-slate-100 h-2 rounded-full mb-3">
              <div className="bg-indigo-500 h-2 rounded-full w-[85%]"></div>
            </div>
            <p className="text-xs font-medium text-emerald-600 flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" /> Burnout Risk: LOW
            </p>
          </CardContent>
        </Card>

        {/* Intelligence Context */}
        <div className="space-y-6">
          <Card className="bg-slate-900 text-slate-100 border-slate-800">
            <CardHeader className="pb-3 border-b border-slate-800">
              <CardTitle className="text-lg font-semibold flex items-center gap-2">
                <span className="text-indigo-400">✦</span> Visual Intelligence
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4 space-y-4 text-sm">
              <div>
                <span className="text-slate-400 font-semibold block mb-1 uppercase tracking-wider text-xs">What is happening?</span>
                <p>3 engineering tasks are currently blocked in the Review stage.</p>
              </div>
              <div>
                <span className="text-slate-400 font-semibold block mb-1 uppercase tracking-wider text-xs">Why is it happening?</span>
                <p>The core bottleneck is the "JWT Service" task waiting for Security Audit approval.</p>
              </div>
              <div>
                <span className="text-slate-400 font-semibold block mb-1 uppercase tracking-wider text-xs">What happens next?</span>
                <p>If not approved today, Release 2.4 will miss its deployment window.</p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-indigo-950 text-slate-100 border-indigo-900">
            <CardHeader className="pb-3 border-b border-indigo-900">
              <CardTitle className="text-lg font-semibold flex items-center gap-2 text-indigo-300">
                <Target className="w-5 h-5" /> Business Impact Layer
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4 space-y-3 text-xs">
              <div className="flex justify-between items-center bg-indigo-900 p-3 rounded border border-indigo-800">
                <span>Task: JWT Service</span>
                <span className="text-rose-400 font-bold">BLOCKED</span>
              </div>
              <div className="text-center text-indigo-500">↓ impacts</div>
              <div className="flex justify-between items-center bg-indigo-900 p-3 rounded border border-indigo-800">
                <span>Milestone: Auth Upgrade</span>
                <span className="text-amber-400 font-bold">AT RISK</span>
              </div>
              <div className="text-center text-indigo-500">↓ impacts</div>
              <div className="flex justify-between items-center bg-indigo-900 p-3 rounded border border-indigo-800">
                <span>Release: 2.4</span>
                <span className="text-amber-400 font-bold">AT RISK</span>
              </div>
              <div className="text-center text-indigo-500">↓ impacts</div>
              <div className="flex justify-between items-center bg-indigo-900 p-3 rounded border border-indigo-800">
                <span>Roadmap: Q3 Security</span>
                <span className="text-rose-400 font-bold">DELAYED</span>
              </div>
              <div className="text-center text-indigo-500">↓ impacts</div>
              <div className="flex justify-between items-center bg-indigo-900 p-3 rounded border border-rose-900/50">
                <span className="font-semibold text-white">Business Outcome: Enterprise Sales</span>
                <span className="text-rose-400 font-bold text-right">-$120k ARR<br/>Q3 Miss</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
