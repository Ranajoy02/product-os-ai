'use client';

import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FileSignature, CheckCircle2, XCircle, Clock, AlertCircle, FileText, ChevronRight } from 'lucide-react';
import { toast } from 'sonner';

const MOCK_APPROVALS = [
  {
    id: 'app-1',
    type: 'PRD',
    title: 'HIPAA Compliance Audit Module',
    requester: 'Sarah Connor',
    project: 'Project Athena',
    status: 'PENDING',
    date: '2026-06-16T10:30:00Z',
    priority: 'High',
  },
  {
    id: 'app-2',
    type: 'Architecture',
    title: 'Telehealth Video Integration',
    requester: 'John Smith',
    project: 'Telemed Web',
    status: 'PENDING',
    date: '2026-06-15T14:20:00Z',
    priority: 'Medium',
  },
  {
    id: 'app-3',
    type: 'Change Request',
    title: 'Increase API Rate Limits',
    requester: 'Alice Chen',
    project: 'Core Platform',
    status: 'APPROVED',
    date: '2026-06-14T09:15:00Z',
    priority: 'Low',
  }
];

export default function ApprovalsPage() {
  const [approvals, setApprovals] = useState(MOCK_APPROVALS);

  const handleApprove = (id: string) => {
    setApprovals(prev => prev.map(a => a.id === id ? { ...a, status: 'APPROVED' } : a));
    toast.success('Approval granted successfully.');
  };

  const handleReject = (id: string) => {
    setApprovals(prev => prev.map(a => a.id === id ? { ...a, status: 'REJECTED' } : a));
    toast.error('Approval rejected.');
  };

  const getPriorityColor = (priority: string) => {
    switch(priority) {
      case 'High': return 'text-rose-600 bg-rose-50 border-rose-200';
      case 'Medium': return 'text-amber-600 bg-amber-50 border-amber-200';
      default: return 'text-slate-600 bg-slate-50 border-slate-200';
    }
  };

  const getStatusBadge = (status: string) => {
    switch(status) {
      case 'PENDING': return <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800"><Clock className="w-3 h-3" /> Pending Review</span>;
      case 'APPROVED': return <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800"><CheckCircle2 className="w-3 h-3" /> Approved</span>;
      case 'REJECTED': return <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-rose-100 text-rose-800"><XCircle className="w-3 h-3" /> Rejected</span>;
    }
  };

  const pendingCount = approvals.filter(a => a.status === 'PENDING').length;

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-slate-900 flex items-center gap-3">
            <FileSignature className="w-8 h-8 text-indigo-600" />
            Approvals & Sign-Offs
          </h1>
          <p className="text-slate-500 mt-2 text-lg">Review and manage pending product requirement documents and architecture decisions.</p>
        </div>
        <div className="bg-indigo-50 border border-indigo-100 px-4 py-2 rounded-xl flex items-center gap-3 shadow-sm">
          <div className="w-10 h-10 bg-indigo-600 rounded-full flex items-center justify-center text-white font-bold text-lg">
            {pendingCount}
          </div>
          <div className="text-sm font-medium text-indigo-900">
            Pending<br/>Approvals
          </div>
        </div>
      </div>

      <div className="grid gap-6">
        {approvals.map(approval => (
          <Card key={approval.id} className="border-slate-200 shadow-sm hover:shadow-md transition-shadow group overflow-hidden">
            <div className="flex flex-col md:flex-row">
              <div className="p-6 flex-1 flex flex-col justify-center">
                <div className="flex items-center gap-3 mb-2">
                  <span className={`px-2 py-1 rounded text-xs font-bold uppercase tracking-wider border ${getPriorityColor(approval.priority)}`}>
                    {approval.type}
                  </span>
                  {getStatusBadge(approval.status)}
                  <span className="text-sm text-slate-400 flex items-center gap-1">
                    <Clock className="w-3 h-3" /> {new Date(approval.date).toLocaleDateString()}
                  </span>
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-1 flex items-center gap-2">
                  <FileText className="w-5 h-5 text-slate-400" />
                  {approval.title}
                </h3>
                <div className="text-sm text-slate-500 flex items-center gap-4 mt-2">
                  <span className="flex items-center gap-1">
                    <div className="w-5 h-5 rounded-full bg-slate-200 flex items-center justify-center text-[10px] font-bold text-slate-600">
                      {approval.requester.charAt(0)}
                    </div>
                    {approval.requester}
                  </span>
                  <span className="text-slate-300">•</span>
                  <span>{approval.project}</span>
                </div>
              </div>
              
              <div className="bg-slate-50 border-t md:border-t-0 md:border-l border-slate-100 p-6 flex items-center justify-end gap-3 min-w-[280px]">
                {approval.status === 'PENDING' ? (
                  <>
                    <Button variant="outline" className="border-rose-200 text-rose-700 hover:bg-rose-50 flex-1" onClick={() => handleReject(approval.id)}>
                      Reject
                    </Button>
                    <Button className="bg-emerald-600 hover:bg-emerald-700 text-white flex-1" onClick={() => handleApprove(approval.id)}>
                      Approve
                    </Button>
                  </>
                ) : (
                  <Button variant="ghost" className="w-full text-slate-500" onClick={() => toast.info('Navigating to detail view...')}>
                    View Details <ChevronRight className="w-4 h-4 ml-1" />
                  </Button>
                )}
              </div>
            </div>
          </Card>
        ))}

        {approvals.length === 0 && (
          <div className="text-center py-24 bg-slate-50 border border-dashed border-slate-300 rounded-xl">
            <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto mb-4" />
            <h3 className="text-lg font-bold text-slate-900">All Caught Up!</h3>
            <p className="text-slate-500 mt-1">You have no pending approvals in your queue.</p>
          </div>
        )}
      </div>
    </div>
  );
}
