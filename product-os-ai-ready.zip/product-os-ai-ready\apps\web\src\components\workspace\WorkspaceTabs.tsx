'use client';

import React from 'react';
import { useWorkspaceStore, WorkspaceTab } from '@/store/workspace-context';
import { Button } from '@/components/ui/button';

export function WorkspaceTabs() {
  const { activeTab, setActiveTab } = useWorkspaceStore();

  const tabs: WorkspaceTab[] = [
    'Overview', 
    'Lifecycle', 
    'Documents', 
    'Communication', 
    'Approvals', 
    'Performance', 
    'Insights'
  ];

  return (
    <div className="flex items-center space-x-1 border-b px-4 bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800">
      {tabs.map((tab) => (
        <Button
          key={tab}
          variant="ghost"
          className={`rounded-none border-b-2 px-4 py-2 h-auto ${
            activeTab === tab 
              ? 'border-indigo-600 text-indigo-600 dark:border-indigo-400 dark:text-indigo-400' 
              : 'border-transparent text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100'
          }`}
          onClick={() => setActiveTab(tab)}
        >
          {tab}
        </Button>
      ))}
    </div>
  );
}
