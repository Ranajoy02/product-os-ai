'use client';

import React, { useEffect } from 'react';
import { useWorkspaceStore, WorkspaceEntityType } from '@/store/workspace-context';
import { WorkspaceTabs } from '@/components/workspace/WorkspaceTabs';
import { WorkspaceHeader } from '@/components/workspace/WorkspaceHeader';
import { WorkspaceSidebar } from '@/components/workspace/WorkspaceSidebar';
import { WorkspaceContent } from '@/components/workspace/WorkspaceContent';
import { ContextualDrawer } from '@/components/workspace/ContextualDrawer';

export default function WorkspacePage({ 
  params 
}: { 
  params: Promise<{ entityType: WorkspaceEntityType; id: string }>
}) {
  const resolvedParams = React.use(params);
  const { setEntity, resetWorkspace } = useWorkspaceStore();

  useEffect(() => {
    // Lock the context engine onto this entity
    setEntity(resolvedParams.id, resolvedParams.entityType);
    
    return () => {
      resetWorkspace();
    };
  }, [resolvedParams.id, resolvedParams.entityType, setEntity, resetWorkspace]);

  // Route Integrity & RBAC Mock Checks
  if (resolvedParams.id === 'invalid' || resolvedParams.id === 'missing' || resolvedParams.id === 'deleted') {
    return (
      <div className="flex flex-col h-screen items-center justify-center bg-slate-50">
        <h1 className="text-4xl font-bold text-slate-900 mb-2">404</h1>
        <p className="text-slate-500">Workspace not found or has been deleted.</p>
      </div>
    );
  }

  if (resolvedParams.id === 'unauthorized') {
    return (
      <div className="flex flex-col h-screen items-center justify-center bg-slate-50">
        <h1 className="text-4xl font-bold text-rose-600 mb-2">403</h1>
        <p className="text-slate-500">You do not have permission to view this workspace.</p>
      </div>
    );
  }

  if (resolvedParams.id === 'archived') {
    return (
      <div className="flex flex-col h-screen items-center justify-center bg-amber-50">
        <h1 className="text-4xl font-bold text-amber-900 mb-2">Archived Workspace</h1>
        <p className="text-amber-700">This workspace is read-only and has been archived.</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-slate-50 dark:bg-slate-950 overflow-hidden">
      {/* Global Context Header */}
      <WorkspaceHeader entityId={resolvedParams.id} entityType={resolvedParams.entityType} />

      {/* Main 3-Pane Unified Layout */}
      <div className="flex flex-1 overflow-hidden">
        
        {/* Pane 1: Lifecycle Sidebar */}
        <WorkspaceSidebar />
        
        {/* Pane 2: Main Canvas */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Persistent Tabs */}
          <WorkspaceTabs />
          
          {/* Dynamic Content based on Tabs & Lifecycle */}
          <div className="flex-1 overflow-y-auto p-6">
            <WorkspaceContent />
          </div>
        </div>

        {/* Pane 3: Right Drawer (Contextual) */}
        <ContextualDrawer />

      </div>
    </div>
  );
}
