import { ObjectType, Field, ID, Float, Int } from '@nestjs/graphql';

@ObjectType()
export class DecisionLog {
  @Field(() => ID)
  id: string;

  @Field()
  title: string;

  @Field()
  context: string;

  @Field()
  ownerId: string;

  @Field(() => String, { nullable: true })
  outcome?: string | null;

  @Field()
  createdAt: Date;
}

@ObjectType()
export class ResourceAllocation {
  @Field(() => ID)
  id: string;

  @Field()
  userId: string;

  @Field(() => String, { nullable: true })
  initiativeId?: string | null;

  @Field(() => String, { nullable: true })
  taskId?: string | null;

  @Field(() => Float)
  allocatedPts: number;

  @Field()
  startDate: Date;

  @Field()
  endDate: Date;

  @Field()
  createdAt: Date;
}

@ObjectType()
export class DeliveryIntelligence {
  @Field(() => Float)
  deliveryRiskScore: number;

  @Field(() => Float)
  delayProbability: number;

  @Field(() => Float)
  qualityProbability: number;

  @Field(() => Float)
  resourceSufficiencyScore: number;

  @Field(() => Float)
  timelineConfidence: number;

  @Field(() => Float)
  budgetConfidence: number;

  @Field()
  rootCause: string;

  @Field()
  recommendedAction: string;

  @Field()
  expectedImprovement: string;
}

@ObjectType()
export class ExecutiveBrief {
  @Field(() => ID)
  id: string;

  @Field(() => Int)
  productsReviewed: number;

  @Field(() => Int)
  productsAtRisk: number;

  @Field()
  situation: string;

  @Field()
  rootCause: string;

  @Field()
  businessImpact: string;

  @Field()
  recommendation: string;

  @Field()
  expectedOutcome: string;

  @Field()
  generatedAt: Date;
}

@ObjectType()
export class DigitalTwinScenario {
  @Field()
  name: string;

  @Field()
  type: string; // 'CURRENT', 'RECOMMENDED', 'ALTERNATIVE'

  @Field()
  status: string;

  @Field()
  risk: string;

  @Field()
  progress: string;

  @Field()
  capacity: string;

  @Field()
  expectedCompletion: string;

  @Field()
  expectedCost: string;

  @Field()
  bottlenecks: string;
}

@ObjectType()
export class DigitalTwin {
  @Field(() => ID)
  entityId: string;

  @Field(() => [DigitalTwinScenario])
  scenarios: DigitalTwinScenario[];
}
