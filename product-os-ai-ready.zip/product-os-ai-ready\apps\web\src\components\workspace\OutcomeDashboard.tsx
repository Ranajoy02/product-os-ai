import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Target, TrendingUp, Award, BarChart3, TrendingDown, Minus, CheckCircle2 } from 'lucide-react';

interface Metric {
  id: string;
  name: string;
  target: number;
  actual: number;
  unit: string;
  trend: 'up' | 'down' | 'neutral';
}

const mockMetrics: Metric[] = [
  { id: '1', name: 'User Acquisition', target: 50000, actual: 52400, unit: 'users', trend: 'up' },
  { id: '2', name: 'Retention Rate', target: 45, actual: 42, unit: '%', trend: 'down' },
  { id: '3', name: 'Revenue', target: 200000, actual: 205000, unit: '$', trend: 'up' },
  { id: '4', name: 'System Uptime', target: 99.99, actual: 99.95, unit: '%', trend: 'neutral' },
];

const mockGoal = {
  title: "Expand Market Share in Q3",
  description: "Capture 15% more of the enterprise segment by releasing advanced analytics features.",
  achievementPercentage: 85,
  impact: "High",
  actualOutcomes: "Analytics features launched on time. Strong early adoption from existing enterprise clients, driving a 10% increase in upsells.",
};

export function OutcomeDashboard() {
  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-slate-900 dark:text-white">Outcome Dashboard</h2>
          <p className="text-slate-500 dark:text-slate-400">Track business goals, success metrics, and actual impact.</p>
        </div>
        <Badge variant="outline" className="px-3 py-1 text-sm bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-900/30 dark:text-blue-300 dark:border-blue-800">
          Q3 2026 Cycle
        </Badge>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Business Goal Card */}
        <Card className="md:col-span-2">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <Target className="h-5 w-5 text-indigo-500" />
              <CardTitle>Business Goal</CardTitle>
            </div>
            <CardDescription>The primary objective for this workspace entity.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <h3 className="text-xl font-semibold text-slate-800 dark:text-slate-100">{mockGoal.title}</h3>
                <p className="text-slate-600 dark:text-slate-300 mt-1">{mockGoal.description}</p>
              </div>
              
              <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium text-slate-700 dark:text-slate-200">Overall Achievement</span>
                  <span className="text-sm font-bold text-indigo-600 dark:text-indigo-400">{mockGoal.achievementPercentage}%</span>
                </div>
                {/* Custom Progress Bar */}
                <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2.5">
                  <div 
                    className="bg-indigo-600 h-2.5 rounded-full transition-all duration-500" 
                    style={{ width: `${mockGoal.achievementPercentage}%` }}
                  ></div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Impact Card */}
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <Award className="h-5 w-5 text-amber-500" />
              <CardTitle>Business Impact</CardTitle>
            </div>
            <CardDescription>Strategic value delivered.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center justify-center py-6 text-center">
              <div className="h-16 w-16 rounded-full bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center mb-4">
                <TrendingUp className="h-8 w-8 text-amber-600 dark:text-amber-400" />
              </div>
              <span className="text-3xl font-bold text-slate-900 dark:text-white mb-1">{mockGoal.impact}</span>
              <span className="text-sm text-slate-500 dark:text-slate-400">Value Rating</span>
            </div>
          </CardContent>
        </Card>

        {/* Success Metrics */}
        <Card className="md:col-span-3">
          <CardHeader>
            <div className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5 text-emerald-500" />
              <CardTitle>Success Metrics</CardTitle>
            </div>
            <CardDescription>Key performance indicators tracked against targets.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {mockMetrics.map((metric) => (
                <div key={metric.id} className="p-4 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50">
                  <div className="text-sm text-slate-500 dark:text-slate-400 mb-1">{metric.name}</div>
                  <div className="flex items-end gap-2 mb-3">
                    <span className="text-2xl font-bold text-slate-900 dark:text-white">
                      {metric.unit === '$' ? '$' : ''}{metric.actual.toLocaleString()}{metric.unit === '%' ? '%' : ''}
                    </span>
                    <span className="text-xs text-slate-500 dark:text-slate-500 mb-1 flex items-center gap-1">
                      / {metric.unit === '$' ? '$' : ''}{metric.target.toLocaleString()}{metric.unit === '%' ? '%' : ''}
                    </span>
                  </div>
                  
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-500">
                      {Math.round((metric.actual / metric.target) * 100)}% of target
                    </span>
                    <span className={`flex items-center gap-1 ${
                      metric.trend === 'up' ? 'text-emerald-600 dark:text-emerald-400' : 
                      metric.trend === 'down' ? 'text-rose-600 dark:text-rose-400' : 
                      'text-slate-600 dark:text-slate-400'
                    }`}>
                      {metric.trend === 'up' && <TrendingUp className="h-3 w-3" />}
                      {metric.trend === 'down' && <TrendingDown className="h-3 w-3" />}
                      {metric.trend === 'neutral' && <Minus className="h-3 w-3" />}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Actual Outcomes */}
        <Card className="md:col-span-3">
          <CardHeader>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-blue-500" />
              <CardTitle>Actual Outcomes</CardTitle>
            </div>
            <CardDescription>Qualitative results and observations.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="p-4 bg-blue-50/50 dark:bg-blue-900/10 border border-blue-100 dark:border-blue-900/30 rounded-lg text-slate-700 dark:text-slate-300 leading-relaxed">
              {mockGoal.actualOutcomes}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
