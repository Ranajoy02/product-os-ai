import { ObjectType, Field, ID, InputType } from '@nestjs/graphql';

@ObjectType()
export class MigrationSimulation {
  @Field(() => ID)
  id: string;

  @Field()
  status: string; // 'RUNNING', 'COMPLETED', 'FAILED'

  @Field()
  totalRecords: number;

  @Field()
  estimatedTime: string;

  @Field()
  predictedErrors: number;

  @Field({ nullable: true })
  sourceSystem?: string;

  @Field({ nullable: true })
  targetSystem?: string;

  @Field({ nullable: true })
  migratedRecords?: number;

  @Field({ nullable: true })
  errorRecords?: number;
}

@ObjectType()
export class FieldMapping {
  @Field(() => ID)
  id: string;

  @Field()
  sourceField: string;

  @Field()
  targetField: string;

  @Field()
  confidenceScore: number;
}

@ObjectType()
export class MigrationValidationResult {
  @Field(() => ID)
  id: string;

  @Field()
  isValid: boolean;

  @Field(() => [String])
  errors: string[];
}

@ObjectType()
export class MigrationConversionStatus {
  @Field(() => ID)
  id: string;

  @Field()
  recordsProcessed: number;

  @Field()
  recordsFailed: number;

  @Field()
  status: string;
}

@ObjectType()
export class VerificationResult {
  @Field(() => ID)
  id: string;

  @Field()
  dataIntegrityScore: number;

  @Field()
  status: string; // 'VERIFIED', 'ISSUES_FOUND'
}

@InputType()
export class StartSimulationInput {
  @Field()
  sourceSystem: string;

  @Field()
  targetSystem: string;
}

@InputType()
export class CreateFieldMappingInput {
  @Field()
  sourceField: string;

  @Field()
  targetField: string;
}
