'use client';

import React from 'react';
import { useQuery } from '@apollo/experimental-nextjs-app-support/ssr';
import { gql } from '@apollo/client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Target, CheckCircle2, TrendingUp, Users, Activity } from 'lucide-react';

const GET_OUTCOME_DASHBOARD = gql`
  query GetOutcomeIntelligence {
    getOutcomeIntelligence {
      strategicSuccessScore
      kpiAchievementRate
      totalROI
      customerImpactScore
      businessGoals {
        id
        title
        target
        current
        status
      }
    }
  }
`;

export default function OutcomePage() {
  const { data, loading, error } = useQuery<any>(GET_OUTCOME_DASHBOARD);

  if (loading) return <div className="p-8 text-slate-500 animate-pulse">Loading Outcome Intelligence...</div>;
  if (error) return <div className="p-8 text-rose-500">Error: {error.message}</div>;

  const metrics = data?.getOutcomeIntelligence;

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Outcome Intelligence Engine</h1>
          <p className="text-slate-500 mt-1">Bridging the gap between Release Management and true Business Outcomes.</p>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-4">
        <Card className="border-indigo-100 bg-gradient-to-br from-indigo-50 to-white shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">Strategic Success</CardTitle>
            <Target className="h-4 w-4 text-indigo-500" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-indigo-700">{metrics?.strategicSuccessScore}/100</div>
          </CardContent>
        </Card>
        
        <Card className="border-emerald-100 bg-gradient-to-br from-emerald-50 to-white shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">KPI Achievement</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-emerald-500" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-emerald-700">{metrics?.kpiAchievementRate}%</div>
          </CardContent>
        </Card>

        <Card className="border-emerald-100 bg-gradient-to-br from-emerald-50 to-white shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">Realized ROI</CardTitle>
            <TrendingUp className="h-4 w-4 text-emerald-500" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-emerald-700">{metrics?.totalROI}%</div>
          </CardContent>
        </Card>

        <Card className="border-amber-100 bg-gradient-to-br from-amber-50 to-white shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">Customer Impact</CardTitle>
            <Users className="h-4 w-4 text-amber-500" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-amber-700">{metrics?.customerImpactScore}/10</div>
          </CardContent>
        </Card>
      </div>

      <Card className="mt-8">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-slate-500" /> Business Goals Tracking
          </CardTitle>
        </CardHeader>
        <CardContent>
           <div className="overflow-x-auto">
             <table className="w-full text-sm text-left">
               <thead className="text-xs text-slate-500 uppercase bg-slate-50 border-b border-slate-200">
                 <tr>
                   <th className="px-6 py-3">Business Goal</th>
                   <th className="px-6 py-3">Target KPI</th>
                   <th className="px-6 py-3">Current Achievement</th>
                   <th className="px-6 py-3">Status</th>
                 </tr>
               </thead>
               <tbody className="divide-y divide-slate-100">
                 {metrics?.businessGoals.map((goal: any) => (
                   <tr key={goal.id} className="hover:bg-slate-50">
                     <td className="px-6 py-4 font-medium text-slate-900">{goal.title}</td>
                     <td className="px-6 py-4 text-slate-500">{goal.target}</td>
                     <td className="px-6 py-4 text-slate-900 font-medium">{goal.current}</td>
                     <td className="px-6 py-4">
                       <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${
                         goal.status === 'Achieved' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
                       }`}>
                         {goal.status}
                       </span>
                     </td>
                   </tr>
                 ))}
               </tbody>
             </table>
           </div>
        </CardContent>
      </Card>
    </div>
  );
}
