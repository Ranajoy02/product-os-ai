import {
  Controller,
  Get,
  UseGuards,
  Request,
  Body,
  Patch,
} from '@nestjs/common';
import { OrganizationService } from './organization.service';
import { JwtAuthGuard } from '../../../core/auth/jwt-auth.guard';

@UseGuards(JwtAuthGuard)
@Controller('organizations')
export class OrganizationController {
  constructor(private readonly orgService: OrganizationService) {}

  @Get('current')
  async getCurrentOrg(@Request() req) {
    return this.orgService.getOrganization(req.user.organizationId);
  }

  @Patch('current')
  async updateCurrentOrg(@Request() req, @Body() data) {
    return this.orgService.updateOrganization(req.user.organizationId, data);
  }

  @Get('current/workspaces')
  async getWorkspaces(@Request() req) {
    return this.orgService.getWorkspaces(req.user.organizationId);
  }
}
