'use client';

import React from 'react';
import { useWorkspaceStore, LifecycleStage } from '@/store/workspace-context';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import { ChevronRight, FileText, CheckCircle, Clock } from 'lucide-react';
import { ChangeRequestManager } from './ChangeRequestManager';

const STAGES: LifecycleStage[] = [
  'Objective',
  'Business Case',
  'BRD',
  'PRD',
  'Roadmap',
  'Workflow',
  'Resource Planning',
  'Design',
  'Development',
  'Testing',
  'Approval',
  'Release',
  'Post Release Review',
  'Outcome',
  'Knowledge Capture'
];

export function LifecycleTab() {
  const { activeLifecycleStage, setLifecycleStage } = useWorkspaceStore();

  const activeIndex = STAGES.indexOf(activeLifecycleStage);

  return (
    <div className="space-y-6 max-w-6xl mx-auto h-full flex flex-col">
      <div className="flex-shrink-0">
        <h2 className="text-2xl font-bold tracking-tight mb-4">Lifecycle Navigator</h2>
        
        <ScrollArea className="w-full whitespace-nowrap pb-4">
          <div className="flex w-max space-x-2 items-center p-1">
            {STAGES.map((stage, index) => {
              const isActive = stage === activeLifecycleStage;
              const isPast = index < activeIndex;
              
              return (
                <React.Fragment key={stage}>
                  <Button
                    variant={isActive ? 'default' : isPast ? 'outline' : 'ghost'}
                    className={`rounded-full px-4 h-9 ${isActive ? 'shadow-md' : ''}`}
                    onClick={() => setLifecycleStage(stage)}
                  >
                    {isPast && <CheckCircle className="mr-2 h-4 w-4 text-green-500" />}
                    {stage}
                  </Button>
                  {index < STAGES.length - 1 && (
                    <ChevronRight className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                  )}
                </React.Fragment>
              );
            })}
          </div>
          <ScrollBar orientation="horizontal" />
        </ScrollArea>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 flex-grow min-h-0">
        <Card className="xl:col-span-2 flex flex-col min-h-0">
          <CardHeader className="flex-shrink-0">
            <CardTitle>{activeLifecycleStage} Workspace</CardTitle>
            <CardDescription>
              Manage artifacts and tasks for the {activeLifecycleStage} phase.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex-grow overflow-auto">
            <div className="border-2 border-dashed rounded-lg p-12 text-center text-muted-foreground h-full flex flex-col items-center justify-center min-h-[300px]">
              <FileText className="h-12 w-12 mb-4 opacity-50" />
              <h3 className="text-lg font-medium mb-2">Workspace Canvas</h3>
              <p className="max-w-md">
                Interactive canvas for editing {activeLifecycleStage} artifacts, embedded tools, and collaborative content will appear here.
              </p>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-6 flex flex-col min-h-0">
          <Card className="flex-shrink-0">
            <CardHeader>
              <CardTitle className="text-lg">Phase Checklist</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                <li className="flex items-start gap-2 text-sm">
                  <Clock className="h-4 w-4 mt-0.5 text-blue-500" />
                  <span>Draft initial document</span>
                </li>
                <li className="flex items-start gap-2 text-sm">
                  <div className="h-4 w-4 mt-0.5 rounded-full border" />
                  <span>Review with stakeholders</span>
                </li>
                <li className="flex items-start gap-2 text-sm">
                  <div className="h-4 w-4 mt-0.5 rounded-full border" />
                  <span>Obtain sign-off</span>
                </li>
              </ul>
            </CardContent>
          </Card>
          
          <div className="flex-grow min-h-0 overflow-auto">
            <ChangeRequestManager />
          </div>
        </div>
      </div>
    </div>
  );
}
