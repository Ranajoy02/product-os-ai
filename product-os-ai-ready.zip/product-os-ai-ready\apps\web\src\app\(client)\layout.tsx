import React from 'react';
import Link from 'next/link';

export default function ClientLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <header className="h-16 bg-white border-b px-8 flex items-center justify-between">
        <div className="font-semibold text-xl text-primary">
          Acme Corp Portal
        </div>
        <nav className="flex gap-6">
          <Link href="/client" className="text-sm font-medium hover:text-primary">Progress</Link>
          <Link href="/client/deliverables" className="text-sm font-medium text-muted-foreground hover:text-primary">Deliverables</Link>
          <Link href="/client/approvals" className="text-sm font-medium text-muted-foreground hover:text-primary">Approvals</Link>
        </nav>
        <div className="w-8 h-8 rounded-full bg-slate-200"></div>
      </header>
      <main className="flex-1 p-8">
        {children}
      </main>
    </div>
  );
}
