import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function main() {
  console.log('Seeding Demo Production Database...');

  // 1. Clear existing generic data if any
  await prisma.workflowTransition.deleteMany();
  await prisma.workflowStep.deleteMany();
  await prisma.workflowExecution.deleteMany();
  await prisma.workflow.deleteMany();
  await prisma.task.deleteMany();
  await prisma.project.deleteMany();
  await prisma.team.deleteMany();
  await prisma.user.deleteMany();
  await prisma.workspace.deleteMany();
  await prisma.organization.deleteMany();

  // 2. Create Organization & Workspace
  const org = await prisma.organization.create({
    data: {
      name: 'MediCloud Enterprise',
    },
  });

  const workspace = await prisma.workspace.create({
    data: {
      name: 'Global HQ',
      organizationId: org.id,
    },
  });

  // 3. Create Demo Users
  const password = await bcrypt.hash('DemoPassword123!', 10);
  const admin = await prisma.user.create({
    data: {
      email: 'admin@medicloud.demo',
      passwordHash: password,
      firstName: 'Sarah',
      lastName: 'Connor',
      role: 'ADMIN' as any,
      organizationId: org.id,
    },
  });

  // 4. Create Team
  const team = await prisma.team.create({
    data: {
      name: 'Healthcare Compliance Engineering',
    },
  });

  // 5. Create Projects
  const project1 = await prisma.project.create({
    data: {
      name: 'HIPAA Compliance Audit Module',
      description: 'Phase 2 rollout of the compliance suite.',
      workspaceId: workspace.id,
    },
  });

  const project2 = await prisma.project.create({
    data: {
      name: 'Telehealth Video Integration',
      description: 'WebRTC video call system for doctors.',
      workspaceId: workspace.id,
    },
  });

  console.log('Database seeded successfully!');
  console.log(`Demo Account -> Email: admin@medicloud.demo | Password: DemoPassword123!`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
