'use client';

import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Database, ShieldCheck, HardDrive, Lock, RefreshCcw, Save } from 'lucide-react';
import { gql } from '@apollo/client';
import { useQuery } from '@apollo/experimental-nextjs-app-support/ssr';

const GET_GOVERNANCE_POLICY = gql`
  query GetGovernancePolicy {
    getGovernancePolicies {
      id
      dataResidency
      retentionPeriod
      encryptionLevel
      backupFrequency
    }
  }
`;

export default function ComplianceGovernancePage() {
  const { data, loading, error } = useQuery<any>(GET_GOVERNANCE_POLICY);
  const [updating, setUpdating] = useState(false);

  const [formData, setFormData] = useState({
    dataResidency: 'US-East',
    retentionDays: 365,
    encryptionLevel: 'AES-256',
    backupFrequency: 'Daily'
  });

  // Sync form data with fetched data
  React.useEffect(() => {
    if (data?.getGovernancePolicies?.length > 0) {
      const policy = data.getGovernancePolicies[0];
      setFormData({
        dataResidency: policy.dataResidency,
        retentionDays: policy.retentionPeriod,
        encryptionLevel: policy.encryptionLevel,
        backupFrequency: policy.backupFrequency
      });
    }
  }, [data]);

  const handleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSave = () => {
    setUpdating(true);
    setTimeout(() => {
      setUpdating(false);
      alert("Configuration saved securely.");
    }, 800);
  };

  if (loading) return <div className="p-8 text-slate-500 animate-pulse">Loading Governance Policy...</div>;
  if (error) return <div className="p-8 text-rose-500">Error loading policy: {error.message}</div>;

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Compliance & Governance Center</h1>
          <p className="text-slate-500 mt-1">Configure Data Residency, Retention, Encryption, and Backup policies.</p>
        </div>
        <Button 
          onClick={handleSave} 
          disabled={updating}
          className="bg-indigo-600 hover:bg-indigo-700"
        >
          <Save className="w-4 h-4 mr-2" />
          {updating ? 'Saving...' : 'Save Configuration'}
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Data Residency */}
        <Card className="border-slate-200 shadow-sm">
          <CardHeader className="border-b border-slate-100 bg-slate-50/50 pb-4">
            <div className="flex items-center gap-2">
              <Globe className="w-5 h-5 text-indigo-500" />
              <CardTitle className="text-lg">Data Residency</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="pt-6 space-y-4">
            <div className="flex flex-col gap-2">
              <label className="text-sm font-semibold text-slate-700">Primary Region</label>
              <select name="dataResidency" value={formData.dataResidency} onChange={handleChange} className="border-slate-200 rounded-md p-2 bg-white">
                <option value="US-East">US-East (N. Virginia)</option>
                <option value="US-West">US-West (Oregon)</option>
                <option value="EU-Central">EU-Central (Frankfurt)</option>
                <option value="EU-West">EU-West (Ireland)</option>
                <option value="AP-South">AP-South (Mumbai)</option>
              </select>
              <p className="text-xs text-slate-500 mt-1">Dictates physical location of data-at-rest to comply with GDPR/CCPA.</p>
            </div>
          </CardContent>
        </Card>

        {/* Data Retention */}
        <Card className="border-slate-200 shadow-sm">
          <CardHeader className="border-b border-slate-100 bg-slate-50/50 pb-4">
            <div className="flex items-center gap-2">
              <Database className="w-5 h-5 text-indigo-500" />
              <CardTitle className="text-lg">Retention Policy</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="pt-6 space-y-4">
            <div className="flex flex-col gap-2">
              <label className="text-sm font-semibold text-slate-700">Audit & Log Retention (Days)</label>
              <select name="retentionDays" value={formData.retentionDays} onChange={handleChange} className="border-slate-200 rounded-md p-2 bg-white">
                <option value="90">90 Days</option>
                <option value="180">180 Days</option>
                <option value="365">365 Days (1 Year)</option>
                <option value="1825">1825 Days (5 Years)</option>
                <option value="2555">2555 Days (7 Years)</option>
              </select>
              <p className="text-xs text-slate-500 mt-1">Duration for which audit logs and entity history are preserved before permanent deletion.</p>
            </div>
          </CardContent>
        </Card>

        {/* Encryption */}
        <Card className="border-slate-200 shadow-sm">
          <CardHeader className="border-b border-slate-100 bg-slate-50/50 pb-4">
            <div className="flex items-center gap-2">
              <Lock className="w-5 h-5 text-indigo-500" />
              <CardTitle className="text-lg">Encryption Policy</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="pt-6 space-y-4">
            <div className="flex flex-col gap-2">
              <label className="text-sm font-semibold text-slate-700">Encryption Level</label>
              <select name="encryptionLevel" value={formData.encryptionLevel} onChange={handleChange} className="border-slate-200 rounded-md p-2 bg-white">
                <option value="AES-128">AES-128</option>
                <option value="AES-256">AES-256</option>
                <option value="BYOK">Bring Your Own Key (BYOK)</option>
              </select>
              <p className="text-xs text-slate-500 mt-1">Algorithm used for volume encryption at-rest. BYOK requires KMS configuration.</p>
            </div>
          </CardContent>
        </Card>

        {/* Backup */}
        <Card className="border-slate-200 shadow-sm">
          <CardHeader className="border-b border-slate-100 bg-slate-50/50 pb-4">
            <div className="flex items-center gap-2">
              <HardDrive className="w-5 h-5 text-indigo-500" />
              <CardTitle className="text-lg">Disaster Recovery & Backup</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="pt-6 space-y-4">
            <div className="flex flex-col gap-2">
              <label className="text-sm font-semibold text-slate-700">Backup Frequency</label>
              <select name="backupFrequency" value={formData.backupFrequency} onChange={handleChange} className="border-slate-200 rounded-md p-2 bg-white">
                <option value="Hourly">Hourly</option>
                <option value="Daily">Daily</option>
                <option value="Weekly">Weekly</option>
              </select>
              <p className="text-xs text-slate-500 mt-1">Snapshot frequency for cross-region replication.</p>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Certifications Banner */}
      <Card className="border-emerald-200 bg-emerald-50 shadow-sm mt-8">
        <CardContent className="flex items-center gap-6 p-6">
          <ShieldCheck className="w-12 h-12 text-emerald-600 shrink-0" />
          <div>
            <h3 className="font-bold text-emerald-900 text-lg">Platform Compliance Certifications</h3>
            <p className="text-emerald-700 mt-1">ProductOS AI maintains active SOC 2 Type II, ISO 27001, and GDPR compliant certifications. Your current configuration satisfies the controls required for these frameworks.</p>
          </div>
          <div className="flex gap-2 ml-auto shrink-0">
             <span className="px-3 py-1 bg-white border border-emerald-200 rounded text-sm font-bold text-emerald-700">SOC 2</span>
             <span className="px-3 py-1 bg-white border border-emerald-200 rounded text-sm font-bold text-emerald-700">ISO 27001</span>
             <span className="px-3 py-1 bg-white border border-emerald-200 rounded text-sm font-bold text-emerald-700">GDPR</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Icon placeholder
import { Globe } from 'lucide-react';
