import { Injectable, NotFoundException } from '@nestjs/common';
import { Outcome } from './models/outcome.model';

@Injectable()
export class OutcomeService {
  private outcomes: Outcome[] = [
    {
      id: 'outcome-1',
      businessGoals: 'Increase Q3 Revenue by 15%',
      kpiTargets: '$1.5M ARR',
      kpiAchievement: 85,
      roi: 24.5,
      customerImpact: 'High',
      strategicSuccess: 'On Track',
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      id: 'outcome-2',
      businessGoals: 'Reduce Churn by 5%',
      kpiTargets: 'Churn < 2%',
      kpiAchievement: 60,
      roi: 12.0,
      customerImpact: 'Medium',
      strategicSuccess: 'At Risk',
      createdAt: new Date(),
      updatedAt: new Date(),
    }
  ];

  async findAll(): Promise<Outcome[]> {
    return this.outcomes;
  }

  async findById(id: string): Promise<Outcome> {
    const outcome = this.outcomes.find(o => o.id === id);
    if (!outcome) {
      throw new NotFoundException(`Outcome with ID ${id} not found`);
    }
    return outcome;
  }

  async create(data: {
    businessGoals: string;
    kpiTargets: string;
    kpiAchievement: number;
    roi: number;
    customerImpact: string;
    strategicSuccess: string;
  }): Promise<Outcome> {
    const outcome = { 
      id: `outcome-${Date.now()}`, 
      ...data,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.outcomes.push(outcome);
    return outcome;
  }

  async update(id: string, data: any): Promise<Outcome> {
    const idx = this.outcomes.findIndex(o => o.id === id);
    if (idx === -1) throw new NotFoundException(`Outcome with ID ${id} not found`);
    this.outcomes[idx] = { 
      ...this.outcomes[idx], 
      ...data,
      updatedAt: new Date()
    };
    return this.outcomes[idx];
  }

  async delete(id: string): Promise<Outcome> {
    const idx = this.outcomes.findIndex(o => o.id === id);
    if (idx === -1) throw new NotFoundException(`Outcome with ID ${id} not found`);
    const outcome = this.outcomes[idx];
    this.outcomes.splice(idx, 1);
    return outcome;
  }
}
