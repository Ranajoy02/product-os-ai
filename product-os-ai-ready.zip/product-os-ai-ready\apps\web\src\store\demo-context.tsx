'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';

export type DemoNarrative = 'enterprise_saas' | 'security_incident' | 'ai_launch';

interface DemoContextType {
  isDemoMode: boolean;
  activeNarrative: DemoNarrative;
  setNarrative: (n: DemoNarrative) => void;
  // Executive questions state
  preconfiguredQuestions: string[];
}

const defaultQuestions = [
  'Why is this release delayed?',
  'Which team is overloaded?',
  'What is the highest roadmap risk?',
  'What approvals are blocking delivery?',
  'What is the projected business impact?'
];

const DemoContext = createContext<DemoContextType>({
  isDemoMode: false,
  activeNarrative: 'enterprise_saas',
  setNarrative: () => {},
  preconfiguredQuestions: defaultQuestions
});

export function DemoProvider({ children }: { children: React.ReactNode }) {
  const [isDemoMode, setIsDemoMode] = useState(false);
  const [activeNarrative, setActiveNarrative] = useState<DemoNarrative>('enterprise_saas');

  useEffect(() => {
    // Only access process.env on client side if needed, but Next.js injects NEXT_PUBLIC variables at build time
    if (process.env.NEXT_PUBLIC_DEMO_MODE === 'true') {
      setIsDemoMode(true);
    }
  }, []);

  return (
    <DemoContext.Provider value={{
      isDemoMode,
      activeNarrative,
      setNarrative: setActiveNarrative,
      preconfiguredQuestions: defaultQuestions
    }}>
      {children}
    </DemoContext.Provider>
  );
}

export const useDemoContext = () => useContext(DemoContext);
