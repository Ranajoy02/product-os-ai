import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../core/prisma/prisma.service';
import {
  DecisionLog,
  ResourceAllocation,
  DeliveryIntelligence,
  ExecutiveBrief,
  DigitalTwin,
} from './models/intelligence.model';

@Injectable()
export class IntelligenceService {
  constructor(private readonly prisma: PrismaService) {}

  async getDecisionLogs(): Promise<DecisionLog[]> {
    return this.prisma.decisionLog.findMany({
      orderBy: { createdAt: 'desc' },
    });
  }

  async getResourceAllocations(): Promise<ResourceAllocation[]> {
    return this.prisma.resourceAllocation.findMany({
      orderBy: { startDate: 'desc' },
    });
  }

  async createDecisionLog(data: {
    title: string;
    context: string;
    ownerId: string;
    outcome?: string | null;
  }): Promise<DecisionLog> {
    return this.prisma.decisionLog.create({
      data,
    });
  }

  async getDeliveryIntelligence(
    entityId: string,
  ): Promise<DeliveryIntelligence> {
    // Mocking predictive operations for Phase 8
    return {
      deliveryRiskScore: 84.5,
      delayProbability: 72.0,
      qualityProbability: 65.4,
      resourceSufficiencyScore: 40.0,
      timelineConfidence: 35.5,
      budgetConfidence: 88.0,
      rootCause: 'QA Capacity Shortage',
      recommendedAction: 'Add 1 QA Engineer',
      expectedImprovement: '+14% probability of on-time delivery',
    };
  }

  async generateExecutiveBrief(): Promise<ExecutiveBrief> {
    return {
      id: 'exec-brief-latest',
      productsReviewed: 14,
      productsAtRisk: 2,
      situation:
        'Release Alpha is currently trending towards a 2-week delay due to testing bottlenecks.',
      rootCause:
        'QA testing velocity is 40% below target due to understaffing in the validation phase.',
      businessImpact: '$120k delayed revenue realization in Q3.',
      recommendation:
        'Reallocate 2 QA Engineers from Project Beta (Low Priority) to Release Alpha.',
      expectedOutcome:
        'Restores Timeline Confidence to 90% and secures Q3 revenue targets.',
      generatedAt: new Date(),
    };
  }

  async getDigitalTwin(entityId: string): Promise<DigitalTwin> {
    return {
      entityId,
      scenarios: [
        {
          name: 'Baseline',
          type: 'CURRENT',
          status: 'At Risk',
          risk: 'High',
          progress: '65%',
          capacity: 'Overloaded (110%)',
          expectedCompletion: 'Nov 15 (Delayed)',
          expectedCost: '$450,000 (+12% overrun)',
          bottlenecks: 'QA Validation Phase',
        },
        {
          name: 'AI Recommendation',
          type: 'RECOMMENDED',
          status: 'On Track',
          risk: 'Low',
          progress: '65%',
          capacity: 'Balanced (85%)',
          expectedCompletion: 'Oct 30 (On Time)',
          expectedCost: '$410,000 (Within Budget)',
          bottlenecks: 'None Predicted',
        },
        {
          name: 'Alternative: Scope Cut',
          type: 'ALTERNATIVE',
          status: 'On Track',
          risk: 'Medium',
          progress: '80%',
          capacity: 'Comfortable (70%)',
          expectedCompletion: 'Oct 15 (Early)',
          expectedCost: '$380,000 (Under Budget)',
          bottlenecks: 'Stakeholder Approval',
        },
      ],
    };
  }
}
