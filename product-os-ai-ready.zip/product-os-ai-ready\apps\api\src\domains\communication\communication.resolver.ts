import { Resolver, Query, Mutation, Args, ID } from '@nestjs/graphql';
import { CommunicationService } from './communication.service';
import { Channel, Message, ChannelType } from './communication.models';

@Resolver()
export class CommunicationResolver {
  constructor(private readonly communicationService: CommunicationService) {}

  @Query(() => [Channel])
  channels() {
    return this.communicationService.getChannels();
  }

  @Query(() => Channel, { nullable: true })
  channel(@Args('id', { type: () => ID }) id: string) {
    return this.communicationService.getChannel(id);
  }

  @Query(() => [Message])
  messages(@Args('channelId', { type: () => ID }) channelId: string) {
    return this.communicationService.getMessages(channelId);
  }

  @Mutation(() => Channel)
  createChannel(
    @Args('name') name: string,
    @Args('type', { type: () => ChannelType }) type: ChannelType,
  ) {
    return this.communicationService.createChannel(name, type);
  }

  @Mutation(() => Message)
  sendMessage(
    @Args('channelId', { type: () => ID }) channelId: string,
    @Args('senderId', { type: () => ID }) senderId: string,
    @Args('content') content: string,
  ) {
    return this.communicationService.sendMessage(channelId, senderId, content);
  }
}
