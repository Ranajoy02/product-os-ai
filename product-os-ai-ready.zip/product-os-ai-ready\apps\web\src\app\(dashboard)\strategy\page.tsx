'use client';

import React from 'react';
import { useQuery } from '@apollo/experimental-nextjs-app-support/ssr';
import { gql } from '@apollo/client';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Loader2, LayoutDashboard, Target } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

const GET_ROADMAPS_AND_OUTCOMES = gql`
  query GetRoadmapsAndOutcomes {
    roadmaps {
      id
      name
      type
    }
    getOutcomes {
      id
      businessGoals
      kpiTargets
      kpiAchievement
      roi
      customerImpact
      strategicSuccess
    }
  }
`;

export default function Strategy() {
  const { data, loading, error } = useQuery<any>(GET_ROADMAPS_AND_OUTCOMES);

  return (
    <div className="p-8 space-y-8 max-w-[1600px] mx-auto">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-slate-900">Strategy & Roadmaps</h1>
          <p className="text-muted-foreground mt-2 text-sm">Strategic Goals, Objectives and Key Results (OKRs), and Outcomes.</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="bg-white" onClick={() => toast.success('Objective creation started.')}>New Objective</Button>
          <Button className="bg-indigo-600 hover:bg-indigo-700" onClick={() => toast.success('Roadmap workflow initiated.')}>Create Roadmap</Button>
        </div>
      </div>
      
      {loading ? (
        <div className="flex h-64 items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-indigo-600" />
        </div>
      ) : error ? (
        <div className="h-32 border-2 border-dashed border-red-200 bg-red-50 rounded-xl flex items-center justify-center text-red-500">
          Error loading strategy data: {error.message}
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {data?.roadmaps?.length === 0 ? (
              <div className="col-span-full h-32 border-2 border-dashed rounded-xl flex items-center justify-center text-muted-foreground">
                No roadmaps found. Create one to get started.
              </div>
            ) : (
              data?.roadmaps?.map((roadmap: any) => (
                <Card key={roadmap.id} className="bg-white shadow-sm border-slate-200 hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-lg">{roadmap.name}</CardTitle>
                        <CardDescription className="uppercase mt-1 text-xs font-semibold text-indigo-500 tracking-wider">
                          {roadmap.type}
                        </CardDescription>
                      </div>
                      <div className="w-10 h-10 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center">
                        <Target className="w-5 h-5" />
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Button variant="outline" className="w-full text-sm">View Details</Button>
                  </CardContent>
                </Card>
              ))
            )}
          </div>

          <div className="pt-6 border-t border-slate-200">
            <h2 className="text-2xl font-bold tracking-tight text-slate-900 mb-6">Business Outcomes</h2>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {data?.getOutcomes?.length === 0 ? (
                <div className="col-span-full h-32 border-2 border-dashed rounded-xl flex items-center justify-center text-muted-foreground">
                  No outcomes tracked yet.
                </div>
              ) : (
                data?.getOutcomes?.map((outcome: any) => (
                  <Card key={outcome.id} className="bg-white shadow-sm border-slate-200 hover:shadow-md transition-shadow">
                    <CardHeader>
                      <CardTitle className="text-lg">{outcome.businessGoals}</CardTitle>
                      <CardDescription>Strategic Success: {outcome.strategicSuccess}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="text-slate-500 font-medium">KPI Targets</p>
                          <p className="font-semibold">{outcome.kpiTargets}</p>
                        </div>
                        <div>
                          <p className="text-slate-500 font-medium">KPI Achievement</p>
                          <p className="font-semibold text-emerald-600">{outcome.kpiAchievement}%</p>
                        </div>
                        <div>
                          <p className="text-slate-500 font-medium">Return on Investment</p>
                          <p className="font-semibold text-indigo-600">{outcome.roi}%</p>
                        </div>
                        <div>
                          <p className="text-slate-500 font-medium">Customer Impact</p>
                          <p className="font-semibold">{outcome.customerImpact}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
