import { Controller, Post, Body, Param, UseGuards } from '@nestjs/common';
import { WorkflowService } from './workflow.service';
import { JwtAuthGuard } from '../../core/auth/jwt-auth.guard';

@UseGuards(JwtAuthGuard)
@Controller('workflow')
export class WorkflowController {
  constructor(private readonly workflowService: WorkflowService) {}

  @Post()
  async createWorkflow(
    @Body()
    body: {
      organizationId: string;
      name: string;
      description?: string;
    },
  ) {
    return this.workflowService.createWorkflow(
      body.organizationId,
      body.name,
      body.description,
    );
  }

  @Post(':id/steps')
  async addStep(
    @Param('id') id: string,
    @Body() body: { name: string; type: any; config: any },
  ) {
    return this.workflowService.addStep(id, body.name, body.type, body.config);
  }

  @Post('transitions')
  async addTransition(
    @Body() body: { sourceId: string; targetId: string; condition: any },
  ) {
    return this.workflowService.addTransition(
      body.sourceId,
      body.targetId,
      body.condition,
    );
  }

  @Post('execute/:workflowId')
  async executeStep(
    @Param('workflowId') workflowId: string,
    @Body() body: { targetId: string; targetType: string; actionPayload: any },
  ) {
    return this.workflowService.executeStep(
      workflowId,
      body.targetId,
      body.targetType,
      body.actionPayload,
    );
  }
}
