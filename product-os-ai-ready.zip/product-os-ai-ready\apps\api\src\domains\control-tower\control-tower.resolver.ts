import { Resolver, Query } from '@nestjs/graphql';
import { ControlTowerService } from './control-tower.service';
import { ControlTowerMetrics } from './models/control-tower-metrics.model';

@Resolver(() => ControlTowerMetrics)
export class ControlTowerResolver {
  constructor(private readonly controlTowerService: ControlTowerService) {}

  @Query(() => ControlTowerMetrics, { name: 'controlTowerMetrics' })
  async getMetrics(): Promise<ControlTowerMetrics> {
    return this.controlTowerService.getMetrics();
  }
}
