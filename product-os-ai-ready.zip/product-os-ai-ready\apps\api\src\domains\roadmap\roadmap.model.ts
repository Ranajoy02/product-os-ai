import {
  ObjectType,
  Field,
  ID,
  Float,
  registerEnumType,
} from '@nestjs/graphql';

export enum RoadmapType {
  PORTFOLIO = 'PORTFOLIO',
  PROGRAM = 'PROGRAM',
  PRODUCT = 'PRODUCT',
  PROJECT = 'PROJECT',
  RELEASE = 'RELEASE',
}

registerEnumType(RoadmapType, {
  name: 'RoadmapType',
});

@ObjectType()
export class KeyResult {
  @Field(() => ID)
  id: string;

  @Field()
  objectiveId: string;

  @Field()
  name: string;

  @Field(() => Float)
  target: number;

  @Field(() => Float)
  current: number;
}

@ObjectType()
export class Initiative {
  @Field(() => ID)
  id: string;

  @Field()
  objectiveId: string;

  @Field()
  name: string;

  @Field(() => [RoadmapItem], { nullable: true })
  roadmaps?: RoadmapItem[];
}

@ObjectType()
export class Objective {
  @Field(() => ID)
  id: string;

  @Field()
  goalId: string;

  @Field()
  name: string;

  @Field(() => [KeyResult], { nullable: true })
  keyResults?: KeyResult[];

  @Field(() => [Initiative], { nullable: true })
  initiatives?: Initiative[];
}

@ObjectType()
export class StrategicGoal {
  @Field(() => ID)
  id: string;

  @Field()
  name: string;

  @Field(() => [Objective], { nullable: true })
  objectives?: Objective[];
}

@ObjectType()
export class RoadmapItem {
  @Field(() => ID)
  id: string;

  @Field()
  roadmapId: string;

  @Field()
  initiativeId: string;

  @Field()
  startDate: Date;

  @Field()
  endDate: Date;

  @Field()
  status: string;

  @Field(() => Initiative, { nullable: true })
  initiative?: Initiative;
}

@ObjectType()
export class Roadmap {
  @Field(() => ID)
  id: string;

  @Field()
  name: string;

  @Field(() => RoadmapType)
  type: RoadmapType;

  @Field(() => [RoadmapItem], { nullable: true })
  items?: RoadmapItem[];
}
