import { create } from 'zustand';

interface AIContextState {
  isOpen: boolean;
  activeContext: string;
  recommendation: AIRecommendation | null;
  toggleAdvisor: () => void;
  setContext: (context: string) => void;
  fetchRecommendation: () => Promise<void>;
}

export interface AIRecommendation {
  reason: string;
  confidence: number;
  evidence: string;
  impact: string;
  actionText: string;
}

export const useAIContext = create<AIContextState>((set, get) => ({
  isOpen: false,
  activeContext: 'Global Dashboard',
  recommendation: null,
  toggleAdvisor: () => set((state) => ({ isOpen: !state.isOpen })),
  setContext: (context) => set({ activeContext: context }),
  fetchRecommendation: async () => {
    // In a real implementation, this would POST the activeContext to the AI endpoint
    // We mock the Explainable AI payload here for the Investor Demo
    set({
      isOpen: true, // Auto open when fetching
      recommendation: {
        reason: "12 blocked tasks in QA, 3 pending security approvals.",
        confidence: 91,
        evidence: "View 12 blocked tasks | View QA team capacity: 110%",
        impact: "Resolving this recovers 4 days on the Release 2.0 timeline.",
        actionText: "Reallocate 2 devs to QA"
      }
    });
  }
}));
