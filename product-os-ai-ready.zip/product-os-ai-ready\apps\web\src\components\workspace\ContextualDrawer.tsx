'use client';

import React from 'react';
import { useWorkspaceStore } from '@/store/workspace-context';
import { MessageSquare, Users, FolderKanban, PackageSearch, ShieldCheck, Mail, Send } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

export function ContextualDrawer() {
  const { activeTab, entityId, entityType } = useWorkspaceStore();
  const [activeChat, setActiveChat] = React.useState('entity');

  const [activeDrawerTab, setActiveDrawerTab] = React.useState('communication');

  const chatTypes = [
    { id: 'entity', label: 'Entity Chat', icon: MessageSquare },
    { id: 'team', label: 'Team Chat', icon: Users },
    { id: 'project', label: 'Project Chat', icon: FolderKanban },
    { id: 'product', label: 'Product Chat', icon: PackageSearch },
    { id: 'approval', label: 'Approval Chat', icon: ShieldCheck },
    { id: 'dm', label: 'Direct Messages', icon: Mail },
  ];

  return (
    <div className="w-80 border-l bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 flex flex-col h-full shrink-0">
      <div className="p-4 border-b border-slate-200 dark:border-slate-800">
        <h3 className="font-semibold text-sm">Contextual Drawer</h3>
        <p className="text-xs text-slate-500">
          Scope: {entityType} {entityId}
        </p>
      </div>

      {/* Chat Type Selector */}
      <div className="flex overflow-x-auto p-2 space-x-1 border-b border-slate-100 dark:border-slate-800 no-scrollbar">
        {chatTypes.map((c) => {
          const Icon = c.icon;
          const isActive = activeChat === c.id;
          return (
            <button
              key={c.id}
              onClick={() => setActiveChat(c.id)}
              className={`flex-shrink-0 flex items-center space-x-1 px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
                isActive 
                  ? 'bg-indigo-100 text-indigo-700 dark:bg-indigo-900 dark:text-indigo-300' 
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-400 dark:hover:bg-slate-700'
              }`}
            >
              <Icon className="h-3 w-3" />
              <span>{c.label}</span>
            </button>
          );
        })}
      </div>

      {/* Chat Canvas (Mock) */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4">
        <div className="flex justify-center">
          <span className="text-xs text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded-full">
            Today
          </span>
        </div>
        <div className="flex space-x-3">
          <div className="h-8 w-8 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center font-bold text-xs shrink-0">
            JS
          </div>
          <div>
            <div className="bg-slate-100 dark:bg-slate-800 p-3 rounded-2xl rounded-tl-sm text-sm">
              We need to discuss the {entityType} requirements. Does the BRD cover edge cases?
            </div>
            <div className="text-[10px] text-slate-400 mt-1 ml-1">10:42 AM</div>
          </div>
        </div>
        <div className="flex space-x-3 flex-row-reverse space-x-reverse">
          <div className="h-8 w-8 rounded-full bg-slate-200 text-slate-700 flex items-center justify-center font-bold text-xs shrink-0">
            Me
          </div>
          <div>
            <div className="bg-indigo-600 text-white p-3 rounded-2xl rounded-tr-sm text-sm">
              I'm adding the change request now. Let's track it in the lifecycle navigator.
            </div>
            <div className="text-[10px] text-slate-400 mt-1 mr-1 text-right">10:45 AM</div>
          </div>
        </div>
      </div>

      {/* Input Area */}
      <div className="p-3 border-t border-slate-200 dark:border-slate-800">
        <div className="flex items-center space-x-2">
          <Input 
            placeholder={`Message in ${activeChat}...`} 
            className="flex-1 bg-slate-50 dark:bg-slate-950 border-none shadow-none focus-visible:ring-1"
          />
          <Button size="icon" className="h-9 w-9 shrink-0 rounded-full">
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
