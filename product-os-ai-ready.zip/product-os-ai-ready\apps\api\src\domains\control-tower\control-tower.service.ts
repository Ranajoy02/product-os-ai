import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../core/prisma/prisma.service';
import { ControlTowerMetrics } from './models/control-tower-metrics.model';

@Injectable()
export class ControlTowerService {
  constructor(private prisma: PrismaService) {}

  async getMetrics(): Promise<ControlTowerMetrics> {
    const activeProductsCount = await this.prisma.product.count();
    const inFlightProjectsCount = await this.prisma.project.count();
    const totalTeamsCount = await this.prisma.team.count();

    // Calculate PRD Approvals
    const pendingPrdApprovals = await this.prisma.approval.count({
      where: {
        status: 'PENDING',
        document: {
          type: 'PRD',
        },
      },
    });

    const pendingChangeRequests = await this.prisma.changeRequest.count({
      where: {
        status: 'REQUESTED',
      },
    });

    const offTrackOkrs = await this.prisma.keyResult.count({
      where: {
        current: {
          lt: 50,
        },
      },
    });

    return {
      activeProducts: {
        count: activeProductsCount,
        trend: 2,
      },
      inFlightProjects: {
        count: inFlightProjectsCount,
        onTrackPercentage: 85.0,
      },
      totalTeams: {
        count: totalTeamsCount,
        avgUtilization: 92.0,
      },
      deliveryHealth: {
        score: 94.2,
        grade: 'A-',
      },
      risks: [
        {
          title: 'Frontend Resource Bottleneck',
          project: 'Merchant Dashboard v2',
          severity: 'high',
          impact: 'Could delay Q3 release by 2 weeks',
        },
        {
          title: 'Scope Creep Detected',
          project: 'Payment Gateway Integration',
          severity: 'medium',
          impact: '15 new tickets added post-sprint planning',
        },
        {
          title: 'Burnout Risk: Core Team',
          project: 'Mobile App Refactor',
          severity: 'high',
          impact: '3 key engineers over 110% utilization',
        },
      ],
      actionItems: {
        pendingPrdApprovals,
        pendingChangeRequests,
        offTrackOkrs,
      },
    };
  }
}
