import {
  Resolver,
  Query,
  ObjectType,
  Field,
  ID,
  Float,
  Args,
} from '@nestjs/graphql';
import { PerformanceService } from './performance.service';

@ObjectType()
export class PerformanceUser {
  @Field(() => ID)
  id: string;

  @Field()
  email: string;

  @Field({ nullable: true })
  firstName?: string;

  @Field({ nullable: true })
  lastName?: string;

  @Field()
  role: string;
}

@ObjectType()
export class PerformanceScore {
  @Field(() => ID)
  id: string;

  @Field()
  userId: string;

  @Field(() => PerformanceUser)
  user: PerformanceUser;

  @Field(() => Float)
  contributionScore: number;

  @Field(() => Float)
  deliveryScore: number;

  @Field(() => Float)
  collaborationScore: number;

  @Field(() => Float)
  burnoutRisk: number;
}

@Resolver(() => PerformanceScore)
export class PerformanceResolver {
  constructor(private performanceService: PerformanceService) {}

  @Query(() => [PerformanceScore])
  async getPerformanceScores() {
    return this.performanceService.getPerformanceScores();
  }

  @Query(() => PerformanceScore, { nullable: true })
  async getPerformanceScoreByUser(
    @Args('userId', { type: () => ID }) userId: string,
  ) {
    return this.performanceService.getPerformanceScoreByUser(userId);
  }
}
