import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  UseGuards,
  Patch,
} from '@nestjs/common';
import { ProjectService } from './project.service';
import { TaskService } from './task.service';
import { JwtAuthGuard } from '../../core/auth/jwt-auth.guard';
import { TaskStatus } from '@prisma/client';

@UseGuards(JwtAuthGuard)
@Controller('projects')
export class ProjectController {
  constructor(
    private readonly projectService: ProjectService,
    private readonly taskService: TaskService,
  ) {}

  @Get('workspace/:workspaceId')
  async getProjects(@Param('workspaceId') workspaceId: string) {
    return this.projectService.getProjectsByWorkspace(workspaceId);
  }

  @Post('workspace/:workspaceId')
  async createProject(@Param('workspaceId') workspaceId: string, @Body() body) {
    return this.projectService.createProject(workspaceId, body);
  }

  @Get(':projectId')
  async getProjectDetails(@Param('projectId') projectId: string) {
    return this.projectService.getProjectDetails(projectId);
  }

  @Post(':projectId/tasks')
  async createTask(@Param('projectId') projectId: string, @Body() body) {
    return this.taskService.createTask(projectId, body);
  }

  @Patch('tasks/:taskId/status')
  async updateTaskStatus(
    @Param('taskId') taskId: string,
    @Body('status') status: TaskStatus,
  ) {
    return this.taskService.updateTaskStatus(taskId, status);
  }
}
