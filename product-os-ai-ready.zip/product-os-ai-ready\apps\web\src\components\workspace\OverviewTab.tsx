import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Activity, AlertTriangle, CheckCircle, Users, Clock, TrendingUp, Target, ShieldAlert } from 'lucide-react';

export function OverviewTab() {
  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-500">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold tracking-tight">Executive Summary View</h2>
      </div>

      {/* Primary KPI Section */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Health & Status</CardTitle>
            <Activity className="h-4 w-4 text-emerald-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-emerald-500">On Track</div>
            <p className="text-xs text-muted-foreground mt-1">
              +2% ahead of schedule
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Risks & Bottlenecks</CardTitle>
            <AlertTriangle className="h-4 w-4 text-amber-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-amber-500">2 Medium</div>
            <p className="text-xs text-muted-foreground mt-1">
              Backend API dependencies
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Approvals</CardTitle>
            <CheckCircle className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">3 items</div>
            <p className="text-xs text-muted-foreground mt-1">
              Requires PM review
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Assigned Team</CardTitle>
            <Users className="h-4 w-4 text-indigo-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12 Members</div>
            <p className="text-xs text-muted-foreground mt-1">
              Frontend, Backend, Design
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Team Visibility Widgets */}
      <div>
        <h3 className="text-xl font-semibold tracking-tight mt-8 mb-4">Team Visibility Widgets</h3>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          
          <Card>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base font-medium">Capacity</CardTitle>
                <Clock className="h-4 w-4 text-slate-500" />
              </div>
              <CardDescription>Available engineering hours</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold mt-2">420 hrs</div>
              <div className="mt-2 text-sm text-slate-500">Next sprint (2 weeks)</div>
              <div className="mt-4 w-full bg-slate-100 rounded-full h-2">
                <div className="bg-blue-500 h-2 rounded-full" style={{ width: '85%' }}></div>
              </div>
              <p className="mt-2 text-xs text-slate-500 text-right">85% Allocated</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base font-medium">Utilization</CardTitle>
                <Target className="h-4 w-4 text-slate-500" />
              </div>
              <CardDescription>Resource allocation efficiency</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold mt-2">92%</div>
              <div className="mt-2 text-sm text-slate-500">Optimal target: 85-95%</div>
              <div className="mt-5 flex gap-2">
                <Badge variant="outline" className="bg-emerald-50 text-emerald-700 border-emerald-200">Balanced</Badge>
                <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">High focus</Badge>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base font-medium">Velocity</CardTitle>
                <TrendingUp className="h-4 w-4 text-slate-500" />
              </div>
              <CardDescription>Story points completed</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold mt-2">48 pts</div>
              <div className="mt-2 text-sm text-emerald-600 flex items-center">
                <TrendingUp className="h-3 w-3 mr-1" /> +4 from last sprint
              </div>
              <div className="flex items-end gap-1 h-12 mt-4">
                {[32, 40, 38, 44, 48].map((v, i) => (
                  <div key={i} className="bg-blue-100 hover:bg-blue-200 transition-colors w-full rounded-t-sm" style={{ height: `${(v/50)*100}%` }}></div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base font-medium">Performance</CardTitle>
                <CheckCircle className="h-4 w-4 text-slate-500" />
              </div>
              <CardDescription>Quality and delivery metrics</CardDescription>
            </CardHeader>
            <CardContent className="space-y-5 mt-2">
              <div className="flex justify-between items-center text-sm">
                <span className="text-slate-500">Code Coverage</span>
                <span className="font-medium">88%</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-slate-500">Bug Fix Rate</span>
                <span className="font-medium text-emerald-600">94%</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-slate-500">Deploy Success</span>
                <span className="font-medium">99.9%</span>
              </div>
            </CardContent>
          </Card>

          <Card className="md:col-span-2 lg:col-span-2">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base font-medium">Risks</CardTitle>
                <ShieldAlert className="h-4 w-4 text-slate-500" />
              </div>
              <CardDescription>Active team and project risks</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 mt-3">
                <div className="flex items-start gap-4">
                  <div className="mt-0.5 bg-amber-100 p-1.5 rounded-md">
                    <AlertTriangle className="h-4 w-4 text-amber-600" />
                  </div>
                  <div>
                    <h4 className="text-sm font-medium">Third-party API deprecation</h4>
                    <p className="text-xs text-slate-500 mt-1">Payment gateway v1 will be deprecated next month. Migration to v2 is at 40%.</p>
                  </div>
                  <Badge variant="secondary" className="ml-auto mt-1">Medium</Badge>
                </div>
                <div className="flex items-start gap-4">
                  <div className="mt-0.5 bg-red-100 p-1.5 rounded-md">
                    <AlertTriangle className="h-4 w-4 text-red-600" />
                  </div>
                  <div>
                    <h4 className="text-sm font-medium">Frontend Resource Constrained</h4>
                    <p className="text-xs text-slate-500 mt-1">Two senior engineers on PTO next week during major release window.</p>
                  </div>
                  <Badge variant="destructive" className="ml-auto mt-1">High</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
