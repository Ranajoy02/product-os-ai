import { Module } from '@nestjs/common';
import { MigrationService } from './migration.service';
import { MigrationResolver } from './migration.resolver';

@Module({
  providers: [MigrationService, MigrationResolver],
  exports: [MigrationService],
})
export class MigrationModule {}
