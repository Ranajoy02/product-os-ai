import { ObjectType, Field, Int, Float } from '@nestjs/graphql';

@ObjectType()
export class MetricTrend {
  @Field(() => Int)
  count: number;

  @Field(() => Int)
  trend: number;
}

@ObjectType()
export class ProjectMetrics {
  @Field(() => Int)
  count: number;

  @Field(() => Float)
  onTrackPercentage: number;
}

@ObjectType()
export class TeamMetrics {
  @Field(() => Int)
  count: number;

  @Field(() => Float)
  avgUtilization: number;
}

@ObjectType()
export class DeliveryHealthMetrics {
  @Field(() => Float)
  score: number;

  @Field(() => String)
  grade: string;
}

@ObjectType()
export class DeliveryRisk {
  @Field(() => String)
  title: string;

  @Field(() => String)
  project: string;

  @Field(() => String)
  severity: string;

  @Field(() => String)
  impact: string;
}

@ObjectType()
export class ActionItems {
  @Field(() => Int)
  pendingPrdApprovals: number;

  @Field(() => Int)
  pendingChangeRequests: number;

  @Field(() => Int)
  offTrackOkrs: number;
}

@ObjectType()
export class ControlTowerMetrics {
  @Field(() => MetricTrend)
  activeProducts: MetricTrend;

  @Field(() => ProjectMetrics)
  inFlightProjects: ProjectMetrics;

  @Field(() => TeamMetrics)
  totalTeams: TeamMetrics;

  @Field(() => DeliveryHealthMetrics)
  deliveryHealth: DeliveryHealthMetrics;

  @Field(() => [DeliveryRisk])
  risks: DeliveryRisk[];

  @Field(() => ActionItems)
  actionItems: ActionItems;
}
