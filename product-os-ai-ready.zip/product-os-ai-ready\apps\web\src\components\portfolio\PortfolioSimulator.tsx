import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Sliders, RefreshCw, BarChart3, TrendingUp, AlertOctagon } from 'lucide-react';
import { gql } from '@apollo/client';

export function PortfolioSimulator() {
  const [shiftPriorities, setShiftPriorities] = useState(false);
  const [delayRelease, setDelayRelease] = useState(false);
  const [reallocateTeams, setReallocateTeams] = useState(false);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<any>(null);
  const [outcome, setOutcome] = useState<any>(null);

  const handleSimulate = async () => {
    setLoading(true);
    setError(null);
    try {
      await new Promise(resolve => setTimeout(resolve, 800));
      setOutcome({
        projectedROI: shiftPriorities ? 24 : 18,
        valueCreated: reallocateTeams ? 2400000 : 1800000,
        overloadedTeamsReduced: reallocateTeams ? 3 : 0,
        delayedInitiativesRecovered: delayRelease ? 2 : 0
      });
    } catch (e) {
      setError(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="border-indigo-100 shadow-sm overflow-hidden">
      <div className="bg-slate-900 px-6 py-4 flex items-center gap-3">
        <Sliders className="text-indigo-400 w-5 h-5" />
        <h2 className="text-lg font-bold text-white tracking-wide">Portfolio Allocation Simulator</h2>
      </div>
      <CardContent className="p-6 grid grid-cols-1 md:grid-cols-12 gap-8">
        
        {/* Controls */}
        <div className="md:col-span-5 space-y-6">
          <div className="space-y-4">
            <label className="flex items-start gap-3 cursor-pointer p-3 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors">
              <input 
                type="checkbox" 
                checked={shiftPriorities} 
                onChange={(e) => setShiftPriorities(e.target.checked)}
                className="mt-1 h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-600" 
              />
              <div>
                <div className="font-semibold text-slate-900">Shift Priorities</div>
                <div className="text-sm text-slate-500 mt-1">Deprioritize Beta features to accelerate Alpha.</div>
              </div>
            </label>

            <label className="flex items-start gap-3 cursor-pointer p-3 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors">
              <input 
                type="checkbox" 
                checked={delayRelease} 
                onChange={(e) => setDelayRelease(e.target.checked)}
                className="mt-1 h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-600" 
              />
              <div>
                <div className="font-semibold text-slate-900">Delay Non-Critical Releases</div>
                <div className="text-sm text-slate-500 mt-1">Push Release Gamma to Q4 to free up QA bandwidth.</div>
              </div>
            </label>

            <label className="flex items-start gap-3 cursor-pointer p-3 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors">
              <input 
                type="checkbox" 
                checked={reallocateTeams} 
                onChange={(e) => setReallocateTeams(e.target.checked)}
                className="mt-1 h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-600" 
              />
              <div>
                <div className="font-semibold text-slate-900">Reallocate Teams</div>
                <div className="text-sm text-slate-500 mt-1">Move 3 engineers from Platform to Core Product.</div>
              </div>
            </label>
          </div>

          <Button 
            onClick={handleSimulate} 
            disabled={loading}
            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-6 text-lg rounded-xl shadow-md flex items-center justify-center gap-2"
          >
            {loading ? <RefreshCw className="w-5 h-5 animate-spin" /> : <BarChart3 className="w-5 h-5" />}
            Run Simulation
          </Button>
        </div>

        {/* Results */}
        <div className="md:col-span-7 bg-slate-50 rounded-xl border border-slate-200 p-6 flex flex-col justify-center relative overflow-hidden">
          {error && <div className="text-rose-500">Simulation failed: {error.message}</div>}
          
          {!outcome && !error && (
            <div className="text-center text-slate-400">
              <Sliders className="w-16 h-16 mx-auto mb-4 opacity-20" />
              <p className="font-medium text-lg">Select parameters and run simulation to predict outcomes.</p>
            </div>
          )}

          {outcome && (
            <div className="space-y-6 relative z-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <h3 className="text-slate-500 uppercase tracking-widest font-bold text-xs">Simulated Outcome</h3>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white p-4 rounded-lg shadow-sm border border-emerald-100 flex items-start gap-3">
                  <TrendingUp className="w-8 h-8 text-emerald-500 mt-1 shrink-0" />
                  <div>
                    <div className="text-sm text-slate-500 mb-1">Projected ROI</div>
                    <div className="text-2xl font-black text-emerald-700">{outcome.projectedROI}%</div>
                  </div>
                </div>

                <div className="bg-white p-4 rounded-lg shadow-sm border border-indigo-100 flex items-start gap-3">
                  <BarChart3 className="w-8 h-8 text-indigo-500 mt-1 shrink-0" />
                  <div>
                    <div className="text-sm text-slate-500 mb-1">Value Created</div>
                    <div className="text-2xl font-black text-indigo-700">${(outcome.valueCreated / 1000000).toFixed(1)}M</div>
                  </div>
                </div>

                <div className="bg-white p-4 rounded-lg shadow-sm border border-emerald-100 flex items-start gap-3">
                  <AlertOctagon className="w-8 h-8 text-emerald-500 mt-1 shrink-0" />
                  <div>
                    <div className="text-sm text-slate-500 mb-1">Overloaded Teams Reduced</div>
                    <div className="text-2xl font-black text-emerald-700">{outcome.overloadedTeamsReduced}</div>
                  </div>
                </div>

                <div className="bg-white p-4 rounded-lg shadow-sm border border-emerald-100 flex items-start gap-3">
                  <RefreshCw className="w-8 h-8 text-emerald-500 mt-1 shrink-0" />
                  <div>
                    <div className="text-sm text-slate-500 mb-1">Delayed Initiatives Recovered</div>
                    <div className="text-2xl font-black text-emerald-700">{outcome.delayedInitiativesRecovered}</div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

      </CardContent>
    </Card>
  );
}
