'use client';

import { useState } from 'react';
import { useAIContext } from '../../store/ai-context';
import { useDemoContext } from '../../store/demo-context';
import { DemoData } from '../../store/demo-data';

export function AIAdvisorDrawer() {
  const { isOpen, toggleAdvisor, recommendation, activeContext } = useAIContext();
  const { isDemoMode, activeNarrative, preconfiguredQuestions } = useDemoContext();
  
  const [selectedQuestion, setSelectedQuestion] = useState<string | null>(null);

  const handleQuestionClick = (q: string) => {
    setSelectedQuestion(q);
  };

  const currentDemoData = DemoData[activeNarrative];

  return (
    <>
      {!isOpen && (
        <button 
          onClick={toggleAdvisor}
          className="fixed bottom-6 right-6 w-14 h-14 bg-indigo-600 text-white rounded-full shadow-lg flex items-center justify-center hover:bg-indigo-500 transition-colors z-40"
        >
          AI
        </button>
      )}

      {isOpen && (
        <div className="fixed inset-y-0 right-0 w-96 bg-gray-900 border-l border-gray-800 text-white shadow-2xl z-50 flex flex-col">
          <div className="p-6 border-b border-gray-800">
            <div className="flex justify-between items-center mb-2">
              <h2 className="text-xl font-semibold flex items-center gap-2">
                <span className="text-indigo-500">✦</span> AI Delivery Advisor
              </h2>
              <button onClick={toggleAdvisor} className="text-gray-400 hover:text-white">
                &times;
              </button>
            </div>
            {isDemoMode && (
              <div className="text-xs bg-indigo-500/20 text-indigo-300 px-2 py-1 rounded inline-block mt-2">
                Demo Mode: {currentDemoData.name}
              </div>
            )}
          </div>

          <div className="p-4 bg-gray-800/50 text-sm text-gray-400 border-b border-gray-800">
            Context: {activeContext}
          </div>

          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {isDemoMode ? (
              <div className="space-y-4">
                <p className="text-sm text-gray-300">Executive Question Library</p>
                <div className="space-y-2">
                  {preconfiguredQuestions.map((q) => (
                    <button
                      key={q}
                      onClick={() => handleQuestionClick(q)}
                      className={`w-full text-left text-sm p-3 rounded-lg border transition-colors ${selectedQuestion === q ? 'bg-indigo-900 border-indigo-500 text-white' : 'bg-gray-800 border-gray-700 text-gray-300 hover:border-gray-500'}`}
                    >
                      {q}
                    </button>
                  ))}
                </div>

                {selectedQuestion && (
                  <div className="mt-6 p-4 bg-indigo-950/50 border border-indigo-900 rounded-lg">
                    <p className="text-xs text-indigo-400 mb-2 uppercase tracking-wider font-semibold">AI Analysis</p>
                    <p className="text-sm text-indigo-100 leading-relaxed">
                      {currentDemoData.aiAnswers[selectedQuestion]}
                    </p>
                  </div>
                )}
              </div>
            ) : recommendation ? (
              // Original recommendation view
              <div className="space-y-6">
                <div className="bg-red-500/10 border border-red-500/20 p-4 rounded-lg">
                  <h3 className="text-red-400 font-medium mb-2">Alert: Delivery Delay Predicted</h3>
                  <p className="text-sm">Workflow delay risk increased by 18%.</p>
                </div>
                <div className="space-y-4 text-sm">
                  <div>
                    <span className="text-gray-400 block mb-1">Reason</span>
                    <p>{recommendation.reason}</p>
                  </div>
                  <div>
                    <span className="text-gray-400 block mb-1">Confidence</span>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 bg-gray-800 h-2 rounded-full overflow-hidden">
                        <div className="bg-indigo-500 h-full" style={{ width: `${recommendation.confidence}%` }}></div>
                      </div>
                      <span>{recommendation.confidence}%</span>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="h-full flex items-center justify-center text-gray-500 text-sm text-center">
                Monitoring {activeContext}...<br/>No immediate actions required.
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}
