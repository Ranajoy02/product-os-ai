import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../core/prisma/prisma.service';
import { ChannelType } from './communication.models';

@Injectable()
export class CommunicationService {
  constructor(private readonly prisma: PrismaService) {}

  async getChannels() {
    return this.prisma.channel.findMany();
  }

  async getChannel(id: string) {
    return this.prisma.channel.findUnique({ where: { id } });
  }

  async getMessages(channelId: string) {
    return this.prisma.message.findMany({ where: { channelId } });
  }

  async createChannel(name: string, type: ChannelType) {
    return this.prisma.channel.create({
      data: { name, type },
    });
  }

  async sendMessage(channelId: string, senderId: string, content: string) {
    return this.prisma.message.create({
      data: { channelId, senderId, content },
    });
  }
}
