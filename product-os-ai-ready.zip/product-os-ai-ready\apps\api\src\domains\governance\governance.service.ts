import { Injectable } from '@nestjs/common';
import { GovernancePolicy, CreateGovernancePolicyInput } from './models/governance.model';

@Injectable()
export class GovernanceService {
  private policies: GovernancePolicy[] = [];

  getGovernancePolicies(): GovernancePolicy[] {
    return this.policies;
  }

  createGovernancePolicy(input: CreateGovernancePolicyInput): GovernancePolicy {
    const newPolicy = {
      id: Math.random().toString(36).substring(7),
      ...input,
    };
    this.policies.push(newPolicy);
    return newPolicy;
  }
}
