import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

export default function ClientDashboard() {
  return (
    <div className="max-w-5xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Project Progress</h1>
        <p className="text-muted-foreground">Real-time updates on your deliverables.</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Current Milestone: MVP Launch</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between text-sm font-medium">
              <span>Overall Completion</span>
              <span>85%</span>
            </div>
            <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden">
              <div className="bg-primary h-full" style={{ width: '85%' }}></div>
            </div>
            <p className="text-sm text-muted-foreground">Estimated Delivery: Oct 15, 2026</p>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Pending Approvals</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-3 border rounded-md">
              <div>
                <div className="font-medium">Design Mockups v2</div>
                <div className="text-xs text-muted-foreground">Due today</div>
              </div>
              <Button size="sm">Review</Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-sm">
              <span className="font-medium text-primary">Team</span> completed 3 backend tasks. <span className="text-muted-foreground text-xs ml-2">2h ago</span>
            </div>
            <div className="text-sm">
              <span className="font-medium text-primary">System</span> published the weekly report. <span className="text-muted-foreground text-xs ml-2">1d ago</span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
