import { Field, ID, ObjectType, InputType, Int } from '@nestjs/graphql';

@ObjectType()
export class GovernancePolicy {
  @Field(() => ID)
  id: string;

  @Field()
  dataResidency: string;

  @Field(() => Int)
  retentionPeriod: number;

  @Field()
  encryptionLevel: string;

  @Field()
  backupFrequency: string;
}

@InputType()
export class CreateGovernancePolicyInput {
  @Field()
  dataResidency: string;

  @Field(() => Int)
  retentionPeriod: number;

  @Field()
  encryptionLevel: string;

  @Field()
  backupFrequency: string;
}
