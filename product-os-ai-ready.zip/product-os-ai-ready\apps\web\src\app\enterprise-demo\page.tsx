'use client';

import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Play, CheckCircle2, ChevronRight, FileText, Map, Settings, 
  Users, Activity, BrainCircuit, BarChart3, TrendingUp, Layers,
  Target, AlertTriangle, TrendingDown, Zap, Network
} from 'lucide-react';

type ScenarioStep = {
  id: string;
  title: string;
  icon: React.ReactNode;
  content: React.ReactNode;
};

const SCENARIOS = [
  {
    id: 's1',
    title: 'Scenario 1: From Concept to Execution',
    description: 'Watch AI orchestrate a complete business objective.',
    steps: [
      { id: '1-1', title: 'Business Goal', icon: <Target className="w-5 h-5" />, content: <div>Business Goal: Capture 20% of EMEA Market by Q4.</div> },
      { id: '1-2', title: 'Upload PRD', icon: <FileText className="w-5 h-5" />, content: <div>Uploading PRD for Enterprise SSO and Localization...</div> },
      { id: '1-3', title: 'AI Analysis', icon: <BrainCircuit className="w-5 h-5" />, content: <div>Analyzing requirements, parsing 14 Epics...</div> },
      { id: '1-4', title: 'Roadmap Generation', icon: <Map className="w-5 h-5" />, content: <div>Auto-generated Q3 Roadmap with dependencies mapped.</div> },
      { id: '1-5', title: 'Workflow Orchestration', icon: <Settings className="w-5 h-5" />, content: <div>Assigning 42 Tasks across 3 Engineering Squads...</div> },
    ]
  },
  {
    id: 's2',
    title: 'Scenario 2: Predictive Operations',
    description: 'See how the Digital Twin predicts and prevents failure.',
    steps: [
      { id: '2-1', title: 'Release Delay Detected', icon: <Activity className="w-5 h-5 text-rose-500" />, content: <div>Alert: Release Gamma trending 14 days late.</div> },
      { id: '2-2', title: 'Root Cause Isolation', icon: <AlertTriangle className="w-5 h-5 text-amber-500" />, content: <div>Root Cause: Backend squad velocity dropped 30%.</div> },
      { id: '2-3', title: 'Impact Analysis', icon: <TrendingDown className="w-5 h-5 text-rose-500" />, content: <div>Impact: $250k delayed revenue recognition.</div> },
      { id: '2-4', title: 'AI Recommendation', icon: <Zap className="w-5 h-5 text-indigo-500" />, content: <div>Recommendation: Shift 2 Senior Devs from Tech Debt to Feature Work.</div> },
    ]
  },
  {
    id: 's3',
    title: 'Scenario 3: Strategic Traceability',
    description: 'Connect every engineering task to a business outcome.',
    steps: [
      { id: '3-1', title: 'Knowledge Graph', icon: <Network className="w-5 h-5" />, content: <div>Querying full enterprise graph...</div> },
      { id: '3-2', title: 'Traceability Chain', icon: <Layers className="w-5 h-5" />, content: <div>Task #402 → PRD Sec 2 → EMEA Expansion Goal</div> },
      { id: '3-3', title: 'Business Outcome', icon: <BarChart3 className="w-5 h-5 text-emerald-500" />, content: <div>Outcome: +5% ARR realized. Strategic Success: 92/100.</div> },
    ]
  },
  {
    id: 's4',
    title: 'Scenario 4: Enterprise Governance & Scale',
    description: 'Ensure compliance, security, and seamless integration at scale.',
    steps: [
      { id: '4-1', title: 'Identity & Access', icon: <Users className="w-5 h-5" />, content: <div>Validating Okta SSO & Enforcing ABAC rules.</div> },
      { id: '4-2', title: 'Compliance Check', icon: <CheckCircle2 className="w-5 h-5 text-emerald-500" />, content: <div>Data Residency: EU-Frankfurt. SOC2 Controls Active.</div> },
      { id: '4-3', title: 'Legacy Migration', icon: <Layers className="w-5 h-5" />, content: <div>Importing 42,000 Jira Epics → Validation → Conversion.</div> },
      { id: '4-4', title: 'Automated Workflows', icon: <Zap className="w-5 h-5 text-indigo-500" />, content: <div>GitHub PR Merged → Slack Alert → Task Closed.</div> },
    ]
  }
];


export default function EnterpriseDemoPage() {
  const [activeScenarioId, setActiveScenarioId] = useState('s1');
  const [activeStepIndex, setActiveStepIndex] = useState(0);

  const activeScenario = SCENARIOS.find(s => s.id === activeScenarioId)!;
  const activeStep = activeScenario.steps[activeStepIndex];

  const handleNextStep = () => {
    if (activeStepIndex < activeScenario.steps.length - 1) {
      setActiveStepIndex(activeStepIndex + 1);
    }
  };

  const handleScenarioChange = (id: string) => {
    setActiveScenarioId(id);
    setActiveStepIndex(0);
  };

  return (
    <div className="flex h-screen bg-slate-950 text-white font-sans">
      
      {/* Sidebar Navigation */}
      <div className="w-80 border-r border-slate-800 bg-slate-900 flex flex-col">
        <div className="p-6 border-b border-slate-800">
          <div className="flex items-center gap-2 mb-1">
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-500 flex items-center justify-center font-bold">
              OS
            </div>
            <span className="text-xl font-bold tracking-tight">ProductOS AI</span>
          </div>
          <p className="text-xs text-slate-400 uppercase tracking-widest font-semibold mt-2">Investor Demo</p>
        </div>
        
        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          {SCENARIOS.map(scenario => (
            <button
              key={scenario.id}
              onClick={() => handleScenarioChange(scenario.id)}
              className={`w-full text-left p-4 rounded-xl transition-all ${
                activeScenarioId === scenario.id 
                  ? 'bg-indigo-600 shadow-md shadow-indigo-900/50' 
                  : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <h3 className={`font-bold ${activeScenarioId === scenario.id ? 'text-white' : ''}`}>{scenario.title}</h3>
              <p className={`text-sm mt-1 ${activeScenarioId === scenario.id ? 'text-indigo-200' : 'text-slate-500'}`}>
                {scenario.description}
              </p>
            </button>
          ))}
        </div>
      </div>

      {/* Main Canvas */}
      <div className="flex-1 flex flex-col relative overflow-hidden bg-gradient-to-br from-slate-900 via-slate-950 to-black">
        
        {/* Top bar */}
        <div className="h-16 flex items-center px-8 border-b border-slate-800/50 backdrop-blur-sm">
          <div className="flex items-center gap-2 text-sm text-slate-400">
            <span>Demo Mode</span>
            <ChevronRight className="w-4 h-4" />
            <span className="text-white font-medium">{activeScenario.title}</span>
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 flex flex-col items-center justify-center p-12">
          
          <div className="max-w-3xl w-full">
            
            {/* Progress Stepper */}
            <div className="flex items-center justify-between mb-12 relative">
               <div className="absolute left-0 top-1/2 -translate-y-1/2 w-full h-1 bg-slate-800 rounded-full z-0"></div>
               <div className="absolute left-0 top-1/2 -translate-y-1/2 h-1 bg-indigo-500 rounded-full z-0 transition-all duration-500" 
                    style={{ width: `${(activeStepIndex / (activeScenario.steps.length - 1)) * 100}%` }}></div>
               
               {activeScenario.steps.map((step, idx) => (
                 <div key={step.id} className="relative z-10 flex flex-col items-center gap-2">
                   <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors duration-300 ${
                     idx < activeStepIndex ? 'bg-indigo-500 text-white shadow-[0_0_15px_rgba(99,102,241,0.5)]' : 
                     idx === activeStepIndex ? 'bg-indigo-600 text-white ring-4 ring-indigo-900' : 'bg-slate-800 text-slate-500'
                   }`}>
                     {idx < activeStepIndex ? <CheckCircle2 className="w-5 h-5" /> : step.icon}
                   </div>
                   <span className={`text-xs font-bold absolute -bottom-6 whitespace-nowrap ${
                     idx <= activeStepIndex ? 'text-indigo-200' : 'text-slate-600'
                   }`}>
                     {step.title}
                   </span>
                 </div>
               ))}
            </div>

            {/* Interactive Mock Display */}
            <Card className="bg-slate-900/80 border-slate-700/50 backdrop-blur-xl shadow-2xl min-h-[400px] flex flex-col items-center justify-center relative overflow-hidden">
              <div className="absolute top-0 right-0 p-8 opacity-5">
                {activeStep.icon}
              </div>
              
              <CardContent className="p-12 text-center z-10 animate-in fade-in zoom-in-95 duration-500">
                <div className="mb-6 flex justify-center text-indigo-400">
                  {activeStep.icon}
                </div>
                <h2 className="text-3xl font-black mb-4 tracking-tight">{activeStep.title}</h2>
                <div className="text-xl text-slate-300 font-light leading-relaxed max-w-xl mx-auto">
                  {activeStep.content}
                </div>

                {activeStepIndex < activeScenario.steps.length - 1 ? (
                  <Button 
                    onClick={handleNextStep}
                    className="mt-12 bg-white text-slate-900 hover:bg-indigo-50 font-bold px-8 py-6 rounded-full text-lg shadow-[0_0_30px_rgba(255,255,255,0.2)] transition-all hover:scale-105"
                  >
                    Execute Next Phase <Play className="w-5 h-5 ml-2 fill-current" />
                  </Button>
                ) : (
                  <div className="mt-12 text-emerald-400 font-bold flex items-center justify-center gap-2 text-xl bg-emerald-950/30 py-4 px-6 rounded-full border border-emerald-800/50">
                    <CheckCircle2 className="w-6 h-6" /> Scenario Complete
                  </div>
                )}
              </CardContent>
            </Card>

          </div>
        </div>
      </div>

    </div>
  );
}
