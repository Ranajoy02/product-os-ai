import { Module } from '@nestjs/common';
import { CommunicationService } from './communication.service';
import { CommunicationResolver } from './communication.resolver';
import { PrismaModule } from '../../core/prisma/prisma.module';

@Module({
  imports: [PrismaModule],
  providers: [CommunicationService, CommunicationResolver],
  exports: [CommunicationService, CommunicationResolver],
})
export class CommunicationModule {}
