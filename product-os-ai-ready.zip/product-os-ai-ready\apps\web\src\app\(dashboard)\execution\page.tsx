"use client";

import React from 'react';
import { useQuery } from '@apollo/experimental-nextjs-app-support/ssr';
import { gql } from '@apollo/client';

const GET_WORKFLOWS = gql`
  query GetWorkflows($orgId: String!) {
    workflows(organizationId: $orgId) {
      id
      name
      description
      steps {
        id
        name
        type
      }
    }
  }
`;

export default function Execution() {
  // Using a hardcoded orgId for demo purposes, you'd typically get this from context or session
  const { data, loading, error } = useQuery<any>(GET_WORKFLOWS, {
    variables: { orgId: 'org_123' }, // mock orgId
  });

  return (
    <div className="p-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Project Workspace</h1>
        <p className="text-muted-foreground mt-2">Manage tasks, sprints, and change requests.</p>
      </div>

      {loading && <p>Loading workflows...</p>}
      {error && <p className="text-red-500">Error: {error.message}</p>}

      <div className="space-y-4">
        {data?.workflows?.length === 0 && (
          <div className="h-48 border-2 border-dashed rounded-xl flex items-center justify-center text-muted-foreground">
            No Workflows found for this Organization.
          </div>
        )}
        
        {data?.workflows?.map((workflow: any) => (
          <div key={workflow.id} className="p-6 border rounded-xl shadow-sm bg-card">
            <h2 className="text-xl font-semibold">{workflow.name}</h2>
            {workflow.description && <p className="text-muted-foreground mt-1">{workflow.description}</p>}
            
            <div className="mt-4 space-y-2">
              <h3 className="font-medium text-sm text-slate-500 uppercase tracking-wider">Steps:</h3>
              {workflow.steps?.length === 0 && <p className="text-sm text-muted-foreground">No steps defined.</p>}
              <ul className="list-disc pl-5 space-y-1">
                {workflow.steps?.map((step: any) => (
                  <li key={step.id} className="text-sm">
                    <span className="font-medium">{step.name}</span> ({step.type})
                  </li>
                ))}
              </ul>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
