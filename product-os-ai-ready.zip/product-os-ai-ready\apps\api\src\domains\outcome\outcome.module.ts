import { Module } from '@nestjs/common';
import { OutcomeService } from './outcome.service';
import { OutcomeResolver } from './outcome.resolver';
import { PrismaService } from '../../core/prisma/prisma.service';

@Module({
  providers: [OutcomeService, OutcomeResolver, PrismaService],
  exports: [OutcomeService, OutcomeResolver],
})
export class OutcomeModule {}
