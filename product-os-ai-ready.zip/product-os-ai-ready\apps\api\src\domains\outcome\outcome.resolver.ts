import {
  Resolver,
  Query,
  Mutation,
  Args,
  ID,
  Float,
  InputType,
  Field,
} from '@nestjs/graphql';
import { OutcomeService } from './outcome.service';
import { Outcome } from './models/outcome.model';

@InputType()
export class CreateOutcomeInput {
  @Field()
  businessGoals: string;

  @Field()
  kpiTargets: string;

  @Field(() => Float)
  kpiAchievement: number;

  @Field(() => Float)
  roi: number;

  @Field()
  customerImpact: string;

  @Field()
  strategicSuccess: string;
}

@InputType()
export class UpdateOutcomeInput {
  @Field(() => String, { nullable: true })
  businessGoals?: string;

  @Field(() => String, { nullable: true })
  kpiTargets?: string;

  @Field(() => Float, { nullable: true })
  kpiAchievement?: number;

  @Field(() => Float, { nullable: true })
  roi?: number;

  @Field(() => String, { nullable: true })
  customerImpact?: string;

  @Field(() => String, { nullable: true })
  strategicSuccess?: string;
}

@Resolver(() => Outcome)
export class OutcomeResolver {
  constructor(private readonly outcomeService: OutcomeService) {}

  @Query(() => [Outcome])
  async getOutcomes() {
    return this.outcomeService.findAll();
  }

  @Query(() => Outcome)
  async getOutcome(@Args('id', { type: () => ID }) id: string) {
    return this.outcomeService.findById(id);
  }

  @Mutation(() => Outcome)
  async createOutcome(@Args('input') input: CreateOutcomeInput) {
    return this.outcomeService.create(input);
  }

  @Mutation(() => Outcome)
  async updateOutcome(
    @Args('id', { type: () => ID }) id: string,
    @Args('input') input: UpdateOutcomeInput,
  ) {
    return this.outcomeService.update(id, input);
  }

  @Mutation(() => Outcome)
  async deleteOutcome(@Args('id', { type: () => ID }) id: string) {
    return this.outcomeService.delete(id);
  }
}
