import {
  Controller,
  Get,
  Param,
  Query,
  Post,
  Body,
  UseGuards,
} from '@nestjs/common';
import { KnowledgeService } from './knowledge.service';
import { JwtAuthGuard } from '../../core/auth/jwt-auth.guard';

@UseGuards(JwtAuthGuard)
@Controller('knowledge')
export class KnowledgeController {
  constructor(private readonly knowledgeService: KnowledgeService) {}

  @Get('traverse/:startNodeId')
  async traverseGraph(
    @Param('startNodeId') startNodeId: string,
    @Query('depth') depth?: string,
  ) {
    const maxDepth = depth ? parseInt(depth, 10) : 3;
    return this.knowledgeService.traverseGraph(startNodeId, maxDepth);
  }

  @Post('nodes')
  async createNode(@Body() body: { entityId: string; entityType: string }) {
    return this.knowledgeService.createNode(body.entityId, body.entityType);
  }

  @Post('edges')
  async createEdge(
    @Body() body: { sourceId: string; targetId: string; relation: string },
  ) {
    return this.knowledgeService.createEdge(
      body.sourceId,
      body.targetId,
      body.relation,
    );
  }
}
