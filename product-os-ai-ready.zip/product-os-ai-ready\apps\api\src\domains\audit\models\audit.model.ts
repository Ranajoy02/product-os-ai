import { Field, ID, ObjectType, InputType } from '@nestjs/graphql';
import { GraphQLJSONObject } from 'graphql-type-json';

@ObjectType()
export class AuditLog {
  @Field(() => ID)
  id: string;

  @Field()
  entityType: string;

  @Field()
  entityId: string;

  @Field()
  action: string;

  @Field()
  actorId: string;

  @Field()
  timestamp: string;

  @Field()
  ipAddress: string;

  @Field(() => GraphQLJSONObject, { nullable: true })
  beforeState?: any;

  @Field(() => GraphQLJSONObject, { nullable: true })
  afterState?: any;
}

@InputType()
export class CreateAuditLogInput {
  @Field()
  entityType: string;
  @Field()
  entityId: string;
  @Field()
  action: string;
  @Field()
  actorId: string;
  @Field()
  timestamp: string;
  @Field()
  ipAddress: string;
}
