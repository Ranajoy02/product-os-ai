import {
  Resolver,
  Query,
  Mutation,
  Args,
  ObjectType,
  Field,
  ID,
  Int,
} from '@nestjs/graphql';
import { WorkflowService } from './workflow.service';
import { GraphQLJSONObject } from 'graphql-type-json';

@ObjectType()
export class WorkflowExecution {
  @Field(() => ID)
  id: string;

  @Field()
  workflowId: string;

  @Field()
  targetId: string;

  @Field()
  targetType: string;

  @Field()
  status: string;
}

@ObjectType()
export class WorkflowTransition {
  @Field(() => ID)
  id: string;

  @Field()
  sourceId: string;

  @Field()
  targetId: string;

  @Field(() => GraphQLJSONObject, { nullable: true })
  condition?: any;
}

@ObjectType()
export class WorkflowStep {
  @Field(() => ID)
  id: string;

  @Field()
  workflowId: string;

  @Field()
  name: string;

  @Field()
  type: string;

  @Field(() => GraphQLJSONObject)
  config: any;

  @Field(() => Int, { nullable: true })
  slaMinutes?: number;

  @Field()
  isBottleneck: boolean;

  @Field(() => [WorkflowTransition], { nullable: true })
  transitions?: WorkflowTransition[];

  @Field(() => [WorkflowTransition], { nullable: true })
  incoming?: WorkflowTransition[];
}

@ObjectType()
export class Workflow {
  @Field(() => ID)
  id: string;

  @Field()
  name: string;

  @Field({ nullable: true })
  description?: string;

  @Field()
  organizationId: string;

  @Field(() => Int)
  version: number;

  @Field()
  isPublished: boolean;

  @Field(() => [WorkflowStep], { nullable: true })
  steps?: WorkflowStep[];

  @Field(() => [WorkflowExecution], { nullable: true })
  executions?: WorkflowExecution[];
}

@Resolver(() => Workflow)
export class WorkflowResolver {
  constructor(private readonly workflowService: WorkflowService) {}

  @Query(() => [Workflow])
  async workflows(@Args('organizationId') organizationId: string) {
    return this.workflowService.getWorkflows(organizationId);
  }

  @Query(() => Workflow, { nullable: true })
  async workflow(@Args('id', { type: () => ID }) id: string) {
    return this.workflowService.getWorkflow(id);
  }

  @Mutation(() => Workflow)
  async createWorkflow(
    @Args('organizationId') organizationId: string,
    @Args('name') name: string,
    @Args('description', { nullable: true }) description?: string,
  ) {
    return this.workflowService.createWorkflow(
      organizationId,
      name,
      description,
    );
  }

  @Mutation(() => WorkflowStep)
  async addWorkflowStep(
    @Args('workflowId') workflowId: string,
    @Args('name') name: string,
    @Args('type') type: string,
    @Args('config', { type: () => GraphQLJSONObject }) config: any,
  ) {
    return this.workflowService.addStep(workflowId, name, type as any, config);
  }

  @Mutation(() => WorkflowTransition)
  async addWorkflowTransition(
    @Args('sourceId') sourceId: string,
    @Args('targetId') targetId: string,
    @Args('condition', { type: () => GraphQLJSONObject, nullable: true })
    condition?: any,
  ) {
    return this.workflowService.addTransition(sourceId, targetId, condition);
  }

  @Mutation(() => WorkflowExecution)
  async executeWorkflowStep(
    @Args('workflowId') workflowId: string,
    @Args('targetId') targetId: string,
    @Args('targetType') targetType: string,
    @Args('actionPayload', { type: () => GraphQLJSONObject })
    actionPayload: any,
  ) {
    return this.workflowService.executeStep(
      workflowId,
      targetId,
      targetType,
      actionPayload,
    );
  }
}
