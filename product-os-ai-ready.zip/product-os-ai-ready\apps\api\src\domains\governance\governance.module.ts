import { Module } from '@nestjs/common';
import { GovernanceService } from './governance.service';
import { GovernanceResolver } from './governance.resolver';

@Module({
  providers: [GovernanceService, GovernanceResolver],
  exports: [GovernanceService, GovernanceResolver],
})
export class GovernanceModule {}
