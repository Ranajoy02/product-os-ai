import { create } from 'zustand';

export type WorkspaceEntityType = 'product' | 'project' | 'release' | 'initiative' | 'program';

export type LifecycleStage = 
  | 'Objective'
  | 'Business Case'
  | 'BRD'
  | 'PRD'
  | 'Roadmap'
  | 'Workflow'
  | 'Resource Planning'
  | 'Design'
  | 'Development'
  | 'Testing'
  | 'Approval'
  | 'Release'
  | 'Post Release Review'
  | 'Outcome'
  | 'Knowledge Capture';

export type WorkspaceTab = 
  | 'Overview' 
  | 'Lifecycle' 
  | 'Documents' 
  | 'Communication' 
  | 'Approvals' 
  | 'Performance' 
  | 'Insights';

interface WorkspaceState {
  entityId: string | null;
  entityType: WorkspaceEntityType | null;
  activeTab: WorkspaceTab;
  activeLifecycleStage: LifecycleStage;
  
  // Actions
  setEntity: (id: string, type: WorkspaceEntityType) => void;
  setActiveTab: (tab: WorkspaceTab) => void;
  setLifecycleStage: (stage: LifecycleStage) => void;
  resetWorkspace: () => void;
}

export const useWorkspaceStore = create<WorkspaceState>((set) => ({
  entityId: null,
  entityType: null,
  activeTab: 'Overview',
  activeLifecycleStage: 'Objective',
  
  setEntity: (id, type) => set({ entityId: id, entityType: type }),
  setActiveTab: (tab) => set({ activeTab: tab }),
  setLifecycleStage: (stage) => set({ activeLifecycleStage: stage }),
  resetWorkspace: () => set({ entityId: null, entityType: null, activeTab: 'Overview', activeLifecycleStage: 'Objective' })
}));
