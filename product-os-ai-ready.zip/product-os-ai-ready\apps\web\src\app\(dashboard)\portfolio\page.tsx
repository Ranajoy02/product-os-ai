'use client';

import React from 'react';
import { useQuery } from '@apollo/experimental-nextjs-app-support/ssr';
import { gql } from '@apollo/client';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { PieChart, TrendingUp, AlertOctagon, Activity, Briefcase } from 'lucide-react';
import { PortfolioSimulator } from '@/components/portfolio/PortfolioSimulator';

const GET_PORTFOLIO_DASHBOARD = gql`
  query GetPortfolioIntelligence {
    getPortfolioIntelligence {
      totalValueCreated
      averageROI
      overloadedTeams
      delayedInitiatives
      portfolioItems {
        id
        name
        type
        roi
        status
      }
    }
  }
`;

export default function PortfolioPage() {
  const { data, loading, error } = useQuery<any>(GET_PORTFOLIO_DASHBOARD);

  if (loading) return <div className="p-8 text-slate-500 animate-pulse">Loading Portfolio Intelligence...</div>;
  if (error) return <div className="p-8 text-rose-500">Error: {error.message}</div>;

  const metrics = data?.getPortfolioIntelligence;

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Portfolio Intelligence</h1>
          <p className="text-slate-500 mt-1">Macro-level tracking of investments, value creation, and cross-initiative risks.</p>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-4">
        <Card className="border-indigo-100 bg-gradient-to-br from-indigo-50 to-white shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">Total Value Created</CardTitle>
            <PieChart className="h-4 w-4 text-indigo-500" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-indigo-700">${(metrics?.totalValueCreated / 1000000).toFixed(1)}M</div>
          </CardContent>
        </Card>
        
        <Card className="border-emerald-100 bg-gradient-to-br from-emerald-50 to-white shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">Average ROI</CardTitle>
            <TrendingUp className="h-4 w-4 text-emerald-500" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-emerald-700">{metrics?.averageROI}%</div>
          </CardContent>
        </Card>

        <Card className="border-rose-100 bg-gradient-to-br from-rose-50 to-white shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">Delayed Initiatives</CardTitle>
            <Activity className="h-4 w-4 text-rose-500" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-rose-700">{metrics?.delayedInitiatives}</div>
          </CardContent>
        </Card>

        <Card className="border-amber-100 bg-gradient-to-br from-amber-50 to-white shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">Overloaded Teams</CardTitle>
            <AlertOctagon className="h-4 w-4 text-amber-500" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-amber-700">{metrics?.overloadedTeams}</div>
          </CardContent>
        </Card>
      </div>

      <div className="mt-8">
        <PortfolioSimulator />
      </div>

      <Card className="mt-8">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Briefcase className="w-5 h-5 text-slate-500" /> Executive Investment Breakdown
          </CardTitle>
        </CardHeader>
        <CardContent>
           <div className="overflow-x-auto">
             <table className="w-full text-sm text-left">
               <thead className="text-xs text-slate-500 uppercase bg-slate-50 border-b border-slate-200">
                 <tr>
                   <th className="px-6 py-3">Portfolio Item</th>
                   <th className="px-6 py-3">Type</th>
                   <th className="px-6 py-3">Status</th>
                   <th className="px-6 py-3">ROI</th>
                 </tr>
               </thead>
               <tbody className="divide-y divide-slate-100">
                 {metrics?.portfolioItems.map((item: any) => (
                   <tr key={item.id} className="hover:bg-slate-50">
                     <td className="px-6 py-4 font-medium text-slate-900">{item.name}</td>
                     <td className="px-6 py-4 text-slate-500">{item.type}</td>
                     <td className="px-6 py-4">
                       <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${
                         item.status === 'On Track' ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'
                       }`}>
                         {item.status}
                       </span>
                     </td>
                     <td className="px-6 py-4 text-emerald-600 font-medium">{item.roi}%</td>
                   </tr>
                 ))}
               </tbody>
             </table>
           </div>
        </CardContent>
      </Card>
    </div>
  );
}
