import { Controller, Post, Body, Param, UseGuards } from '@nestjs/common';
import { AiService } from './ai.service';
import { JwtAuthGuard } from '../../core/auth/jwt-auth.guard';

@UseGuards(JwtAuthGuard)
@Controller('ai')
export class AiController {
  constructor(private readonly aiService: AiService) {}

  @Post('projects/:projectId/parse-prd')
  async parsePrd(
    @Param('projectId') projectId: string,
    @Body('content') content: string,
  ) {
    return this.aiService.parsePrdToTasks(projectId, content);
  }

  @Post('products/:productId/index-document')
  async indexDocument(
    @Param('productId') productId: string,
    @Body() body: { title: string; content: string },
  ) {
    return this.aiService.indexDocument(productId, body.title, body.content);
  }

  @Post('workflow/generate')
  async generateWorkflow(@Body('prompt') prompt: string) {
    return this.aiService.generateWorkflowFromPrompt(prompt);
  }

  @Post('root-cause')
  async analyzeRootCause(@Body() body: { query: string; releaseId: string }) {
    return this.aiService.analyzeRootCause(body.query, body.releaseId);
  }
}
