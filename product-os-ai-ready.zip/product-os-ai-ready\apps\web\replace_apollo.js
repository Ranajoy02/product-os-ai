const fs = require('fs');
const path = require('path');
const { globSync } = require('glob');

const files = globSync('src/app/(dashboard)/**/page.tsx');
files.forEach(file => {
  let content = fs.readFileSync(file, 'utf8');
  if (content.includes('@apollo/client') && content.includes('useQuery')) {
    content = content.replace(/import\s+\{\s*([^}]*?useQuery[^}]*?)\s*\}\s+from\s+'@apollo\/client';/g, (match, p1) => {
      const others = p1.split(',').map(s => s.trim()).filter(s => s !== 'useQuery' && s !== '');
      let newImport = `import { useQuery } from '@apollo/experimental-nextjs-app-support/ssr';\n`;
      if (others.length > 0) {
        newImport += `import { ${others.join(', ')} } from '@apollo/client';`;
      }
      return newImport;
    });
    fs.writeFileSync(file, content);
    console.log('Updated ' + file);
  }
});
