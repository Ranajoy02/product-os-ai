'use client';

import React from 'react';
import { WorkspaceEntityType } from '@/store/workspace-context';
import { Badge } from '@/components/ui/badge';
import { ChevronRight, LayoutDashboard } from 'lucide-react';
import Link from 'next/link';

interface WorkspaceHeaderProps {
  entityId: string;
  entityType: WorkspaceEntityType;
}

export function WorkspaceHeader({ entityId, entityType }: WorkspaceHeaderProps) {
  // Mock data for initial loading, would be preloaded via Apollo
  const entityName = `${entityType.charAt(0).toUpperCase() + entityType.slice(1)} ${entityId}`;

  return (
    <header className="h-14 border-b bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 flex items-center px-4 justify-between">
      <div className="flex items-center space-x-2 text-sm text-slate-600 dark:text-slate-400">
        <Link href="/" className="hover:text-indigo-600 flex items-center">
          <LayoutDashboard className="h-4 w-4 mr-1" />
          Workspace
        </Link>
        <ChevronRight className="h-4 w-4" />
        <span className="capitalize">{entityType}</span>
        <ChevronRight className="h-4 w-4" />
        <span className="font-semibold text-slate-900 dark:text-slate-100">{entityName}</span>
      </div>
      
      <div className="flex items-center space-x-3">
        <Badge variant="outline" className="bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950 dark:text-emerald-400 dark:border-emerald-800">
          On Track
        </Badge>
        <div className="h-8 w-8 rounded-full bg-slate-200 dark:bg-slate-800 flex items-center justify-center text-xs font-semibold">
          JD
        </div>
      </div>
    </header>
  );
}
